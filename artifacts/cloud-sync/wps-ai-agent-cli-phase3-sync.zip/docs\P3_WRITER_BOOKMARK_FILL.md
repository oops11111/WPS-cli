# Writer Bookmark Fill

P3-079 adds `writer-fill-bookmark` and `wps_agent_writer_fill_bookmark` for
filling a unique, non-reserved bookmark whose paired endpoints sit in the same
direct body paragraph. P3-186 also accepts a same-paragraph bookmark in a direct-body
table cell, with a single-line replacement of at most 4096 characters. The result preserves surrounding paragraph text and
uses WPS to replace only the bookmarked range. Preflight requires one paired
name and valid character offsets; missing, duplicate, malformed, cross-paragraph,
nested-table, text-box and header/footer targets are rejected before backup.

`--dry-run` reports the bookmark name, paragraph index and text lengths without
opening WPS or creating a backup. A write creates a backup, opens the registered
document in WPS, checks the current range text, writes the requested value,
recreates the bookmark around the inserted text, saves, then verifies the WPS
range. After closing WPS, offline read-back checks the bookmark is still unique,
its value matches, and the complete target paragraph equals the expected text.
Failures after the write retain the backup for recovery. Request IDs replay a
recorded successful write.

P3-173 also compares every direct body paragraph and table-cell text after the write. When the original body ends in a table, WPS may append exactly one empty body paragraph during save; that single normalization is accepted and reported as `body_tail_normalized=true`. Any other extra paragraph or changed table text still fails validation. Real WPS tests passed for both inline-run and direct-paragraph-child bookmark markers on temporary copies, including neighboring table/header/footer text, backup, and replay. This does not expand the supported write scope.

This implementation does not fill bookmarks spanning paragraphs, in nested cells,
text boxes, headers/footers, notes or comments. It does not promise formatting
preservation across mixed-format runs; WPS controls formatting at the replaced
range. The current verified fixture checks that a single bold bookmark run
remains bold. Page layout and visual fidelity are not checked.

For a supported direct table cell, post-save readback checks the bookmark remains
in the same cell and story paragraph, all document paragraphs match the expected
single-range replacement, and direct-body table topology is unchanged (grid
columns, row/cell arrangement, merge flags, and cell paragraph/nested-table counts).
The real WPS temporary-file test verifies adjacent cell and body text, backup,
post-save registration identity, and Python/CLI/MCP replay. P3-187 additionally
verified horizontal/vertical merges, a multi-paragraph cell, table style, and
neighboring italic and target bold runs on disposable real-WPS files. P3-188
normalizes relationship hyperlinks and simple/complex fields to semantic targets,
instructions, and display text for post-save comparison. Real WPS retained a
same-cell hyperlink and merge field through two consecutive bookmark fills, even
though it converted both nodes to complex fields. A bookmark range overlapping a
hyperlink or field is rejected before backup. Malformed/nested field boundaries,
broader formatting, and visual fidelity remain unverified.
P3-189 also rejects missing hyperlink relationships, empty field instructions,
orphaned field separators, unclosed complex fields, and nested fields before
backup or WPS startup. Offline tampering tests confirm that changed relationship
targets and field instructions fail post-save validation.
P3-190 extends table-cell readback to inline and anchored drawing trees, image
relationship targets and image-byte hashes, extents, transform, crop, position,
wrap, and visible object descriptions. A disposable real-WPS inline image passed;
a bookmark range enclosing a drawing is rejected before backup. P3-191 verified
one positioned, cropped anchor and two cropped inline images through WPS save.
P3-192 verified two anchors with distinct stacking ranks, horizontal positions,
crop data, relationship targets, and image hashes. P3-193 exports the disposable
document to PDF before and after WPS save, rasterizes both, and verifies that the
red and blue image masks are pixel-identical. An overlap sample confirms the
expected top drawing. P3-194 verified page and column/paragraph reference frames
through rendered WPS output and rejects character-relative anchors that can drift
when preceding bookmark text changes width. P3-195 verified cell-edge clamping,
page-edge raster clipping with `layoutInCell` disabled, and stable none, square,
and top-and-bottom wrap modes with unchanged adjacent text geometry. P3-196
verified unchanged page count, marker geometry, and full-page raster output in a
multi-page table-bookmark fixture. P3-197 audits multiple anchors across page
breaks and confirmed per-page visibility, stacking ranks, marker geometry, and
pixel-identical full-page output. P3-198 verified tight/through diamond wrap
polygons through WPS save. P3-199 verified left/right/largest plus asymmetric
floating distances and long text flow; the snapshot now records all four
distances. P3-200 rejects malformed polygons and invalid distances before
backup. P3-201 audits concave/self-intersecting paths.

Evidence on 2026-10-07:

- Offline tests cover character offsets, dry-run without file changes, missing
  and reserved names, duplicate names, cross-paragraph and table rejection,
  no backup before rejected writes, commit read-back and idempotent replay.
- Local `kwps.Application` integration passed on a temporary DOCX. It filled
  `Client` from `old` to `Northwind`, retained the bookmark, preserved bold
  formatting, and verified the full paragraph `Dear Northwind!`.
- MCP catalog drift is zero at 61 tools (9 mutating, 11 WPS-required, 52
  read-only). `mcp-smoke --expected-min-tools 61 --tool-name wps_agent_tasks`
  passes; mutating bookmark tools are not called by the generic smoke harness.

P3-080 formula/cache/display inspection is complete; see
`P3_SPREADSHEET_INSPECT.md` for its WPS evidence. P3-081 now examines how the
existing spreadsheet reader represents dates, percentages, currency and empty
cells without changing its raw-value contract.
