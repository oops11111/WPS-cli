# Product Requirements Evidence Audit

Date: 2026-10-07. Source: user-supplied WPS_AI_Agent_CLI_PRD_v1.1.docx,
sections 4, 5, 7, 8 and 9, read from its DOCX XML. This is a capability gap
audit, not a claim that all PRD acceptance criteria are met.

| PRD requirement | Current evidence | Remaining work |
| --- | --- | --- |
| Stable document IDs, backup, recovery | sessions.py records content and file identity; source/backup checks surround COM, P3-175 serializes cooperating Agent mutations, P3-176 atomically persists shared registries, P3-177 records post-save identity for replay repair, and P3-178 blocks automatic reapplication when a derived backup exists but the unrecorded source changed; real Writer/Spreadsheet WPS writes passed | Registrations are not live COM sessions; the locks do not exclude external editors, and a changed source without a main operation record is deliberately ambiguous rather than proven successful |
| Writer structure and targeted editing | `writer-structure` reads bounded heading/style/bookmark metadata and uniquely paired same-paragraph body/table/header/footer bookmark text; current WPS parity passed 7/7 and 4/4; P3-186 adds guarded table-cell writes; P3-187 verifies table topology; P3-188/189 verify safe hyperlink/field behavior; P3-190/191 verify drawing relationships, crops, positions, and multiple inline images; P3-192 verifies multiple-anchor stacking and media targets through WPS save; P3-193 confirms pixel-identical red/blue masks in rendered PDFs before/after WPS save | Broader cross-version matrix and visual fidelity outside the tested fixture remain unverified |
| Spreadsheet read/write and real calculation | bounded range/formula operations, format and WPS display inspection; worksheet inventory covers layout, visibility, protection, names, calculations and bounded validation/formatting metadata; worksheet mutations have WPS-backed transaction tests; P3-113 verifies 1904 dates and host-locale display | Broader WPS version/locale matrix and macro-enabled WPS round-trip/data preservation still need distinct verification |
| Presentation page/object targeting | presentation_text.py resolves logical slide order; snapshots include blank/image-only slides, grouped text and tables; replacement traverses nested shapes/cells, preserves matched-range formatting and verifies per-object text; P3-088 already limits Spreadsheet write ranges to 10,000 cells before backup/WPS | Broader cross-version Presentation visual fidelity remains unverified |
| Conversion matrix and HTML modes | `html-render`, `html-editable`, controlled import/verify/export; real WPS rich-media round-trip retains stable image/link identities | Broader WPS version fidelity validation remains |
| Batch conversion with per-file results | `html-batch-convert` and `wps_agent_html_batch_convert` convert up to 100 HTML files to PDF/PNG/DOCX with isolated failures and SHA-256 provenance; `batch-template-report` and `wps_agent_batch_template_report` render validated manifests through local Markdown or DOCX templates | Broader cross-version and multipage visual fidelity evidence remains |
| Tasks, cancellation, progress | `html-batch-convert --task-id` updates per-file progress, polls shared task status between files, and retains a partial manifest on cancellation | Live progress streaming and process recovery remain |
| Structured CLI/MCP contract | cli.py, mcp_adapter.py, mcp_server.py; unit and smoke tests | Real desktop-client integration and broad Agent user-story evaluation need distinct evidence |
| Content, calculation and format verification | validators.py, snapshots.py, regression manifest | Current structural checks do not establish visual fidelity or cross-version success thresholds |

Historical Phase 0/1/2 completion refers to the implemented local milestones;
it must not be interpreted as full PRD delivery. The 123 passing unit tests on
the audit date proved their assertions, not all product requirements. Current
test totals and WPS integration evidence are maintained in
`PHASE3_RELEASE_READINESS_REFRESH.md`.

## Scheduled Work

1. P3-159 complete: safe baseline and artifact-dependent release gates are separated. The local safe run passed 15/15 and release run passed 3/3 after package refresh; old failed artifacts were retained.
2. P3-160 complete: `local-release-gates` passed the five-step local package/safe/refresh/readiness/release sequence and saved both regression artifacts.
3. P3-161 complete: bounded, read-only Writer heading/style/bookmark inspection is available via CLI/MCP. It is offline OOXML evidence, not a WPS layout claim.
4. P3-162 complete: selected-section pagination and exact bookmark lookup now report source hashes and ambiguity.
5. P3-163 complete: bounded bookmark text inspection distinguishes available, empty, missing, ambiguous, unsupported scope, and invalid range without claiming WPS validation.
6. P3-164 complete: controlled local WPS read-only observations agreed on paragraph text/order, heading levels, and bookmark text; localized style display names differed from OOXML style IDs as expected.
7. P3-165 complete: opt-in Writer parity CLI/MCP passed 6/6 checks on the controlled local fixture and retained a JSON report with source hash.
8. P3-166 complete: local handoff includes the latest Writer parity JSON; readiness checks report status, fixture/script hashes, and package byte equality without launching WPS.
9. P3-167 complete: a separate controlled fixture verified table and header/footer bookmark presence and text through read-only WPS; this was before nested offline text reads were implemented.
10. P3-168 complete: bounded same-paragraph nested bookmark reads agree with the controlled WPS fixture through CLI/MCP; cross-container and ambiguous reads remain unsupported, and Writer mutation scope stays body-only.
11. P3-169 complete: an opt-in nested-scope Writer parity command retained a passed 3/3 local WPS JSON report; local handoff readiness verifies its source/script hashes and packaged bytes.
12. P3-170 complete: revision/text-box paragraphs are rejected for bookmark reads and fills; a controlled mixed-run table bookmark matched read-only WPS with unchanged SHA-256.
13. P3-171 complete: both Writer parity reports now bind four implementation-file hashes; local readiness marks reports stale when code changes, even if file mtimes are preserved.
14. P3-172 complete: registrations bind SHA-256 and file identity; mutation backup preflight rejects stale or legacy-unverified records, detects copy-time changes, and refreshes the identity after successful local operations. See `P3_DOCUMENT_IDENTITY_AUDIT.md` for the remaining race.
15. P3-173 complete: the observed bookmark fill had correctly updated text, but WPS appended one empty paragraph after a terminal table; narrowly accepting that normalization preserved neighboring text/table checks, backup, and replay.
16. P3-174 complete: a shared guard rechecks source identity and backup bytes just before COM, then checks post-COM source identity after readback; controlled Writer and Spreadsheet replacements are rejected without starting COM.
17. P3-175 complete: a workspace/document-ID lock spans cooperating Agent mutation and registration calls; cross-process contention returns `DOCUMENT_BUSY`, and real Writer/Spreadsheet WPS writes passed under the lock.
18. P3-176 complete: shared documents/operations registry read-modify-write transactions now use bounded cross-process locks and same-directory atomic replacement. Four processes retained 48 distinct records in each registry; concurrent reads saw complete JSON; failed replacement preserved the old state. Real WPS Writer/Spreadsheet checks passed.
19. P3-177 complete: committed file identity allows safe replay repair when registration refresh failed; a changed file or failed identity capture produces explicit non-replayable evidence. Windows transient lock initialization and read sharing races found by repeated concurrency tests were fixed.
20. P3-178 complete: a derived backup with unchanged source allows retry; a changed or unreadable source without a main operation record returns `UNRECORDED_MUTATION_AMBIGUOUS` before target lookup, preventing automatic reapplication. This is not evidence that WPS saved successfully.
21. P3-179 complete: `mutation-request-inspect` and its MCP mapping report main operation, derived backup, and current file identity without writing; recorded-but-stale, changed, retryable, ambiguous, and no-evidence states are distinguished.
22. P3-180 complete: all eight mutation inspection states include non-destructive recovery guidance in CLI/MCP results, and the local validation runbook begins with read-only request evidence inspection; ambiguous states explicitly prohibit automatic overwrite or retry.
23. P3-181 complete: real WPS Writer/Spreadsheet saves on disposable files were interrupted before main ledger commit; retained current/backup artifacts and hashes show ambiguity, CLI/MCP agreed, and same-ID retry did not alter either saved source.
24. P3-182 complete: a bounded, read-only verifier checks both retained manifests and file hashes, rejects missing/malformed/redirected evidence, and reports the two-component result through local handoff; the current workspace passed.
25. P3-183 complete: package creation now rejects incomplete or changed recovery evidence before rebuilding; six valid generated files are included and compared byte-for-byte in package readiness. The current local package passed 6/6 comparisons.
26. P3-184 complete: the real portable package was extracted into a fresh in-workspace directory and its own packaged source independently verified both recovered Writer/Spreadsheet manifests and hashes; a different-root extraction test also passed.
27. P3-185 complete: real WPS filled a uniquely paired table-cell bookmark on a disposable DOCX while adjacent runs, neighbor cell, body paragraphs, and backup identity remained intact; no public mutation scope changed.
28. P3-186 complete: guarded public table-cell bookmark fill passed 356 default tests (30 skipped), one real WPS temporary-file test, and refreshed Writer parity 7/7 and 4/4; scope remains a unique same-paragraph bookmark in a direct-body cell.
29. P3-187 complete: semantic table topology readback rejects a changed merge while preserving expected text; real WPS retained horizontal/vertical merges, multiple cell paragraphs, table style, and tested adjacent/target run formatting. Default tests passed 358 (31 skipped).
30. P3-188 complete: real WPS converted a relationship hyperlink and simple merge field to complex fields; normalized target/instruction/display text survived two fills. Offline guards reject range overlap before backup and changed anchor, relationship target, or field instruction after save. Default tests passed 362 (32 skipped).
31. P3-189 complete: missing hyperlink targets, empty instructions, orphaned separators, unclosed and nested complex fields are rejected before backup/WPS; valid neighbors pass repeated WPS writes. Default tests passed 363 (32 skipped).
32. P3-190 complete: real WPS retained the inline image drawing structure, extent, object description, relationship target, and image hash beside a table bookmark; overlap rejection and relationship-change regressions passed. Default tests passed 366 (33 skipped).
33. P3-191 complete: a positioned/cropped anchor and two cropped inline images retained drawing trees, image targets, and hashes through real WPS; default tests passed 367 (34 skipped), and all five WPS table tests passed.
34. P3-192 complete: two anchors with distinct relative heights and positions retained stacking rank, crop, relationship targets, and image hashes through real WPS save; default tests passed 367 (34 skipped).
35. P3-193 complete: rendered PDF image masks before and after WPS save are pixel-identical for the overlapping red/blue anchor fixture, with overlap order verified.
36. P3-194 complete: column/paragraph and page/page anchor masks remained pixel-identical through WPS bookmark fill; page-relative coordinates were clipped at the table-cell boundary by `layoutInCell`. Character-relative positioning drifted with glyph width and is rejected before backup.
37. P3-195 complete: WPS clamps out-of-cell anchors to the cell edge; with `layoutInCell` off, negative page-relative positioning is raster-clipped to 144x108 pixels. None, square, and top-and-bottom wrapping, crop semantics, and adjacent text bounds remain stable through bookmark fill.
38. P3-196 complete: a multi-page WPS table-bookmark fixture retained page count, PREFACE/AFTER-TABLE page and character bounds, drawing semantics, and pixel-identical full-page raster images.
39. P3-197 complete: a red anchor on page one and a blue table anchor on a later page retained expected visibility, relativeHeight ranking, marker page/character bounds, full-page raster output, and per-color masks through WPS bookmark fill.
40. P3-198 complete: diamond wrapPolygon paths using tight and through modes retained DrawingML vertices, rendered page raster, extracted text, and table-bookmark read-back through real WPS save.
41. P3-199 complete: real WPS preserved left/right/largest wrapText, asymmetric four-direction distances, long wrapped paragraph text, and full-page raster output; drawing snapshots expose each distance.
42. P3-200 complete: tight/through missing polygon, too few vertices, out-of-range coordinates, and negative distances are rejected before backup/WPS with unchanged target bytes; 12 Writer WPS integrations pass.
43. P3-201 next: verify concave wrap paths and reject self-intersecting/degenerate polygons before backup.
44. Later: broaden visual/semantic fidelity and WPS version coverage while preserving independent failures and artifact provenance.

These milestones are actionable entirely in the local workspace. Offline parsing fixes
must remain labelled as file-library behavior; WPS end-to-end validation is a
separate gate, not implied by offline tests.
