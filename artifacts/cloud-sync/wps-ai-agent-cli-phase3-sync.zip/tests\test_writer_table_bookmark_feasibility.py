import os
import io
import json
import tempfile
import unittest
from contextlib import chdir
from pathlib import Path

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.shared import Inches
from PIL import Image
from PIL import ImageChops
import pypdfium2

from wps_ai_agent_cli.backups import create_backup
from wps_ai_agent_cli.com_backend import run_conversion_smoke
from wps_ai_agent_cli.document_text import (
    docx_body_drawing_semantics,
    docx_body_link_field_semantics,
    docx_body_table_topology,
)
from wps_ai_agent_cli.sessions import file_identity, register_document
from wps_ai_agent_cli.writer_ops import writer_fill_bookmark
from wps_ai_agent_cli.writer_structure import read_supported_bookmark_text
from wps_ai_agent_cli.cli import run
from wps_ai_agent_cli.mcp_adapter import call_mcp_tool


def write_image_bookmark_document(
    path: Path, bookmark_around_drawing: bool = False, image_count: int = 1,
    anchored: bool = False, cropped: bool = False, image_width_inches: float = 0.25,
    anchor_spacing_inches: float = 0.25,
    anchor_relative_frames: tuple[str, str] = ("column", "paragraph"),
    anchor_offsets_inches: tuple[float, float] = (0.75, 0.0),
    anchor_wrap: str = "square",
    anchor_wrap_text: str | None = "bothSides",
    anchor_distances_inches: tuple[float, float, float, float] = (0.0, 0.0, 0.125, 0.125),
    layout_in_cell: str = "1",
    preamble_paragraphs: int = 0,
    postamble_paragraphs: int = 0,
    preamble_images: int = 0,
    flow_text_repetitions: int = 0,
) -> None:
    def image_stream(index: int) -> io.BytesIO:
        stream = io.BytesIO()
        color = ((0, 80, 255), (255, 30, 0), (0, 190, 70))[index % 3]
        Image.new("RGB", (96, 64), color).save(stream, format="PNG")
        stream.seek(0)
        return stream

    document = Document()
    for index in range(preamble_paragraphs):
        label = "PREFACE-START" if index == 0 else f"Preamble paragraph {index + 1}"
        paragraph = document.add_paragraph(f"{label}: pagination fixture text for WPS Writer.")
        if index < preamble_images:
            paragraph.add_run().add_picture(image_stream(index + 1), width=Inches(image_width_inches))
    table = document.add_table(rows=1, cols=1)
    paragraph = table.cell(0, 0).paragraphs[0]
    paragraph.add_run("Before ")
    if bookmark_around_drawing:
        image_run = paragraph.add_run()
        image_run.add_picture(image_stream(0), width=Inches(image_width_inches))
        start = OxmlElement("w:bookmarkStart")
        start.set(qn("w:id"), "1")
        start.set(qn("w:name"), "ImageMark")
        end = OxmlElement("w:bookmarkEnd")
        end.set(qn("w:id"), "1")
        image_run._r.addprevious(start)
        image_run._r.addnext(end)
    else:
        old = paragraph.add_run("Old")
        start = OxmlElement("w:bookmarkStart")
        start.set(qn("w:id"), "1")
        start.set(qn("w:name"), "CellMark")
        end = OxmlElement("w:bookmarkEnd")
        end.set(qn("w:id"), "1")
        old._r.addprevious(start)
        old._r.addnext(end)
        paragraph.add_run(" ")
        for index in range(image_count):
            paragraph.add_run().add_picture(image_stream(index), width=Inches(image_width_inches))
        paragraph.add_run(" After")
        if flow_text_repetitions:
            paragraph.add_run(" wrap-flow sample text" * flow_text_repetitions)
    document.save(path)
    if postamble_paragraphs:
        document = Document(path)
        for index in range(postamble_paragraphs):
            label = "AFTER-TABLE-MARKER" if index == 0 else f"Postamble paragraph {index + 1}"
            document.add_paragraph(f"{label}: pagination fixture text for WPS Writer.")
        document.save(path)
    if anchored or cropped:
        document = Document(path)
        inline_drawings = list(document.element.body.iter(qn("wp:inline")))
        if anchored:
            for index, inline in enumerate(inline_drawings):
                anchor = OxmlElement("wp:anchor")
                for name, value in zip(
                    ("distT", "distB", "distL", "distR"),
                    (str(int(Inches(distance).emu)) for distance in anchor_distances_inches),
                ):
                    anchor.set(name, value)
                for name, value in (("simplePos", "0"),
                                    ("relativeHeight", str(100000 + index * 100000)), ("behindDoc", "0"),
                                    ("locked", "0"), ("layoutInCell", layout_in_cell),
                                    ("allowOverlap", "1")):
                    anchor.set(name, value)
                simple = OxmlElement("wp:simplePos")
                simple.set("x", "0")
                simple.set("y", "0")
                anchor.append(simple)
                horizontal = OxmlElement("wp:positionH")
                horizontal.set("relativeFrom", anchor_relative_frames[0])
                horizontal_offset = OxmlElement("wp:posOffset")
                horizontal_offset.text = str(int(Inches(
                    anchor_offsets_inches[0] + index * anchor_spacing_inches
                ).emu))
                horizontal.append(horizontal_offset)
                anchor.append(horizontal)
                vertical = OxmlElement("wp:positionV")
                vertical.set("relativeFrom", anchor_relative_frames[1])
                vertical_offset = OxmlElement("wp:posOffset")
                vertical_offset.text = str(int(Inches(anchor_offsets_inches[1]).emu))
                vertical.append(vertical_offset)
                anchor.append(vertical)
                for child_name in ("wp:extent", "wp:docPr", "wp:cNvGraphicFramePr", "a:graphic"):
                    child = inline.find(qn(child_name))
                    if child is not None:
                        anchor.append(child)
                wrap = OxmlElement(f"wp:wrap{anchor_wrap.title().replace('_', '')}")
                if anchor_wrap != "none" and anchor_wrap_text is not None:
                    wrap.set("wrapText", anchor_wrap_text)
                if anchor_wrap in {"tight", "through"}:
                    polygon = OxmlElement("wp:wrapPolygon")
                    start = OxmlElement("wp:start")
                    start.set("x", "10800")
                    start.set("y", "0")
                    polygon.append(start)
                    for x, y in ((21600, 10800), (10800, 21600), (0, 10800)):
                        point = OxmlElement("wp:lineTo")
                        point.set("x", str(x))
                        point.set("y", str(y))
                        polygon.append(point)
                    wrap.append(polygon)
                anchor.insert(4, wrap)
                inline.getparent().replace(inline, anchor)
        if cropped:
            blip_fill = next(document.element.body.iter(qn("pic:blipFill")))
            source_rect = OxmlElement("a:srcRect")
            source_rect.set("l", "10000")
            source_rect.set("r", "10000")
            blip = blip_fill.find(qn("a:blip"))
            blip_fill.insert(blip_fill.index(blip) + 1, source_rect)
        document.save(path)


def drawing_structure_differences(left, right, path="drawing"):
    if isinstance(left, dict) and isinstance(right, dict):
        differences = []
        for key in sorted(set(left) | set(right)):
            if key not in left or key not in right:
                differences.append((f"{path}.{key}", left.get(key), right.get(key)))
            else:
                differences.extend(drawing_structure_differences(left[key], right[key], f"{path}.{key}"))
        return differences
    if isinstance(left, list) and isinstance(right, list):
        if len(left) != len(right):
            return [(f"{path}.length", len(left), len(right))]
        return [difference for index, (before, after) in enumerate(zip(left, right))
                for difference in drawing_structure_differences(before, after, f"{path}[{index}]")]
    return [] if left == right else [(path, left, right)]


@unittest.skipUnless(os.environ.get("WPS_AGENT_RUN_INTEGRATION") == "1", "Requires explicit local WPS Writer integration run")
class WriterTableBookmarkFeasibilityTests(unittest.TestCase):
    def test_wps_table_bookmark_preserves_wrap_side_and_distances(self):
        variants = (
            ("left", (0.0, 0.0, 0.05, 0.3)),
            ("right", (0.15, 0.05, 0.3, 0.05)),
            ("largest", (0.2, 0.2, 0.2, 0.2)),
        )
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for wrap_text, distances in variants:
                with self.subTest(wrap_text=wrap_text):
                    path = root / f"wrap-side-{wrap_text}.docx"
                    before_pdf = root / f"before-{wrap_text}.pdf"
                    after_pdf = root / f"after-{wrap_text}.pdf"
                    write_image_bookmark_document(
                        path, anchored=True, image_width_inches=1.0,
                        anchor_offsets_inches=(2.0, 0.0), anchor_wrap="square",
                        anchor_wrap_text=wrap_text, anchor_distances_inches=distances,
                        flow_text_repetitions=35,
                    )
                    before_semantics = docx_body_drawing_semantics(path)
                    expected_distances = {
                        name: str(int(Inches(value).emu))
                        for name, value in zip(("distT", "distB", "distL", "distR"), distances)
                    }
                    self.assertEqual(before_semantics["drawings"][0]["wrap_distances"], expected_distances)
                    self.assertTrue(run_conversion_smoke("writer", str(path), str(before_pdf), "pdf")["ok"])
                    before_pdf_doc = pypdfium2.PdfDocument(str(before_pdf))
                    before_image = before_pdf_doc[0].render(scale=1.5).to_pil().convert("RGB")
                    before_text = before_pdf_doc[0].get_textpage().get_text_range()
                    before_pdf_doc.close()

                    ok, record, errors = register_document("writer", str(path), tmp)
                    self.assertTrue(ok, errors)
                    ok, result, errors, _ = writer_fill_bookmark(
                        record["document_id"], "CellMark", "Old", f"wrap-side-{wrap_text}", workspace=tmp,
                    )
                    self.assertTrue(ok, (errors, result))
                    self.assertEqual(docx_body_drawing_semantics(path), before_semantics)
                    self.assertTrue(run_conversion_smoke("writer", str(path), str(after_pdf), "pdf")["ok"])
                    after_pdf_doc = pypdfium2.PdfDocument(str(after_pdf))
                    after_image = after_pdf_doc[0].render(scale=1.5).to_pil().convert("RGB")
                    after_text = after_pdf_doc[0].get_textpage().get_text_range()
                    after_pdf_doc.close()
                    self.assertEqual(after_text, before_text)
                    self.assertIsNone(ImageChops.difference(before_image, after_image).getbbox())

    def test_wps_table_bookmark_preserves_tight_and_through_wrap_polygons(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for mode in ("tight", "through"):
                with self.subTest(wrap=mode):
                    path = root / f"{mode}-wrap.docx"
                    before_pdf = root / f"before-{mode}.pdf"
                    after_pdf = root / f"after-{mode}.pdf"
                    write_image_bookmark_document(
                        path, anchored=True, image_width_inches=1.0,
                        anchor_offsets_inches=(2.5, 0.0), anchor_wrap=mode,
                    )
                    before_semantics = docx_body_drawing_semantics(path)
                    wrap = before_semantics["drawings"][0]["structure"]["children"][4]
                    self.assertEqual(wrap["tag"].rsplit("}", 1)[-1], f"wrap{mode.title()}")
                    self.assertEqual(wrap["children"][0]["tag"].rsplit("}", 1)[-1], "wrapPolygon")
                    self.assertEqual(len(wrap["children"][0]["children"]), 4)
                    self.assertTrue(run_conversion_smoke("writer", str(path), str(before_pdf), "pdf")["ok"])
                    before_pdf_doc = pypdfium2.PdfDocument(str(before_pdf))
                    before_image = before_pdf_doc[0].render(scale=1.5).to_pil().convert("RGB")
                    before_text = before_pdf_doc[0].get_textpage().get_text_range()
                    before_pdf_doc.close()

                    ok, record, errors = register_document("writer", str(path), tmp)
                    self.assertTrue(ok, errors)
                    ok, result, errors, _ = writer_fill_bookmark(
                        record["document_id"], "CellMark", "Old", f"{mode}-wrap", workspace=tmp,
                    )
                    self.assertTrue(ok, (errors, result))
                    self.assertEqual(docx_body_drawing_semantics(path), before_semantics)
                    self.assertTrue(run_conversion_smoke("writer", str(path), str(after_pdf), "pdf")["ok"])
                    after_pdf_doc = pypdfium2.PdfDocument(str(after_pdf))
                    after_image = after_pdf_doc[0].render(scale=1.5).to_pil().convert("RGB")
                    after_text = after_pdf_doc[0].get_textpage().get_text_range()
                    after_pdf_doc.close()
                    self.assertEqual(before_text, after_text)
                    self.assertIsNone(ImageChops.difference(before_image, after_image).getbbox())

    def test_wps_table_bookmark_preserves_multi_anchor_pagination_and_order(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / "multi-anchor-pages.docx"
            before_pdf = root / "before-multi-anchor.pdf"
            after_pdf = root / "after-multi-anchor.pdf"
            write_image_bookmark_document(
                path, anchored=True, image_width_inches=0.9,
                anchor_relative_frames=("column", "paragraph"),
                anchor_offsets_inches=(0.75, 0.0), anchor_spacing_inches=0.25,
                anchor_wrap="square", preamble_paragraphs=36,
                preamble_images=1, postamble_paragraphs=36,
            )
            before_semantics = docx_body_drawing_semantics(path)
            self.assertEqual(len(before_semantics["drawings"]), 2)
            self.assertEqual([item["relative_height_order"] for item in before_semantics["drawings"]], [0, 1])
            self.assertTrue(run_conversion_smoke("writer", str(path), str(before_pdf), "pdf")["ok"])

            def render_report(pdf_path):
                pdf = pypdfium2.PdfDocument(str(pdf_path))
                reports = []
                markers = {}
                for page_index in range(len(pdf)):
                    page = pdf[page_index]
                    image = page.render(scale=1.5).to_pil().convert("RGB")
                    text_page = page.get_textpage()
                    text = text_page.get_text_range()
                    page_markers = {}
                    for marker in ("PREFACE-START", "AFTER-TABLE-MARKER"):
                        start = text.find(marker)
                        if start >= 0:
                            boxes = [text_page.get_charbox(index) for index in range(start, start + len(marker))]
                            page_markers[marker] = tuple(round(value, 2) for value in (
                                min(box[0] for box in boxes), min(box[1] for box in boxes),
                                max(box[2] for box in boxes), max(box[3] for box in boxes),
                            ))
                            markers[marker] = (page_index, page_markers[marker])
                    red, green, blue = image.split()
                    red_mask = ImageChops.multiply(
                        ImageChops.subtract(red, blue).point(lambda value: 255 if value > 100 else 0),
                        red.point(lambda value: 255 if value > 150 else 0),
                    )
                    blue_mask = ImageChops.multiply(
                        ImageChops.subtract(blue, red).point(lambda value: 255 if value > 100 else 0),
                        blue.point(lambda value: 255 if value > 150 else 0),
                    )
                    reports.append({"image": image, "red": red_mask, "blue": blue_mask})
                pdf.close()
                return reports, markers

            before_pages, before_markers = render_report(before_pdf)
            self.assertGreaterEqual(len(before_pages), 2)
            self.assertEqual(set(before_markers), {"PREFACE-START", "AFTER-TABLE-MARKER"})
            red_pages = [index for index, page in enumerate(before_pages) if page["red"].getbbox()]
            blue_pages = [index for index, page in enumerate(before_pages) if page["blue"].getbbox()]
            self.assertEqual(len(red_pages), 1, red_pages)
            self.assertEqual(len(blue_pages), 1, blue_pages)
            self.assertEqual(red_pages[0], 0, red_pages)
            self.assertGreater(blue_pages[0], red_pages[0], blue_pages)

            ok, record, errors = register_document("writer", str(path), tmp)
            self.assertTrue(ok, errors)
            ok, result, errors, _ = writer_fill_bookmark(
                record["document_id"], "CellMark", "Old", "multi-anchor-pages", workspace=tmp,
            )
            self.assertTrue(ok, (errors, result))
            after_semantics = docx_body_drawing_semantics(path)
            self.assertEqual(after_semantics, before_semantics)
            self.assertTrue(run_conversion_smoke("writer", str(path), str(after_pdf), "pdf")["ok"])
            after_pages, after_markers = render_report(after_pdf)
            self.assertEqual(len(after_pages), len(before_pages))
            self.assertEqual(after_markers, before_markers)
            for index, (before, after) in enumerate(zip(before_pages, after_pages)):
                self.assertIsNone(ImageChops.difference(before["image"], after["image"]).getbbox(), index)
                self.assertIsNone(ImageChops.difference(before["red"], after["red"]).getbbox(), index)
                self.assertIsNone(ImageChops.difference(before["blue"], after["blue"]).getbbox(), index)

    def test_wps_table_bookmark_preserves_multi_page_anchor_flow(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / "multi-page-flow.docx"
            before_pdf = root / "before-flow.pdf"
            after_pdf = root / "after-flow.pdf"
            write_image_bookmark_document(
                path, anchored=True, image_width_inches=0.9,
                anchor_relative_frames=("column", "paragraph"),
                anchor_offsets_inches=(2.0, 0.0), anchor_wrap="square",
                preamble_paragraphs=36, postamble_paragraphs=36,
            )
            before_semantics = docx_body_drawing_semantics(path)
            self.assertTrue(run_conversion_smoke("writer", str(path), str(before_pdf), "pdf")["ok"])

            def render_report(pdf_path):
                pdf = pypdfium2.PdfDocument(str(pdf_path))
                page_images = []
                markers = {}
                for page_index in range(len(pdf)):
                    page = pdf[page_index]
                    page_images.append(page.render(scale=1.5).to_pil().convert("RGB"))
                    text_page = page.get_textpage()
                    text = text_page.get_text_range()
                    for marker in ("PREFACE-START", "AFTER-TABLE-MARKER"):
                        start = text.find(marker)
                        if start >= 0:
                            boxes = [text_page.get_charbox(index) for index in range(start, start + len(marker))]
                            markers[marker] = (
                                page_index,
                                tuple(round(value, 2) for value in (
                                    min(box[0] for box in boxes), min(box[1] for box in boxes),
                                    max(box[2] for box in boxes), max(box[3] for box in boxes),
                                )),
                            )
                pdf.close()
                return page_images, markers

            before_pages, before_markers = render_report(before_pdf)
            self.assertGreaterEqual(len(before_pages), 2)
            self.assertEqual(set(before_markers), {"PREFACE-START", "AFTER-TABLE-MARKER"})
            ok, record, errors = register_document("writer", str(path), tmp)
            self.assertTrue(ok, errors)
            ok, result, errors, _ = writer_fill_bookmark(
                record["document_id"], "CellMark", "Old", "multi-page-flow", workspace=tmp,
            )
            self.assertTrue(ok, (errors, result))
            self.assertEqual(docx_body_drawing_semantics(path), before_semantics)
            self.assertTrue(run_conversion_smoke("writer", str(path), str(after_pdf), "pdf")["ok"])
            after_pages, after_markers = render_report(after_pdf)
            self.assertEqual(len(after_pages), len(before_pages))
            self.assertEqual(after_markers, before_markers)
            for index, (before, after) in enumerate(zip(before_pages, after_pages)):
                self.assertEqual(before.size, after.size, index)
                self.assertIsNone(ImageChops.difference(before, after).getbbox(), index)

    def test_wps_table_bookmark_preserves_wrapping_and_edge_clipping(self):
        variants = (
            ("cell_left_none", False, ("column", "paragraph"), (0.0, 0.0), "none", 0.5),
            ("cell_right_square_crop", True, ("column", "paragraph"), (8.5, 0.0), "square", 1.5),
            ("cell_left_negative_crop", True, ("column", "paragraph"), (-0.5, 0.0), "square", 1.5),
            ("cell_middle_top_bottom", False, ("column", "paragraph"), (2.5, 0.0), "top_and_bottom", 1.0),
            ("page_top_left_negative", True, ("page", "page"), (-0.5, -0.25), "square", 1.5),
        )

        def after_word_bounds(pdf_path):
            pdf_doc = pypdfium2.PdfDocument(str(pdf_path))
            text_page = pdf_doc[0].get_textpage()
            text = text_page.get_text_range()
            start = text.find("After")
            self.assertGreaterEqual(start, 0, text)
            boxes = [text_page.get_charbox(index) for index in range(start, start + 5)]
            pdf_doc.close()
            return tuple(round(value, 2) for value in (
                min(box[0] for box in boxes), min(box[1] for box in boxes),
                max(box[2] for box in boxes), max(box[3] for box in boxes),
            ))

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name, cropped, frames, offsets, wrap, width in variants:
                with self.subTest(variant=name):
                    path = root / f"wrap-{name}.docx"
                    before_pdf = root / f"before-{name}.pdf"
                    after_pdf = root / f"after-{name}.pdf"
                    write_image_bookmark_document(
                        path, anchored=True, cropped=cropped, image_width_inches=width,
                        anchor_relative_frames=frames, anchor_offsets_inches=offsets,
                        anchor_wrap=wrap,
                        layout_in_cell="0" if name == "page_top_left_negative" else "1",
                    )
                    before_semantics = docx_body_drawing_semantics(path)
                    self.assertEqual(before_semantics["unresolved_drawings"], [])
                    self.assertTrue(run_conversion_smoke("writer", str(path), str(before_pdf), "pdf")["ok"])
                    before_pdf_doc = pypdfium2.PdfDocument(str(before_pdf))
                    before = before_pdf_doc[0].render(scale=2).to_pil().convert("RGB")
                    before_pdf_doc.close()
                    before_text_bounds = after_word_bounds(before_pdf)

                    ok, record, errors = register_document("writer", str(path), tmp)
                    self.assertTrue(ok, errors)
                    ok, result, errors, _ = writer_fill_bookmark(
                        record["document_id"], "CellMark", "Old", f"wrap-edge-{name}", workspace=tmp,
                    )
                    self.assertTrue(ok, (errors, result))
                    self.assertEqual(docx_body_drawing_semantics(path), before_semantics)
                    self.assertTrue(run_conversion_smoke("writer", str(path), str(after_pdf), "pdf")["ok"])
                    after_pdf_doc = pypdfium2.PdfDocument(str(after_pdf))
                    after = after_pdf_doc[0].render(scale=2).to_pil().convert("RGB")
                    after_pdf_doc.close()
                    self.assertEqual(after_word_bounds(after_pdf), before_text_bounds)

                    def blue_mask(image):
                        red, green, blue = image.split()
                        return ImageChops.multiply(
                            ImageChops.subtract(blue, red).point(lambda value: 255 if value > 100 else 0),
                            blue.point(lambda value: 255 if value > 150 else 0),
                        )

                    before_mask, after_mask = blue_mask(before), blue_mask(after)
                    visible = before_mask.getbbox()
                    self.assertIsNotNone(visible)
                    self.assertIsNone(ImageChops.difference(before_mask, after_mask).getbbox())
                    if name == "cell_right_square_crop":
                        self.assertGreater(visible[2], round(before.width * 0.8), visible)
                    if name == "cell_left_negative_crop":
                        self.assertLess(visible[0], round(before.width * 0.2), visible)
                    if name == "page_top_left_negative":
                        self.assertEqual(visible[0], 0, visible)
                        self.assertEqual(visible[1], 0, visible)
                        self.assertLess(visible[2] - visible[0], round(width * 144) - 20, visible)
                        self.assertLess(visible[3] - visible[1], round(width * 96) - 20, visible)
                    if name in {"cell_right_square_crop", "cell_left_negative_crop"}:
                        self.assertLessEqual(
                            abs((visible[2] - visible[0]) - round(width * 144)), 3, visible,
                        )
                    if name == "page_top_left_negative":
                        self.assertLessEqual(abs((visible[2] - visible[0]) - 144), 3, visible)
                        self.assertLessEqual(abs((visible[3] - visible[1]) - 108), 3, visible)

    def test_wps_table_bookmark_anchor_reference_frames_keep_rendered_edges(self):
        variants = (
            ("column_paragraph", ("column", "paragraph"), (0.0, 0.0)),
            ("page_page", ("page", "page"), (0.0, 0.0)),
        )
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name, frames, offsets in variants:
                with self.subTest(variant=name):
                    path = root / f"anchor-{name}.docx"
                    before_pdf = root / f"before-{name}.pdf"
                    after_pdf = root / f"after-{name}.pdf"
                    write_image_bookmark_document(
                        path, anchored=True, image_width_inches=0.5,
                        anchor_relative_frames=frames, anchor_offsets_inches=offsets,
                    )
                    before_semantics = docx_body_drawing_semantics(path)
                    self.assertEqual(before_semantics["unresolved_drawings"], [])
                    self.assertEqual(
                        before_semantics["drawings"][0]["structure"]["children"][1]["attributes"]["relativeFrom"],
                        frames[0],
                    )
                    self.assertTrue(run_conversion_smoke("writer", str(path), str(before_pdf), "pdf")["ok"])
                    before_pdf_doc = pypdfium2.PdfDocument(str(before_pdf))
                    self.assertEqual(len(before_pdf_doc), 1)
                    before = before_pdf_doc[0].render(scale=2).to_pil().convert("RGB")
                    before_pdf_doc.close()

                    ok, record, errors = register_document("writer", str(path), tmp)
                    self.assertTrue(ok, errors)
                    ok, result, errors, _ = writer_fill_bookmark(
                        record["document_id"], "CellMark", "New", f"anchor-frame-{name}", workspace=tmp,
                    )
                    self.assertTrue(ok, (errors, result))
                    after_semantics = docx_body_drawing_semantics(path)
                    self.assertEqual(after_semantics, before_semantics)
                    self.assertTrue(run_conversion_smoke("writer", str(path), str(after_pdf), "pdf")["ok"])
                    after_pdf_doc = pypdfium2.PdfDocument(str(after_pdf))
                    self.assertEqual(len(after_pdf_doc), 1)
                    after = after_pdf_doc[0].render(scale=2).to_pil().convert("RGB")
                    after_pdf_doc.close()
                    self.assertEqual(before.size, after.size)

                    def blue_mask(image):
                        red, green, blue = image.split()
                        dominant = ImageChops.subtract(blue, red)
                        return ImageChops.multiply(
                            dominant.point(lambda value: 255 if value > 100 else 0),
                            blue.point(lambda value: 255 if value > 150 else 0),
                        )

                    before_mask, after_mask = blue_mask(before), blue_mask(after)
                    self.assertIsNotNone(before_mask.getbbox())
                    self.assertIsNone(ImageChops.difference(before_mask, after_mask).getbbox())
                    if name == "page_page":
                        page_edge = before_mask.getbbox()
                        self.assertGreater(page_edge[0], 0, page_edge)
                        self.assertGreater(page_edge[1], 0, page_edge)

    def test_wps_table_bookmark_float_images_keep_rendered_layout(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / "overlap.docx"
            before_pdf = root / "before.pdf"
            after_pdf = root / "after.pdf"
            write_image_bookmark_document(
                path, image_count=2, anchored=True, image_width_inches=1.5,
                anchor_spacing_inches=0.25,
            )
            before_conversion = run_conversion_smoke("writer", str(path), str(before_pdf), "pdf")
            self.assertTrue(before_conversion["ok"], before_conversion)
            before_identity = file_identity(path)
            before_document = pypdfium2.PdfDocument(str(before_pdf))
            self.assertEqual(len(before_document), 1)
            before_export = before_document[0].render(scale=2).to_pil().convert("RGB")
            before_document.close()
            self.assertEqual(file_identity(path), before_identity)
            ok, record, errors = register_document("writer", str(path), tmp)
            self.assertTrue(ok, errors)
            ok, result, errors, _ = writer_fill_bookmark(
                record["document_id"], "CellMark", "New", "rendered-anchors", workspace=tmp,
            )
            self.assertTrue(ok, (errors, result))
            self.assertNotEqual(file_identity(path), before_identity)
            drawings_after = docx_body_drawing_semantics(path)
            converted = run_conversion_smoke("writer", str(path), str(after_pdf), "pdf")
            self.assertTrue(converted["ok"], converted)
            after_document = pypdfium2.PdfDocument(str(after_pdf))
            self.assertEqual(len(after_document), 1)
            after_export = after_document[0].render(scale=2).to_pil().convert("RGB")
            after_document.close()
            self.assertEqual(before_export.size, after_export.size)

            def color_mask(image, color):
                red, green, blue = image.split()
                if color == "blue":
                    dominant = ImageChops.subtract(blue, red)
                    strength = blue
                else:
                    dominant = ImageChops.subtract(red, blue)
                    strength = red
                return ImageChops.multiply(
                    dominant.point(lambda value: 255 if value > 100 else 0),
                    strength.point(lambda value: 255 if value > 150 else 0),
                )

            blue_before, blue_after = color_mask(before_export, "blue"), color_mask(after_export, "blue")
            red_before, red_after = color_mask(before_export, "red"), color_mask(after_export, "red")
            self.assertIsNone(ImageChops.difference(blue_before, blue_after).getbbox())
            self.assertIsNone(ImageChops.difference(red_before, red_after).getbbox())
            blue_box, red_box = blue_after.getbbox(), red_after.getbbox()
            self.assertIsNotNone(blue_box)
            self.assertIsNotNone(red_box)
            blue_width_emu = int(drawings_after["drawings"][0]["extent"]["cx"])
            blue_logical_right = blue_box[0] + round(blue_width_emu * 144 / 914400)
            overlap_left, overlap_right = max(blue_box[0], red_box[0]), min(blue_logical_right, red_box[2])
            overlap_top, overlap_bottom = max(blue_box[1], red_box[1]), min(blue_box[3], red_box[3])
            self.assertLess(overlap_left, overlap_right, (blue_box, red_box))
            self.assertLess(overlap_top, overlap_bottom, (blue_box, red_box))
            sample = ((overlap_left + overlap_right) // 2, (overlap_top + overlap_bottom) // 2)
            self.assertGreater(red_after.getpixel(sample), 0)
            self.assertEqual(blue_after.getpixel(sample), 0)

    def test_wps_table_bookmark_preserves_adjacent_inline_drawing(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "drawing-neighbor.docx"
            write_image_bookmark_document(path)
            drawings_before = docx_body_drawing_semantics(path)
            self.assertEqual(len(drawings_before["drawings"]), 1)
            self.assertEqual(drawings_before["unresolved_drawings"], [])
            ok, record, errors = register_document("writer", str(path), tmp)
            self.assertTrue(ok, errors)
            ok, result, errors, _ = writer_fill_bookmark(
                record["document_id"], "CellMark", "New", "drawing-neighbor", workspace=tmp,
            )
            self.assertTrue(ok, (errors, result, drawings_before,
                                 drawing_structure_differences(
                                     drawings_before["drawings"][0]["structure"],
                                     docx_body_drawing_semantics(path)["drawings"][0]["structure"],
                                 )))
            self.assertEqual(docx_body_drawing_semantics(path), drawings_before)
            self.assertEqual(read_supported_bookmark_text(path, "CellMark")[1], "New")
            self.assertEqual(len(Document(path).inline_shapes), 1)

    def test_wps_table_bookmark_preserves_anchored_and_multiple_cropped_images(self):
        for variant, options in (
            ("anchored_crop", {"anchored": True, "cropped": True}),
            ("multiple_crop", {"image_count": 2, "cropped": True}),
            ("multiple_anchor_crop", {"image_count": 2, "anchored": True, "cropped": True}),
        ):
            with self.subTest(variant=variant), tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / f"{variant}.docx"
                write_image_bookmark_document(path, **options)
                drawings_before = docx_body_drawing_semantics(path)
                self.assertEqual(drawings_before["unresolved_drawings"], [])
                self.assertEqual(len(drawings_before["drawings"]), options.get("image_count", 1))
                ok, record, errors = register_document("writer", str(path), tmp)
                self.assertTrue(ok, errors)
                ok, result, errors, _ = writer_fill_bookmark(
                    record["document_id"], "CellMark", "New", f"drawing-{variant}", workspace=tmp,
                )
                after = docx_body_drawing_semantics(path)
                self.assertTrue(ok, (errors, result, drawings_before, after))
                self.assertEqual(after, drawings_before)
                self.assertEqual(read_supported_bookmark_text(path, "CellMark")[1], "New")
                expected_type = "anchor" if options.get("anchored") else "inline"
                self.assertEqual([drawing["type"] for drawing in after["drawings"]],
                                 [expected_type] * options.get("image_count", 1))

    def test_wps_table_bookmark_preserves_hyperlink_and_field_neighbors(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "semantic-neighbors.docx"
            document = Document()
            table = document.add_table(rows=1, cols=1)
            paragraph = table.cell(0, 0).paragraphs[0]
            paragraph.add_run("Before ")
            rel_id = paragraph.part.relate_to(
                "https://example.com/audit?source=writer", RT.HYPERLINK, is_external=True,
            )
            hyperlink = OxmlElement("w:hyperlink")
            hyperlink.set(qn("r:id"), rel_id)
            link_run = OxmlElement("w:r")
            link_text = OxmlElement("w:t")
            link_text.text = "LINK"
            link_run.append(link_text)
            hyperlink.append(link_run)
            paragraph._p.append(hyperlink)
            paragraph.add_run(" ")
            old = paragraph.add_run("Old")
            start = OxmlElement("w:bookmarkStart")
            start.set(qn("w:id"), "1")
            start.set(qn("w:name"), "CellMark")
            end = OxmlElement("w:bookmarkEnd")
            end.set(qn("w:id"), "1")
            old._r.addprevious(start)
            old._r.addnext(end)
            paragraph.add_run(" ")
            field = OxmlElement("w:fldSimple")
            field.set(qn("w:instr"), "MERGEFIELD InvoiceCode")
            field_run = OxmlElement("w:r")
            field_text = OxmlElement("w:t")
            field_text.text = "CODE"
            field_run.append(field_text)
            field.append(field_run)
            paragraph._p.append(field)
            paragraph.add_run(" After")
            document.save(path)
            semantics_before = docx_body_link_field_semantics(path)
            self.assertEqual(semantics_before["hyperlinks"][0]["target"],
                             "https://example.com/audit?source=writer")
            self.assertEqual(semantics_before["fields"][0]["instruction_tokens"],
                             ["MERGEFIELD", "InvoiceCode"])
            ok, record, errors = register_document("writer", str(path), tmp)
            self.assertTrue(ok, errors)
            ok, result, errors, _ = writer_fill_bookmark(
                record["document_id"], "CellMark", "New", "semantic-neighbors", workspace=tmp,
            )
            self.assertTrue(ok, (errors, result, semantics_before,
                                 docx_body_link_field_semantics(path)))
            self.assertEqual(docx_body_link_field_semantics(path), semantics_before)
            self.assertEqual(read_supported_bookmark_text(path, "CellMark")[1], "New")
            ok, result, errors, _ = writer_fill_bookmark(
                record["document_id"], "CellMark", "Again", "semantic-neighbors-second", workspace=tmp,
            )
            self.assertTrue(ok, (errors, result))
            self.assertEqual(docx_body_link_field_semantics(path), semantics_before)
            self.assertEqual(read_supported_bookmark_text(path, "CellMark")[1], "Again")

    def test_wps_complex_table_bookmark_topology(self):
        for variant in ("horizontal_merge", "vertical_merge", "multiple_paragraphs", "styled"):
            with self.subTest(variant=variant), tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / f"{variant}.docx"
                document = Document()
                document.add_paragraph("Outside")
                table = document.add_table(rows=2, cols=2)
                if variant == "horizontal_merge":
                    table.cell(0, 0).merge(table.cell(0, 1))
                if variant == "vertical_merge":
                    table.cell(0, 0).merge(table.cell(1, 0))
                if variant == "styled":
                    table.style = "Light Shading Accent 1"
                cell = table.cell(0, 0)
                paragraph = cell.paragraphs[0]
                prefix = paragraph.add_run("Before ")
                old = paragraph.add_run("Old")
                suffix = paragraph.add_run(" After")
                if variant == "styled":
                    prefix.italic = True
                    old.bold = True
                    suffix.italic = True
                start = OxmlElement("w:bookmarkStart")
                start.set(qn("w:id"), "1")
                start.set(qn("w:name"), "CellMark")
                end = OxmlElement("w:bookmarkEnd")
                end.set(qn("w:id"), "1")
                old._r.addprevious(start)
                old._r.addnext(end)
                if variant == "multiple_paragraphs":
                    cell.add_paragraph("Second paragraph")
                if variant != "vertical_merge":
                    table.cell(1, 0).text = "Lower left"
                table.cell(1, 1).text = "Lower right"
                document.save(path)
                topology_before = docx_body_table_topology(path)
                ok, record, errors = register_document("writer", str(path), tmp)
                self.assertTrue(ok, errors)
                ok, result, errors, _ = writer_fill_bookmark(
                    record["document_id"], "CellMark", "New", f"complex-{variant}", workspace=tmp,
                )
                self.assertTrue(ok, (variant, errors, result))
                self.assertEqual(docx_body_table_topology(path), topology_before)
                readback = Document(path)
                self.assertEqual(readback.paragraphs[0].text, "Outside")
                self.assertEqual(readback.tables[0].cell(0, 0).paragraphs[0].text,
                                 "Before New After")
                if variant != "vertical_merge":
                    self.assertEqual(readback.tables[0].cell(1, 0).text, "Lower left")
                self.assertEqual(readback.tables[0].cell(1, 1).text, "Lower right")
                if variant == "multiple_paragraphs":
                    self.assertEqual(readback.tables[0].cell(0, 0).paragraphs[1].text,
                                     "Second paragraph")
                if variant == "styled":
                    self.assertEqual(readback.tables[0].style.name, "Light Shading Accent 1")
                    runs = readback.tables[0].cell(0, 0).paragraphs[0].runs
                    self.assertTrue(any(run.italic and "Before" in run.text for run in runs))
                    self.assertTrue(any(run.italic and "After" in run.text for run in runs))
                    self.assertTrue(any(run.bold and "New" in run.text for run in runs))

    def test_wps_table_cell_bookmark_fill_preserves_neighbors(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "table-bookmark.docx"
            document = Document()
            document.add_paragraph("Outside before")
            table = document.add_table(rows=1, cols=2)
            paragraph = table.cell(0, 0).paragraphs[0]
            paragraph.add_run("Before ")
            old = paragraph.add_run("Old")
            paragraph.add_run(" After")
            start = OxmlElement("w:bookmarkStart")
            start.set(qn("w:id"), "1")
            start.set(qn("w:name"), "CellMark")
            end = OxmlElement("w:bookmarkEnd")
            end.set(qn("w:id"), "1")
            old._r.addprevious(start)
            old._r.addnext(end)
            table.cell(0, 1).text = "Neighbor"
            document.add_paragraph("Outside after")
            document.save(path)

            bookmark, original = read_supported_bookmark_text(path, "CellMark")
            self.assertEqual(original, "Old")
            self.assertTrue(bookmark["text_range_supported"])
            self.assertFalse(bookmark["body_paragraph_range_supported"])
            ok, record, errors = register_document("writer", str(path), tmp)
            self.assertTrue(ok, errors)
            ok, result, errors, replayed = writer_fill_bookmark(
                record["document_id"], "CellMark", "New", "table-public", workspace=tmp,
            )
            self.assertTrue(ok, (errors, result))
            self.assertFalse(replayed)
            self.assertTrue(result["readback_passed"])
            self.assertEqual(result["scope"], "table_cell")
            backup = result["backup"]
            after_bookmark, after_text = read_supported_bookmark_text(path, "CellMark")
            self.assertTrue(after_bookmark["text_range_supported"])
            self.assertEqual(after_text, "New")
            readback = Document(path)
            self.assertEqual([paragraph.text for paragraph in readback.paragraphs],
                             ["Outside before", "Outside after"])
            self.assertEqual(readback.tables[0].cell(0, 0).text, "Before New After")
            self.assertEqual(readback.tables[0].cell(0, 1).text, "Neighbor")
            self.assertEqual(file_identity(Path(backup["backup_path"]))["source_sha256"],
                             backup["source_identity"]["source_sha256"])
            saved_identity = file_identity(path)
            replay_ok, replay_result, replay_errors, replayed = writer_fill_bookmark(
                record["document_id"], "CellMark", "New", "table-public", workspace=tmp,
            )
            self.assertTrue(replay_ok, replay_errors)
            self.assertTrue(replayed)
            self.assertEqual(replay_result, result)
            self.assertEqual(file_identity(path), saved_identity)
            with chdir(tmp):
                output = io.StringIO()
                self.assertEqual(run([
                    "writer-fill-bookmark", "--document-id", record["document_id"],
                    "--bookmark-name", "CellMark", "--text", "New",
                    "--request-id", "table-public",
                ], output_stream=output), 0)
                cli = json.loads(output.getvalue())
                mcp_ok, mcp, mcp_errors = call_mcp_tool("wps_agent_writer_fill_bookmark", {
                    "document_id": record["document_id"], "bookmark_name": "CellMark",
                    "text": "New", "request_id": "table-public",
                })
            self.assertTrue(mcp_ok, mcp_errors)
            self.assertEqual(cli["data"], mcp["response"]["data"])
            self.assertTrue(cli["data"]["readback_passed"])
            self.assertEqual(file_identity(path), saved_identity)
            backed_up, _, backup_errors, _ = create_backup(
                record["document_id"], "table-post-fill-backup", workspace=tmp,
            )
            self.assertTrue(backed_up, backup_errors)


if __name__ == "__main__":
    unittest.main()
