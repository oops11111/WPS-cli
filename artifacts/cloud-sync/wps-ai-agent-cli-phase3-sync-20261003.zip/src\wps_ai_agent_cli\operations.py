from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


OPERATIONS_FILE = "operations.json"


def operations_state_path(workspace: str | Path = ".") -> Path:
    return Path(workspace) / ".wps-agent" / OPERATIONS_FILE


def read_operations(workspace: str | Path = ".") -> dict[str, Any]:
    state_file = operations_state_path(workspace)
    if not state_file.exists():
        return {"operations": {}}
    return json.loads(state_file.read_text(encoding="utf-8"))


def write_operations(state: dict[str, Any], workspace: str | Path = ".") -> None:
    state_file = operations_state_path(workspace)
    state_file.parent.mkdir(parents=True, exist_ok=True)
    state_file.write_text(json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")


def get_operation(request_id: str, workspace: str | Path = ".") -> dict[str, Any] | None:
    state = read_operations(workspace)
    operation = state.get("operations", {}).get(request_id)
    return dict(operation) if operation else None


def list_operations(workspace: str | Path = ".") -> list[dict[str, Any]]:
    state = read_operations(workspace)
    records = [dict(record) for record in state.get("operations", {}).values()]
    return sorted(records, key=lambda item: item.get("recorded_at", ""))


def record_operation(
    request_id: str,
    command: str,
    result: dict[str, Any],
    workspace: str | Path = ".",
) -> dict[str, Any]:
    state = read_operations(workspace)
    record = {
        "request_id": request_id,
        "command": command,
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "result": result,
    }
    state.setdefault("operations", {})[request_id] = record
    write_operations(state, workspace)
    return record
