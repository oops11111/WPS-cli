# 开发任务调度

## 当前执行策略

以阶段目标拆分任务，Phase 0 先跑通技术事实，再用事实收敛 Phase 1 的实现范围。

## Phase 0 当前任务

| ID | 任务 | 状态 | 验收标准 |
| --- | --- | --- | --- |
| P0-001 | 建立项目骨架与 CLI 入口 | done | `python -m wps_ai_agent_cli inspect-env` 可输出 JSON |
| P0-002 | 实现 WPS ProgID 注册检测 | done | 不启动 WPS，仅检测 COM 注册状态 |
| P0-003 | 建立结构化响应模型 | done | 输出含 ok、request_id、backend、summary、validation、errors |
| P0-004 | 建立阶段任务清单与调度命令 | done | `plan` 与 `tasks` 命令可列出阶段任务 |
| P0-005 | 接入最小 COM 原型 | done | Writer、Spreadsheets、Presentation 均已通过 open/save/close |
| P0-006 | 表格公式计算验证样例 | done | raw value `18.0` 与 display text `18` 验证通过 |
| P0-007 | 转换损失矩阵样例 | done | DOCX 到 PDF 样例已记录后端、前提、保留能力与已知损失 |
| P0-008 | Phase 0 可行性报告 | done | 已形成进入 Phase 1 的 conditional go 结论 |

## Phase 1 预备任务

| ID | 任务 | 状态 | 验收标准 |
| --- | --- | --- | --- |
| P1-001 | document_id 会话模型 | done | 文件可注册、查询，并通过稳定 document_id 定位 |
| P1-002 | 修改前强制备份 | done | 已实现 `backup-document`，可按 document_id 创建恢复备份 |
| P1-003 | 请求 ID 与幂等保护 | done | 同一 request_id 重放时返回已记录结果，不重复创建备份 |
| P1-004 | dry-run 预览 | done | `writer-replace --dry-run` 可预览正文匹配数且不修改文件 |
| P1-005 | 基础验证钩子 | done | `validate-document` 支持 Writer 正文文本与 Spreadsheet 单元格值验证 |
| P1-006 | 任务状态台账 | done | `operation` 和 `operations` 可查询 request_id 与历史操作 |
| P1-007 | 批量文件状态报告 | done | `scan-dir` 可输出逐文件组件、大小与注册状态 |
| P1-008 | Phase 1 汇总报告 | done | 已汇总 MVP CLI 能力、已验证命令、剩余缺口与下一步优先级 |
| P1-009 | Writer 范围替换扩展 | done | `writer-replace --paragraph-index` 支持 1-based 段落范围替换，dry-run 与验证范围一致 |
| P1-010 | Spreadsheet 区域读写 | done | A1 范围读取与写入支持备份、COM 写入、读回校验和幂等重放 |
| P1-011 | Presentation 占位符文本替换 | done | 支持演示文稿占位符或文本框替换，并具备备份、验证和幂等 |
| P1-012 | Spreadsheet 公式写入与重算 | done | 支持表格公式写入、触发 WPS 计算，并验证缓存结果 |
| P1-013 | 验证快照扩展 | done | 增加 docx 文本结构、xlsx 公式错误、pptx 文本对象计数等更强验证 |
| P1-014 | 批量执行报告 | done | 合并目录扫描、注册状态和验证快照，输出批量处理报告 |
| P1-015 | 备份清单与恢复 | done | 可按 document_id 列出可恢复备份，并安全恢复指定备份 |
| P1-016 | Phase 1 发布候选审计 | done | 运行最终能力审计，记录剩余缺口并形成 Phase 1 release candidate 报告 |

## Phase 2 当前任务

| ID | 任务 | 状态 | 验收标准 |
| --- | --- | --- | --- |
| P2-001 | 长任务状态模型 | done | 为长时间 WPS 操作建立可复用状态模型，包含进度、终态和恢复建议 |
| P2-002 | 修改命令接入任务状态 | done | 将任务状态创建与终态更新接入选定的 WPS 修改命令，同时保持既有幂等行为 |
| P2-003 | 长任务恢复手册 | done | 为中断、失败和状态不明确的长时间 WPS 操作整理并暴露恢复手册 |
| P2-004 | MCP 工具契约草案 | done | 将当前 CLI 命令映射为可复用的 Agent/MCP 工具契约和示例 |
| P2-005 | MCP adapter 实现 | done | 基于契约草案实现可调用的 MCP adapter 层，并复用现有 CLI 核心逻辑 |
| P2-006 | MCP server 原型 | done | 将 adapter 工具通过标准 MCP-compatible transport 暴露为本地 server 原型 |
| P2-007 | MCP server client 配置与 smoke harness | done | 记录本地 MCP server 客户端配置，并补充 initialize、tools/list、tools/call 可重复 smoke |
| P2-008 | MCP desktop 集成审计 | done | 用桌面客户端配置审计本地 MCP server，记录 transport、路径和环境变量问题 |
| P2-009 | Phase 2 最终交付报告 | done | 汇总 MCP readiness、验证证据、已知边界和后续可选扩展方向 |

## Phase 3 当前任务

| ID | 任务 | 状态 | 验收标准 |
| --- | --- | --- | --- |
| P3-001 | 生产就绪计划与风险清单 | done | 定义 Phase 3 workstreams、风险、验收门槛和首批回归目标 |
| P3-002 | 回归套件 manifest 与 smoke matrix | done | 创建机器可读回归清单，覆盖关键 CLI、MCP 与 WPS smoke 场景 |
| P3-003 | 回归 manifest WPS smoke 执行 | done | 在真实桌面环境运行 WPS-required 回归 profile，记录组件级证据和缺口 |
| P3-004 | 回归结果 artifact 导出 | done | 将 regression-run 输出持久化为带时间戳的 JSON artifact，用于 CI、审计和后续对比 |
| P3-005 | 回归 artifact CI 交接 | done | 记录 CI 调用方式、artifact 留存路径，以及 safe/WPS 回归 profile 的通过门槛 |
| P3-006 | 恢复硬化演练 | done | 定义并执行一次针对中断或失败修改类文档操作的恢复演练，包含恢复证据 |
| P3-007 | 安全边界审计 | done | 审计修改类 CLI 与 MCP 工具的 request_id、dry-run、backup、恢复建议和风险边界 |
| P3-008 | 性能基线采集 | done | 采集核心只读命令和 safe 回归命令的耗时、输出规模和证据，不启动 WPS |
| P3-009 | Desktop MCP 集成证据刷新 | done | 基于当前工具面刷新 MCP desktop 集成证据，覆盖 config audit、tools/list、tools/call 和真实 client 缺口 |
| P3-010 | 高级 WPS 能力定范围 | done | 选择下一个高级 WPS 能力，并在实现前定义 fixture、dry-run、backup、validation 和 smoke 证据要求 |
| P3-011 | Writer 表格单元格更新原型 | done | 实现 Writer 表格单元格更新，包含 fixture、dry-run、backup、读回验证、MCP schema 和 WPS smoke 证据 |
| P3-012 | Writer 表格回归集成 | done | 将 Writer 表格更新纳入回归证据、恢复检查和可重复 WPS smoke 文档，同时避免 safe CI 启动桌面 WPS |
| P3-013 | Spreadsheet WPS calc timeout 调查 | done | 诊断并硬化完整 WPS 回归 profile 暴露出的 spreadsheet calc smoke 超时，同时保留结构化回归 artifact |
| P3-014 | WPS 进程生命周期清理审计 | done | 审计 WPS COM smoke 命令的进程生命周期清理，采集残留进程诊断，并记录不自动杀用户进程的安全清理建议 |
| P3-015 | Phase 3 release readiness 刷新 | done | 刷新 Phase 3 发布就绪证据，总结当前 safe/WPS 回归状态，并列出剩余生产风险和交接步骤 |
| P3-016 | 云端同步就绪交接 | done | 准备将当前本地项目状态同步到云端或远程项目工作区所需的 artifact、证据路径和仓库交接说明 |
| P3-017 | 远程云端目标选择 | next | 选择实际远程或云端项目目标，并按用户选择执行同步路径，例如 Git remote、归档上传或已连接云端工作区 |

进展记录：
- 2026-10-03: P3-004 已为 `regression-run` 增加 `--artifact-dir`，safe profile 生成 `artifacts\regression\regression-run-20261003T063513662051Z-regression-artifact-p3-004-001.json`，报告见 `docs\P3_REGRESSION_ARTIFACT_EXPORT_REPORT.md`。
- 2026-10-03: P3-005 已形成 CI 交接文档，覆盖 safe/WPS 调用命令、artifact 留存路径、通过门槛和失败分诊，见 `docs\REGRESSION_CI_HANDOFF.md`。
- 2026-10-03: P3-006 已执行失败恢复演练，构造 `p3_006_failed_writer_replace` 终态失败任务，验证 `task-recovery`、备份清单和 Writer snapshot 证据，报告见 `docs\P3_RECOVERY_HARDENING_DRILL.md`。
- 2026-10-03: P3-007 已新增 `security-audit`，审计 6 个修改类 MCP/CLI 工具的 request_id、task_id、dry-run、备份和 WPS/文件系统边界，报告见 `docs\P3_SECURITY_BOUNDARY_AUDIT.md`。
- 2026-10-03: P3-008 已新增 `performance-baseline`，采集 6 个不启动 WPS 的核心命令基线，总耗时约 2176ms、总输出约 245KB，报告见 `docs\P3_PERFORMANCE_BASELINE.md`。
- 2026-10-03: P3-009 已刷新 MCP desktop/config 集成证据，`mcp-config-audit` 与 `mcp-smoke --tool-name wps_agent_security_audit` 均通过 38-tool 工具面；同时修复 smoke harness 对无参工具的参数假设，报告见 `docs\P3_DESKTOP_MCP_INTEGRATION_REFRESH.md`。
- 2026-10-03: P3-010 已选择 Writer 表格单元格更新作为下一个高级能力，并定义 fixture、dry-run、backup、validation、MCP 和 WPS smoke 要求，见 `docs\P3_ADVANCED_WPS_CAPABILITY_SCOPE.md`。
- 2026-10-03: P3-011 已实现 `writer-table-write` 与 `wps_agent_writer_table_write`，真实 WPS 写入 `FINAL_STATUS` 通过备份、COM 写入、读回验证和幂等重放；报告见 `docs\P3_WRITER_TABLE_WRITE_REPORT.md`。
- 2026-10-03: P3-012 已新增 `writer-table-smoke` 与 `wps_agent_writer_table_smoke`，并将 Writer 表格更新纳入 WPS regression profile；safe profile 仍不启动 WPS，完整 WPS profile 结构化记录了既有 `spreadsheet-calc-smoke` timeout，报告见 `docs\P3_WRITER_TABLE_REGRESSION_INTEGRATION_REPORT.md`。
- 2026-10-03: P3-013 已定位 `spreadsheet-calc-smoke` timeout 与固定输出文件覆盖/提示等待有关；已增加结构化 COM timeout、`--timeout-seconds`、同路径保护、保存前关闭 alerts 并删除既有输出，完整 WPS profile 4/4 通过，报告见 `docs\P3_SPREADSHEET_CALC_TIMEOUT_HARDENING_REPORT.md`。
- 2026-10-03: P3-014 已新增只读 `wps-process-audit` / `wps_agent_wps_process_audit`，采集当前 WPS 相关进程并给出不自动 kill 用户进程的安全清理建议；报告见 `docs\P3_WPS_PROCESS_LIFECYCLE_AUDIT_REPORT.md`。
- 2026-10-03: P3-015 已刷新 Phase 3 release readiness，记录 93 个单元测试、safe regression 6/6、WPS regression 4/4、41-tool MCP 工具面和剩余风险；报告见 `docs\PHASE3_RELEASE_READINESS_REFRESH.md`。
- 2026-10-03: P3-016 已完成云端同步就绪交接，列出推荐同步范围、排除项、验证命令、最新 artifact 和可选远程目标路径；报告见 `docs\CLOUD_SYNC_READINESS_HANDOFF.md`。

## 每轮开发节奏

1. 选取一个阶段任务。
2. 明确输入、输出、错误码和验证方法。
3. 先写最小测试，再实现命令或核心逻辑。
4. 在真实 WPS 环境中补充实测记录。
5. 更新任务状态和版本矩阵。

## 最新实测证据

- 2026-10-02: WPS Writer `kwps.Application` 已通过 PowerShell COM fallback 完成打开 PRD、保存副本、关闭。
- 2026-10-02: WPS Spreadsheets `ket.Application` 已通过 PowerShell COM fallback 完成打开测试工作簿、保存副本、关闭。
- 2026-10-02: WPS Presentation `kwpp.Application` 已通过 PowerShell COM fallback 完成打开测试演示、保存副本、关闭。
- 2026-10-02: WPS Spreadsheets 公式计算验证通过，`D4 = B4 + C4`，raw value `18.0`，display text `18`。
- 2026-10-02: WPS Writer DOCX 到 PDF 转换验证通过，使用 `ExportAsFixedFormat`，输出 5 页 PDF。
- 2026-10-02: Phase 0 可行性报告完成，建议 Phase 1 以核心 CLI 和验证闭环为范围 conditional go。
- 2026-10-02: Phase 1 已实现 `register-document`、`documents`、`backup-document`，并验证备份幂等重放。
- 2026-10-02: Phase 1 已实现 `writer-replace`，支持正文范围 dry-run、强制备份、WPS COM 替换、结果验证和 request_id 幂等重放。
- 2026-10-02: Phase 1 已实现 `validate-document`，Writer 正文文本和 Spreadsheet 单元格值验证均已通过真实文件验证。
- 2026-10-02: Phase 1 已实现 `operation` 与 `operations`，可查询 request_id 对应操作结果和历史操作列表。
- 2026-10-02: Phase 1 已实现 `scan-dir`，可扫描目录并标注支持文件的组件与注册状态。
- 2026-10-02: Phase 1 MVP 汇总报告完成，记录当前能力边界与下一优先级。
- 2026-10-02: Phase 1 已实现段落范围 Writer 替换，`--paragraph-index 1` 实测通过并支持幂等重放。
- 2026-10-03: Phase 1 已实现 Spreadsheet A1 范围读取与写入，`A8:B9` 真实 WPS COM 写入、读回校验、备份和幂等重放均已通过。
- 2026-10-03: Phase 1 已实现 Presentation 文本替换，真实 WPS COM 将标题替换为 `Phase 1 presentation replace verified`，备份、读回校验和幂等重放均已通过。
- 2026-10-03: Phase 1 已实现 Spreadsheet 公式写入与重算，真实 WPS COM 写入 `E4:E6` 公式并读回缓存值 `[77, 40, 117]`，备份和幂等重放均已通过。
- 2026-10-03: Phase 1 已实现 `snapshot-document`，真实 Writer、Spreadsheet、Presentation 文件均已输出结构快照；同时修复 Windows GBK 控制台无法输出特殊字符 JSON 的问题。
- 2026-10-03: Phase 1 已实现 `batch-report`，`fixtures/phase0` 实测返回 6 个支持文件、2 个已注册文件快照、4 个未注册跳过项，快照失败数为 0。
- 2026-10-03: Phase 1 已实现 `list-backups` 与 `restore-backup`，探针文件真实恢复验证通过；恢复前会自动创建 pre-restore 备份，并支持 request_id 幂等重放。
- 2026-10-03: Phase 1 release candidate 审计完成，`docs/PHASE1_RELEASE_CANDIDATE_REPORT.md` 已记录最终能力、证据、边界与 Phase 2 建议入口。
- 2026-10-03: Phase 2 已实现长任务状态模型，`task-status-create/update/task-status/task-statuses` 实测通过 pending → running → succeeded 生命周期、进度、终态和 result_ref。
- 2026-10-03: Phase 2 已将 `--task-id` 接入选定修改命令，真实 `spreadsheet-write` 实测同时完成 WPS 写入、operation 记录和 task status succeeded 终态。
- 2026-10-03: Phase 2 已实现 `task-recovery` 与 `task-recovery-playbooks`，覆盖 succeeded、failed、cancelled、pending、interrupted_or_running、ambiguous_missing_status 恢复场景；真实 `task_sheet_write_tracked_001` 与缺失任务探针均已输出结构化恢复手册。
- 2026-10-03: Phase 2 已实现 `mcp-tools` 与 `mcp-tool-schema`，当前 31 个 CLI 命令均映射为 MCP 工具契约草案，包含输入 schema、输出契约、WPS 依赖、修改属性和 CLI 示例；草案记录见 `docs/MCP_TOOL_SCHEMA_DRAFT.md`。
- 2026-10-03: Phase 2 已实现 `mcp-call` 本地 adapter，支持 schema 查找、JSON 参数校验、CLI argv 映射、底层 `CommandResponse` 捕获和递归保护；`wps_agent_tasks` 实测通过 adapter 调用现有 `tasks` response 层。
- 2026-10-03: Phase 2 已实现 `mcp-server` JSON-RPC/stdio 原型，支持 `initialize`、`tools/list` 和 `tools/call`；`tools/list` 当前返回 32 个工具，`tools/call` 已通过 server → adapter → CLI response 调用 `wps_agent_tasks`。
- 2026-10-03: Phase 2 已实现 `mcp-smoke` 可重复 smoke harness，覆盖 initialize、tools/list、tools/call，并新增 `config/mcp_client_config.example.json` 与 `docs/MCP_SERVER_CLIENT_CONFIG.md`；Phase 2 当时 `tools/list` 返回 38 个工具，P3-014 后当前工具面为 41 个工具。
- 2026-10-03: Phase 2 已实现 `mcp-config-audit`，通过 `config/mcp_client_config.example.json` 校验 config、cwd、Python command、PYTHONPATH、args 和 configured `tools/list` smoke；Phase 2 当时 `tools/list` 返回 38 个工具，P3-014 后当前工具面为 41 个工具。
- 2026-10-03: Phase 2 最终交付报告完成，详见 `docs/PHASE2_FINAL_HANDOFF_REPORT.md`。
- 2026-10-03: Phase 3 已启动，`docs/PHASE3_PRODUCTION_READINESS_PLAN.md` 记录生产就绪 workstreams、风险清单、验收门槛和首个回归 manifest 任务。
- 2026-10-03: Phase 3 已实现 `config/regression_manifest.json`、`regression-manifest` 与 `regression-run`，safe profile 覆盖 5 个 CLI/MCP/config smoke 场景并实测通过；WPS profile 已列入 manifest，默认不执行以避免意外启动桌面 WPS。
- 2026-10-03: Phase 3 已运行 WPS-required regression profile，`writer-com-smoke`、`spreadsheet-calc-smoke`、`writer-convert-smoke` 均 passed；输出文件位于 `fixtures/phase3`，报告见 `docs/P3_WPS_REGRESSION_SMOKE_REPORT.md`。
- 生成文件: `smoke_writer_copy.docx`、`fixtures/phase0/phase0_calculation_fixture_copy.xlsx`、`fixtures/phase0/phase0_presentation_fixture_copy.pptx`、`fixtures/phase0/phase0_calculation_verified.xlsx`
- 详细记录: `docs/PHASE0_FINDINGS.md`、`docs/CONVERSION_MATRIX.md`、`docs/PHASE0_FEASIBILITY_REPORT.md`
