from __future__ import annotations

import argparse
import json
import sys
from uuid import uuid4

from .artifacts import write_json_artifact
from .backups import create_backup, list_backups, restore_backup
from .batch_report import build_batch_report
from .capabilities import probe_wps_capabilities
from .com_backend import run_com_smoke, run_conversion_smoke, run_spreadsheet_calc_smoke
from .file_scan import scan_directory
from .jsonio import dumps_json
from .mcp_adapter import call_mcp_tool
from .mcp_config_audit import audit_mcp_client_config
from .mcp_schema import get_mcp_tool_schema, list_mcp_tool_categories, list_mcp_tool_schemas
from .mcp_server import handle_mcp_json, serve_stdio
from .mcp_smoke import run_mcp_server_smoke
from .models import CommandResponse, ValidationResult
from .operations import get_operation, list_operations
from .phases import list_phases
from .performance import capture_performance_baseline
from .process_audit import audit_wps_processes
from .presentation_ops import presentation_replace
from .regression import load_regression_manifest, list_regression_scenarios, run_regression_manifest
from .security_audit import build_security_boundary_audit
from .sessions import list_documents, register_document
from .snapshots import snapshot_document
from .spreadsheet_ops import read_spreadsheet_range, write_spreadsheet_formulas, write_spreadsheet_range
from .task_status import (
    build_recovery_playbook,
    create_task_status,
    get_task_status,
    list_recovery_playbooks,
    list_task_statuses,
    update_task_status,
)
from .tasks import list_tasks
from .validators import validate_document
from .writer_ops import writer_replace, writer_table_write
from .writer_table_smoke import run_writer_table_smoke


BACKEND = "local-python"


def _configure_stdout() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def _request_id(value: str | None) -> str:
    return value or str(uuid4())


def _extract_request_id(argv: list[str]) -> tuple[list[str], str | None]:
    cleaned: list[str] = []
    request_id = None
    index = 0
    while index < len(argv):
        item = argv[index]
        if item == "--request-id":
            if index + 1 >= len(argv):
                cleaned.append(item)
            else:
                request_id = argv[index + 1]
                index += 1
        elif item.startswith("--request-id="):
            request_id = item.split("=", 1)[1]
        else:
            cleaned.append(item)
        index += 1
    return cleaned, request_id


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wps-agent",
        description="Agent-friendly CLI for WPS feasibility validation and automation.",
    )
    parser.add_argument("--request-id", help="Stable request id for idempotent agent calls.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("inspect-env", help="Inspect OS, pywin32, and WPS ProgID registration.")
    process_audit_parser = subparsers.add_parser(
        "wps-process-audit",
        help="List WPS-related processes and safe cleanup guidance without terminating anything.",
    )
    process_audit_parser.add_argument("--timeout-seconds", type=int, default=10, help="Timeout for process inspection.")
    subparsers.add_parser("plan", help="Return the staged development roadmap.")

    tasks_parser = subparsers.add_parser("tasks", help="Return staged development tasks.")
    tasks_parser.add_argument("--phase", help="Filter by phase id, for example phase0.")
    tasks_parser.add_argument("--status", help="Filter by task status, for example next.")

    smoke_parser = subparsers.add_parser(
        "com-smoke",
        help="Run the Phase 0 minimal COM open/save/close prototype.",
    )
    smoke_parser.add_argument(
        "--component",
        choices=["writer", "spreadsheets", "presentation"],
        required=True,
        help="WPS component to exercise.",
    )
    smoke_parser.add_argument("--input", required=True, help="Input document path.")
    smoke_parser.add_argument("--output", required=True, help="Output copy path.")
    smoke_parser.add_argument("--visible", action="store_true", help="Show WPS during the smoke run.")

    calc_parser = subparsers.add_parser(
        "calc-smoke",
        help="Run the Phase 0 WPS spreadsheet formula calculation verification.",
    )
    calc_parser.add_argument("--input", required=True, help="Input workbook path.")
    calc_parser.add_argument("--output", required=True, help="Output workbook copy path.")
    calc_parser.add_argument("--timeout-seconds", type=int, default=120, help="Timeout for the WPS spreadsheet COM smoke.")

    convert_parser = subparsers.add_parser(
        "convert-smoke",
        help="Run a Phase 0 WPS conversion smoke test.",
    )
    convert_parser.add_argument("--component", choices=["writer"], required=True)
    convert_parser.add_argument("--input", required=True, help="Input file path.")
    convert_parser.add_argument("--output", required=True, help="Output file path.")
    convert_parser.add_argument("--format", choices=["pdf"], required=True, help="Output format.")

    writer_table_smoke_parser = subparsers.add_parser(
        "writer-table-smoke",
        help="Run a repeatable WPS Writer table cell update smoke test against an output copy.",
    )
    writer_table_smoke_parser.add_argument("--input", required=True, help="Input Writer fixture path.")
    writer_table_smoke_parser.add_argument("--output", required=True, help="Output copy path.")
    writer_table_smoke_parser.add_argument("--table-index", type=int, required=True, help="1-based table index.")
    writer_table_smoke_parser.add_argument("--row", type=int, required=True, help="1-based row index.")
    writer_table_smoke_parser.add_argument("--column", type=int, required=True, help="1-based column index.")
    writer_table_smoke_parser.add_argument("--text", required=True, help="Replacement cell text.")
    writer_table_smoke_parser.add_argument("--task-id", help="Optional long-running task status id to update.")

    register_parser = subparsers.add_parser(
        "register-document",
        help="Register a file and return a stable document_id for later commands.",
    )
    register_parser.add_argument(
        "--component",
        choices=["writer", "spreadsheets", "presentation"],
        required=True,
    )
    register_parser.add_argument("--path", required=True, help="Document path to register.")

    subparsers.add_parser("documents", help="List registered documents.")

    backup_parser = subparsers.add_parser(
        "backup-document",
        help="Create a recoverable backup for a registered document_id.",
    )
    backup_parser.add_argument("--document-id", required=True, help="Registered document_id.")
    backup_parser.add_argument("--dry-run", action="store_true", help="Preview backup path without copying.")
    backup_parser.add_argument("--task-id", help="Optional long-running task status id to update.")

    list_backups_parser = subparsers.add_parser(
        "list-backups",
        help="List recoverable backups, optionally scoped to one document_id.",
    )
    list_backups_parser.add_argument("--document-id", help="Optional registered document_id.")

    restore_backup_parser = subparsers.add_parser(
        "restore-backup",
        help="Restore a selected backup after first protecting the current file.",
    )
    restore_backup_parser.add_argument("--document-id", required=True, help="Registered document_id.")
    backup_selector = restore_backup_parser.add_mutually_exclusive_group(required=True)
    backup_selector.add_argument("--backup-name", help="Backup filename from list-backups.")
    backup_selector.add_argument("--backup-path", help="Backup path from list-backups.")
    restore_backup_parser.add_argument("--dry-run", action="store_true", help="Preview restore without copying.")
    restore_backup_parser.add_argument("--task-id", help="Optional long-running task status id to update.")

    replace_parser = subparsers.add_parser(
        "writer-replace",
        help="Replace text in a registered WPS Writer document with backup, dry-run, and validation.",
    )
    replace_parser.add_argument("--document-id", required=True, help="Registered writer document_id.")
    replace_parser.add_argument("--find", required=True, help="Text to find.")
    replace_parser.add_argument("--replace", required=True, help="Replacement text.")
    replace_parser.add_argument("--dry-run", action="store_true", help="Preview matches without modifying the file.")
    replace_parser.add_argument(
        "--paragraph-index",
        type=int,
        help="Optional 1-based body paragraph index to limit replacement scope.",
    )
    replace_parser.add_argument("--task-id", help="Optional long-running task status id to update.")

    writer_table_parser = subparsers.add_parser(
        "writer-table-write",
        help="Write text to a table cell in a registered WPS Writer document.",
    )
    writer_table_parser.add_argument("--document-id", required=True, help="Registered writer document_id.")
    writer_table_parser.add_argument("--table-index", type=int, required=True, help="1-based table index.")
    writer_table_parser.add_argument("--row", type=int, required=True, help="1-based row index.")
    writer_table_parser.add_argument("--column", type=int, required=True, help="1-based column index.")
    writer_table_parser.add_argument("--text", required=True, help="Replacement cell text.")
    writer_table_parser.add_argument("--dry-run", action="store_true", help="Preview target cell without modifying the file.")
    writer_table_parser.add_argument("--task-id", help="Optional long-running task status id to update.")

    validate_parser = subparsers.add_parser(
        "validate-document",
        help="Run basic validation checks against a registered document.",
    )
    validate_parser.add_argument("--document-id", required=True, help="Registered document_id.")
    validate_parser.add_argument("--contains", help="Expected body text for writer documents.")
    validate_parser.add_argument("--cell", help="Cell address for spreadsheet validation.")
    validate_parser.add_argument("--equals", help="Expected cell value for spreadsheet validation.")

    snapshot_parser = subparsers.add_parser(
        "snapshot-document",
        help="Return a structural validation snapshot for a registered document.",
    )
    snapshot_parser.add_argument("--document-id", required=True, help="Registered document_id.")

    operation_parser = subparsers.add_parser(
        "operation",
        help="Return a recorded operation by request_id.",
    )
    operation_parser.add_argument("--request", required=True, help="Recorded operation request_id.")

    subparsers.add_parser("operations", help="List recorded operations.")

    task_status_create_parser = subparsers.add_parser(
        "task-status-create",
        help="Create a reusable status record for a long-running task.",
    )
    task_status_create_parser.add_argument("--task-id", help="Optional stable task id.")
    task_status_create_parser.add_argument(
        "--command",
        dest="tracked_command",
        required=True,
        help="Command or workflow being tracked.",
    )
    task_status_create_parser.add_argument("--operation-request-id", required=True, help="Request id for the tracked operation.")
    task_status_create_parser.add_argument("--document-id", help="Optional related document_id.")
    task_status_create_parser.add_argument("--message", help="Initial status message.")
    task_status_create_parser.add_argument(
        "--recovery-guidance",
        action="append",
        default=[],
        help="Recovery guidance item. May be provided more than once.",
    )

    task_status_update_parser = subparsers.add_parser(
        "task-status-update",
        help="Update a long-running task status record.",
    )
    task_status_update_parser.add_argument("--task-id", required=True, help="Task id to update.")
    task_status_update_parser.add_argument(
        "--state",
        choices=["pending", "running", "succeeded", "failed", "cancelled"],
        required=True,
        help="New task state.",
    )
    task_status_update_parser.add_argument("--progress-percent", type=int, help="Progress percentage, 0 through 100.")
    task_status_update_parser.add_argument("--message", help="Updated status message.")
    task_status_update_parser.add_argument(
        "--recovery-guidance",
        action="append",
        help="Recovery guidance item. May be provided more than once.",
    )
    task_status_update_parser.add_argument("--result-ref", help="Optional operation request id or output reference.")

    task_status_parser = subparsers.add_parser(
        "task-status",
        help="Return one long-running task status record.",
    )
    task_status_parser.add_argument("--task-id", required=True, help="Task id to return.")

    subparsers.add_parser("task-statuses", help="List long-running task status records.")

    task_recovery_parser = subparsers.add_parser(
        "task-recovery",
        help="Return a recovery playbook for a long-running task status.",
    )
    task_recovery_parser.add_argument("--task-id", required=True, help="Task id to recover or inspect.")

    subparsers.add_parser(
        "task-recovery-playbooks",
        help="List available long-running task recovery playbooks.",
    )

    mcp_tools_parser = subparsers.add_parser(
        "mcp-tools",
        help="List draft MCP tool schemas mapped from CLI commands.",
    )
    mcp_tools_parser.add_argument("--category", help="Optional tool category filter.")
    mcp_tools_parser.add_argument(
        "--mutates-document",
        choices=["true", "false"],
        help="Optional filter for document-mutating tools.",
    )

    mcp_tool_schema_parser = subparsers.add_parser(
        "mcp-tool-schema",
        help="Return one draft MCP tool schema by MCP tool name or CLI command.",
    )
    mcp_tool_schema_parser.add_argument("--name", required=True, help="MCP tool name or CLI command.")

    mcp_call_parser = subparsers.add_parser(
        "mcp-call",
        help="Invoke a draft MCP tool through the local adapter layer.",
    )
    mcp_call_parser.add_argument("--name", required=True, help="MCP tool name or CLI command.")
    mcp_call_parser.add_argument(
        "--arguments-json",
        default="{}",
        help="JSON object of tool arguments.",
    )

    mcp_server_parser = subparsers.add_parser(
        "mcp-server",
        help="Run the local MCP-compatible JSON-RPC server prototype over stdio.",
    )
    mcp_server_parser.add_argument(
        "--once-json",
        help="Handle one JSON-RPC request and exit; useful for tests and smoke checks.",
    )

    mcp_smoke_parser = subparsers.add_parser(
        "mcp-smoke",
        help="Run repeatable MCP server smoke checks for initialize, tools/list, and tools/call.",
    )
    mcp_smoke_parser.add_argument(
        "--expected-min-tools",
        type=int,
        default=1,
        help="Minimum number of tools expected from tools/list.",
    )
    mcp_smoke_parser.add_argument(
        "--tool-name",
        default="wps_agent_tasks",
        help="Tool name to exercise through tools/call.",
    )

    mcp_config_audit_parser = subparsers.add_parser(
        "mcp-config-audit",
        help="Audit a local MCP client config and run a configured tools/list smoke check.",
    )
    mcp_config_audit_parser.add_argument(
        "--config",
        default="config/mcp_client_config.example.json",
        help="Path to MCP client config JSON.",
    )
    mcp_config_audit_parser.add_argument(
        "--server-name",
        default="wps-ai-agent-cli",
        help="Server key under mcpServers.",
    )
    mcp_config_audit_parser.add_argument(
        "--expected-min-tools",
        type=int,
        default=33,
        help="Minimum number of tools expected from configured tools/list smoke.",
    )
    mcp_config_audit_parser.add_argument(
        "--timeout-seconds",
        type=int,
        default=15,
        help="Timeout for the configured tools/list smoke.",
    )

    regression_manifest_parser = subparsers.add_parser(
        "regression-manifest",
        help="List regression manifest scenarios and smoke matrix metadata.",
    )
    regression_manifest_parser.add_argument(
        "--manifest",
        default="config/regression_manifest.json",
        help="Path to regression manifest JSON.",
    )
    regression_manifest_parser.add_argument("--profile", help="Optional scenario profile filter, for example safe or wps.")
    regression_manifest_parser.add_argument("--include-wps", action="store_true", help="Include scenarios that require WPS.")

    regression_run_parser = subparsers.add_parser(
        "regression-run",
        help="Run regression scenarios from the manifest.",
    )
    regression_run_parser.add_argument(
        "--manifest",
        default="config/regression_manifest.json",
        help="Path to regression manifest JSON.",
    )
    regression_run_parser.add_argument("--profile", help="Optional scenario profile filter. Defaults to manifest default_profile.")
    regression_run_parser.add_argument("--include-wps", action="store_true", help="Include scenarios that require WPS.")
    regression_run_parser.add_argument(
        "--artifact-dir",
        help="Optional directory where a timestamped regression-run JSON artifact will be written.",
    )

    subparsers.add_parser(
        "security-audit",
        help="Audit mutating CLI and MCP tool safety boundaries.",
    )

    subparsers.add_parser(
        "performance-baseline",
        help="Capture runtime and output-size baselines for safe read-only commands.",
    )

    scan_parser = subparsers.add_parser(
        "scan-dir",
        help="Scan a directory for supported WPS files and registration status.",
    )
    scan_parser.add_argument("--path", required=True, help="Directory to scan.")
    scan_parser.add_argument("--recursive", action="store_true", help="Scan recursively.")

    batch_report_parser = subparsers.add_parser(
        "batch-report",
        help="Combine directory scan, registration status, and validation snapshots.",
    )
    batch_report_parser.add_argument("--path", required=True, help="Directory to report on.")
    batch_report_parser.add_argument("--recursive", action="store_true", help="Report recursively.")
    batch_report_parser.add_argument(
        "--no-snapshots",
        action="store_true",
        help="Skip validation snapshots and only return scan and registration status.",
    )

    spreadsheet_read_parser = subparsers.add_parser(
        "spreadsheet-read",
        help="Read an A1 range from a registered spreadsheet document.",
    )
    spreadsheet_read_parser.add_argument("--document-id", required=True, help="Registered spreadsheet document_id.")
    spreadsheet_read_parser.add_argument("--range", required=True, help="A1 range to read, for example A1:D6.")
    spreadsheet_read_parser.add_argument("--sheet", help="Optional sheet name. Defaults to first sheet.")

    spreadsheet_write_parser = subparsers.add_parser(
        "spreadsheet-write",
        help="Write a JSON matrix to an A1 range in a registered spreadsheet document.",
    )
    spreadsheet_write_parser.add_argument("--document-id", required=True, help="Registered spreadsheet document_id.")
    spreadsheet_write_parser.add_argument("--range", required=True, help="A1 range to write, for example A1:B2.")
    spreadsheet_write_parser.add_argument("--values-json", required=True, help="Rectangular JSON matrix, for example [[1,2],[3,4]].")
    spreadsheet_write_parser.add_argument("--sheet", help="Optional sheet name. Defaults to first sheet.")
    spreadsheet_write_parser.add_argument("--dry-run", action="store_true", help="Preview write shape without modifying the file.")
    spreadsheet_write_parser.add_argument("--task-id", help="Optional long-running task status id to update.")

    spreadsheet_formula_parser = subparsers.add_parser(
        "spreadsheet-formula-write",
        help="Write formulas to an A1 range, recalculate with WPS, and validate cached values.",
    )
    spreadsheet_formula_parser.add_argument("--document-id", required=True, help="Registered spreadsheet document_id.")
    spreadsheet_formula_parser.add_argument("--range", required=True, help="A1 range to write, for example D4:D6.")
    spreadsheet_formula_parser.add_argument("--formulas-json", required=True, help="Rectangular JSON matrix of formulas, for example [[\"=A1+B1\"]].")
    spreadsheet_formula_parser.add_argument("--expected-values-json", required=True, help="Rectangular JSON matrix of expected cached values.")
    spreadsheet_formula_parser.add_argument("--sheet", help="Optional sheet name. Defaults to first sheet.")
    spreadsheet_formula_parser.add_argument("--dry-run", action="store_true", help="Preview formula write shape without modifying the file.")
    spreadsheet_formula_parser.add_argument("--task-id", help="Optional long-running task status id to update.")

    presentation_replace_parser = subparsers.add_parser(
        "presentation-replace",
        help="Replace text in a registered presentation with backup, validation, and idempotency.",
    )
    presentation_replace_parser.add_argument("--document-id", required=True, help="Registered presentation document_id.")
    presentation_replace_parser.add_argument("--find", required=True, help="Text to find.")
    presentation_replace_parser.add_argument("--replace", required=True, help="Replacement text.")
    presentation_replace_parser.add_argument("--dry-run", action="store_true", help="Preview matches without modifying the file.")
    presentation_replace_parser.add_argument(
        "--slide-index",
        type=int,
        help="Optional 1-based slide index to limit replacement scope.",
    )
    presentation_replace_parser.add_argument("--task-id", help="Optional long-running task status id to update.")

    return parser


def inspect_env_response(request_id: str) -> CommandResponse:
    data = probe_wps_capabilities()
    checks = [
        {
            "name": "windows_host",
            "passed": data["platform"]["is_windows"],
            "details": data["platform"]["system"],
        },
        {
            "name": "pywin32_available",
            "passed": data["dependencies"]["pywin32_available"],
            "details": "required for COM integration",
        },
    ]
    for name, component in data["components"].items():
        checks.append(
            {
                "name": f"{name}_prog_id_registered",
                "passed": component["detected"],
                "details": component["selected_prog_id"],
            }
        )

    passed_count = sum(1 for check in checks if check["passed"])
    status = "passed" if passed_count == len(checks) else "warning"
    return CommandResponse(
        ok=True,
        command="inspect-env",
        request_id=request_id,
        backend=BACKEND,
        summary="Environment capability probe completed.",
        data=data,
        validation=ValidationResult(status=status, checks=checks),
    )


def wps_process_audit_response(request_id: str, timeout_seconds: int) -> CommandResponse:
    ok, result, errors = audit_wps_processes(timeout_seconds=timeout_seconds)
    return CommandResponse(
        ok=ok,
        command="wps-process-audit",
        request_id=request_id,
        backend=BACKEND,
        summary="WPS process audit completed." if ok else "WPS process audit failed.",
        data={"wps_process_audit": result},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "process_scan_completed",
                    "passed": ok,
                    "details": result.get("process_count"),
                },
                {
                    "name": "no_automatic_process_kill",
                    "passed": True,
                    "details": "Read-only process audit.",
                },
            ],
        ),
        errors=errors,
    )


def plan_response(request_id: str) -> CommandResponse:
    return CommandResponse(
        ok=True,
        command="plan",
        request_id=request_id,
        backend=BACKEND,
        summary="Development roadmap loaded from PRD v1.1 phase goals.",
        data={"phases": list_phases()},
        validation=ValidationResult(status="not_applicable"),
    )


def tasks_response(request_id: str, phase: str | None, status: str | None) -> CommandResponse:
    tasks = list_tasks(phase=phase, status=status)
    return CommandResponse(
        ok=True,
        command="tasks",
        request_id=request_id,
        backend=BACKEND,
        summary=f"Returned {len(tasks)} development tasks.",
        data={"tasks": tasks, "filters": {"phase": phase, "status": status}},
        validation=ValidationResult(status="not_applicable"),
    )


def com_smoke_response(
    request_id: str,
    component: str,
    input_path: str,
    output_path: str,
    visible: bool,
) -> CommandResponse:
    result = run_com_smoke(
        component=component,
        input_path=input_path,
        output_path=output_path,
        visible=visible,
    )
    return CommandResponse(
        ok=result["ok"],
        command="com-smoke",
        request_id=request_id,
        backend="wps-com",
        summary=(
            "Minimal COM smoke run completed."
            if result["ok"]
            else "Minimal COM smoke run could not complete."
        ),
        data=result["data"],
        validation=ValidationResult(
            status="passed" if result["ok"] else "failed",
            checks=[
                {
                    "name": "open_save_close",
                    "passed": result["ok"],
                    "details": component,
                }
            ],
        ),
        errors=result["errors"],
    )


def calc_smoke_response(request_id: str, input_path: str, output_path: str, timeout_seconds: int = 120) -> CommandResponse:
    result = run_spreadsheet_calc_smoke(
        input_path=input_path,
        output_path=output_path,
        timeout_seconds=timeout_seconds,
    )
    checks = [
        {
            "name": "formula_raw_value",
            "passed": result["ok"],
            "details": result["data"].get("raw_value") if result["data"] else None,
        },
        {
            "name": "formula_display_text",
            "passed": result["ok"],
            "details": result["data"].get("display_text") if result["data"] else None,
        },
    ]
    return CommandResponse(
        ok=result["ok"],
        command="calc-smoke",
        request_id=request_id,
        backend="wps-com",
        summary=(
            "Spreadsheet calculation smoke run completed."
            if result["ok"]
            else "Spreadsheet calculation smoke run could not complete."
        ),
        data=result["data"],
        validation=ValidationResult(status="passed" if result["ok"] else "failed", checks=checks),
        errors=result["errors"],
    )


def convert_smoke_response(
    request_id: str,
    component: str,
    input_path: str,
    output_path: str,
    output_format: str,
) -> CommandResponse:
    result = run_conversion_smoke(
        component=component,
        input_path=input_path,
        output_path=output_path,
        output_format=output_format,
    )
    return CommandResponse(
        ok=result["ok"],
        command="convert-smoke",
        request_id=request_id,
        backend="wps-com",
        summary=(
            "Conversion smoke run completed."
            if result["ok"]
            else "Conversion smoke run could not complete."
        ),
        data=result["data"],
        validation=ValidationResult(
            status="passed" if result["ok"] else "failed",
            checks=[
                {
                    "name": "output_file_created",
                    "passed": result["ok"],
                    "details": result["data"].get("output_path") if result["data"] else None,
                },
                {
                    "name": "output_file_non_empty",
                    "passed": result["ok"],
                    "details": result["data"].get("output_bytes") if result["data"] else None,
                },
            ],
        ),
        errors=result["errors"],
    )


def writer_table_smoke_response(
    request_id: str,
    input_path: str,
    output_path: str,
    table_index: int,
    row: int,
    column: int,
    text: str,
) -> CommandResponse:
    result = run_writer_table_smoke(
        input_path=input_path,
        output_path=output_path,
        table_index=table_index,
        row=row,
        column=column,
        text=text,
        request_id=request_id,
    )
    data = result["data"]
    return CommandResponse(
        ok=result["ok"],
        command="writer-table-smoke",
        request_id=request_id,
        backend="wps-com",
        summary=(
            "Writer table smoke run completed."
            if result["ok"]
            else "Writer table smoke run could not complete."
        ),
        data=data,
        validation=ValidationResult(
            status="passed" if result["ok"] else "failed",
            checks=[
                {
                    "name": "output_file_created",
                    "passed": bool(data.get("output_bytes")),
                    "details": data.get("output_path"),
                },
                {
                    "name": "writer_table_validated",
                    "passed": bool(data.get("writer_table", {}).get("validation_passed")),
                    "details": data.get("writer_table", {}).get("read_back_text"),
                },
                {
                    "name": "backup_available",
                    "passed": bool(data.get("backup_exists")),
                    "details": data.get("writer_table", {}).get("backup", {}).get("backup_path"),
                },
                {
                    "name": "restore_dry_run_available",
                    "passed": bool(data.get("restore_check", {}).get("ok")),
                    "details": data.get("restore_check", {}).get("result", {}).get("backup_name"),
                },
            ],
        ),
        errors=result["errors"],
    )


def register_document_response(request_id: str, component: str, path: str) -> CommandResponse:
    ok, record, errors = register_document(component=component, path=path)
    return CommandResponse(
        ok=ok,
        command="register-document",
        request_id=request_id,
        backend=BACKEND,
        summary="Document registered." if ok else "Document could not be registered.",
        data={"document": record} if record else {},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "document_path_exists",
                    "passed": ok,
                    "details": record.get("path") if record else path,
                }
            ],
        ),
        errors=errors,
    )


def documents_response(request_id: str) -> CommandResponse:
    documents = list_documents()
    return CommandResponse(
        ok=True,
        command="documents",
        request_id=request_id,
        backend=BACKEND,
        summary=f"Returned {len(documents)} registered documents.",
        data={"documents": documents},
        validation=ValidationResult(status="not_applicable"),
    )


def backup_document_response(request_id: str, document_id: str, dry_run: bool) -> CommandResponse:
    ok, result, errors, replayed = create_backup(
        document_id=document_id,
        request_id=request_id,
        dry_run=dry_run,
    )
    return CommandResponse(
        ok=ok,
        command="backup-document",
        request_id=request_id,
        backend=BACKEND,
        summary=(
            "Backup request replayed from idempotency record."
            if replayed
            else "Backup dry-run completed."
            if dry_run and ok
            else "Backup created."
            if ok
            else "Backup could not be created."
        ),
        data=result,
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "document_registered",
                    "passed": ok,
                    "details": document_id,
                },
                {
                    "name": "backup_created",
                    "passed": bool(result.get("created") or dry_run or replayed),
                    "details": result.get("backup_path"),
                },
            ],
        ),
        errors=errors,
    )


def list_backups_response(request_id: str, document_id: str | None) -> CommandResponse:
    ok, result, errors = list_backups(document_id=document_id)
    return CommandResponse(
        ok=ok,
        command="list-backups",
        request_id=request_id,
        backend=BACKEND,
        summary=(
            f"Returned {result.get('count', 0)} backups."
            if ok
            else "Backup inventory failed."
        ),
        data=result,
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "backups_listed",
                    "passed": ok,
                    "details": {
                        "document_id": document_id,
                        "count": result.get("count"),
                    },
                }
            ],
        ),
        errors=errors,
    )


def restore_backup_response(
    request_id: str,
    document_id: str,
    backup_name: str | None,
    backup_path: str | None,
    dry_run: bool,
) -> CommandResponse:
    ok, result, errors, replayed = restore_backup(
        document_id=document_id,
        request_id=request_id,
        backup_name=backup_name,
        backup_path=backup_path,
        dry_run=dry_run,
    )
    return CommandResponse(
        ok=ok,
        command="restore-backup",
        request_id=request_id,
        backend=BACKEND,
        summary=(
            "Restore request replayed from idempotency record."
            if replayed
            else "Restore dry-run completed."
            if dry_run and ok
            else "Backup restored."
            if ok
            else "Backup restore failed."
        ),
        data=result,
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "backup_selected",
                    "passed": ok,
                    "details": result.get("backup_path"),
                },
                {
                    "name": "pre_restore_backup_created",
                    "passed": bool(dry_run or replayed or result.get("pre_restore_backup", {}).get("created")),
                    "details": result.get("pre_restore_backup", {}).get("backup_path"),
                },
                {
                    "name": "target_restored",
                    "passed": bool(dry_run or replayed or result.get("restored")),
                    "details": result.get("target_path"),
                },
            ],
        ),
        errors=errors,
    )


def writer_replace_response(
    request_id: str,
    document_id: str,
    find_text: str,
    replace_text: str,
    dry_run: bool,
    paragraph_index: int | None,
) -> CommandResponse:
    ok, result, errors, replayed = writer_replace(
        document_id=document_id,
        find_text=find_text,
        replace_text=replace_text,
        request_id=request_id,
        dry_run=dry_run,
        paragraph_index=paragraph_index,
    )
    return CommandResponse(
        ok=ok,
        command="writer-replace",
        request_id=request_id,
        backend="wps-com" if not dry_run else BACKEND,
        summary=(
            "Writer replace request replayed from idempotency record."
            if replayed
            else "Writer replace dry-run completed."
            if dry_run and ok
            else "Writer replace completed."
            if ok
            else "Writer replace could not complete."
        ),
        data=result,
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "matches_found",
                    "passed": bool(result.get("matches", 0) > 0),
                    "details": result.get("matches"),
                },
                {
                    "name": "backup_created",
                    "passed": bool(dry_run or result.get("backup", {}).get("created")),
                    "details": result.get("backup", {}).get("backup_path"),
                },
                {
                    "name": "replacement_validated",
                    "passed": bool(dry_run or result.get("validation_passed")),
                    "details": {
                        "remaining_find_count": result.get("remaining_find_count"),
                        "replace_count_delta": result.get("replace_count_delta"),
                    },
                },
            ],
        ),
        errors=errors,
    )


def writer_table_write_response(
    request_id: str,
    document_id: str,
    table_index: int,
    row: int,
    column: int,
    text: str,
    dry_run: bool,
) -> CommandResponse:
    ok, result, errors, replayed = writer_table_write(
        document_id=document_id,
        table_index=table_index,
        row=row,
        column=column,
        text=text,
        request_id=request_id,
        dry_run=dry_run,
    )
    return CommandResponse(
        ok=ok,
        command="writer-table-write",
        request_id=request_id,
        backend="wps-com" if not dry_run else BACKEND,
        summary=(
            "Writer table write request replayed from idempotency record."
            if replayed
            else "Writer table write dry-run completed."
            if dry_run and ok
            else "Writer table write completed."
            if ok
            else "Writer table write could not complete."
        ),
        data=result,
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "table_cell_found",
                    "passed": ok,
                    "details": {
                        "table_index": table_index,
                        "row": row,
                        "column": column,
                        "current_text": result.get("current_text"),
                    },
                },
                {
                    "name": "backup_created",
                    "passed": bool(dry_run or result.get("backup", {}).get("created") or replayed),
                    "details": result.get("backup", {}).get("backup_path"),
                },
                {
                    "name": "cell_write_validated",
                    "passed": bool(dry_run or result.get("validation_passed") or replayed),
                    "details": {
                        "read_back_text": result.get("read_back_text"),
                        "replacement_text": result.get("replacement_text"),
                    },
                },
            ],
        ),
        errors=errors,
    )


def validate_document_response(
    request_id: str,
    document_id: str,
    contains: str | None,
    cell: str | None,
    equals: str | None,
) -> CommandResponse:
    ok, result, errors = validate_document(
        document_id=document_id,
        contains=contains,
        cell=cell,
        equals=equals,
    )
    component = result.get("component")
    checks = []
    if component == "writer":
        checks.append(
            {
                "name": "body_text_contains",
                "passed": ok,
                "details": {"text": contains, "count": result.get("count")},
            }
        )
    elif component == "spreadsheets":
        checks.append(
            {
                "name": "cell_value_equals",
                "passed": ok,
                "details": {
                    "cell": cell,
                    "expected": equals,
                    "actual": result.get("actual"),
                },
            }
        )
    else:
        checks.append({"name": "validation_supported", "passed": ok, "details": component})

    return CommandResponse(
        ok=ok,
        command="validate-document",
        request_id=request_id,
        backend=BACKEND,
        summary="Document validation completed." if ok else "Document validation failed.",
        data=result,
        validation=ValidationResult(status="passed" if ok else "failed", checks=checks),
        errors=errors,
    )


def snapshot_document_response(request_id: str, document_id: str) -> CommandResponse:
    ok, result, errors = snapshot_document(document_id=document_id)
    component = result.get("component")
    checks = []
    if component == "writer":
        checks.append(
            {
                "name": "writer_text_structure_snapshotted",
                "passed": ok,
                "details": {
                    "paragraph_count": result.get("paragraph_count"),
                    "non_empty_paragraph_count": result.get("non_empty_paragraph_count"),
                },
            }
        )
    elif component == "spreadsheets":
        checks.append(
            {
                "name": "spreadsheet_formula_errors_scanned",
                "passed": ok,
                "details": {
                    "sheet_count": result.get("sheet_count"),
                    "formula_count": result.get("formula_count"),
                    "formula_error_count": result.get("formula_error_count"),
                },
            }
        )
    elif component == "presentation":
        checks.append(
            {
                "name": "presentation_text_objects_counted",
                "passed": ok,
                "details": {
                    "slide_count": result.get("slide_count"),
                    "text_object_count": result.get("text_object_count"),
                    "non_empty_text_object_count": result.get("non_empty_text_object_count"),
                },
            }
        )
    else:
        checks.append({"name": "snapshot_supported", "passed": ok, "details": component})

    return CommandResponse(
        ok=ok,
        command="snapshot-document",
        request_id=request_id,
        backend=BACKEND,
        summary="Document snapshot returned." if ok else "Document snapshot failed.",
        data=result,
        validation=ValidationResult(status="passed" if ok else "failed", checks=checks),
        errors=errors,
    )


def operation_response(request_id: str, operation_request_id: str) -> CommandResponse:
    operation = get_operation(operation_request_id)
    ok = operation is not None
    return CommandResponse(
        ok=ok,
        command="operation",
        request_id=request_id,
        backend=BACKEND,
        summary="Operation returned." if ok else "Operation not found.",
        data={"operation": operation} if operation else {},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "operation_exists",
                    "passed": ok,
                    "details": operation_request_id,
                }
            ],
        ),
        errors=[] if ok else [{"code": "OPERATION_NOT_FOUND", "message": f"Operation not found: {operation_request_id}"}],
    )


def operations_response(request_id: str) -> CommandResponse:
    operations = list_operations()
    return CommandResponse(
        ok=True,
        command="operations",
        request_id=request_id,
        backend=BACKEND,
        summary=f"Returned {len(operations)} recorded operations.",
        data={"operations": operations},
        validation=ValidationResult(status="not_applicable"),
    )


def task_status_create_response(
    request_id: str,
    task_id: str | None,
    command: str,
    operation_request_id: str,
    document_id: str | None,
    message: str | None,
    recovery_guidance: list[str],
) -> CommandResponse:
    ok, result, errors, replayed = create_task_status(
        task_id=task_id,
        command=command,
        request_id=operation_request_id,
        document_id=document_id,
        message=message,
        recovery_guidance=recovery_guidance,
    )
    return CommandResponse(
        ok=ok,
        command="task-status-create",
        request_id=request_id,
        backend=BACKEND,
        summary=(
            "Task status replayed from existing task_id."
            if replayed
            else "Task status created."
            if ok
            else "Task status create failed."
        ),
        data={"task_status": result},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "task_status_created",
                    "passed": ok,
                    "details": {
                        "task_id": result.get("task_id"),
                        "state": result.get("state"),
                        "terminal": result.get("terminal"),
                    },
                }
            ],
        ),
        errors=errors,
    )


def task_status_update_response(
    request_id: str,
    task_id: str,
    state: str,
    progress_percent: int | None,
    message: str | None,
    recovery_guidance: list[str] | None,
    result_ref: str | None,
) -> CommandResponse:
    ok, result, errors = update_task_status(
        task_id=task_id,
        state_value=state,
        progress_percent=progress_percent,
        message=message,
        recovery_guidance=recovery_guidance,
        result_ref=result_ref,
    )
    return CommandResponse(
        ok=ok,
        command="task-status-update",
        request_id=request_id,
        backend=BACKEND,
        summary="Task status updated." if ok else "Task status update failed.",
        data={"task_status": result},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "task_status_updated",
                    "passed": ok,
                    "details": {
                        "task_id": result.get("task_id"),
                        "state": result.get("state"),
                        "progress_percent": result.get("progress_percent"),
                        "terminal": result.get("terminal"),
                    },
                }
            ],
        ),
        errors=errors,
    )


def task_status_response(request_id: str, task_id: str) -> CommandResponse:
    result = get_task_status(task_id)
    ok = result is not None
    return CommandResponse(
        ok=ok,
        command="task-status",
        request_id=request_id,
        backend=BACKEND,
        summary="Task status returned." if ok else "Task status not found.",
        data={"task_status": result} if result else {},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[{"name": "task_status_exists", "passed": ok, "details": task_id}],
        ),
        errors=[] if ok else [{"code": "TASK_STATUS_NOT_FOUND", "message": f"Task status not found: {task_id}"}],
    )


def task_statuses_response(request_id: str) -> CommandResponse:
    statuses = list_task_statuses()
    return CommandResponse(
        ok=True,
        command="task-statuses",
        request_id=request_id,
        backend=BACKEND,
        summary=f"Returned {len(statuses)} task statuses.",
        data={"task_statuses": statuses},
        validation=ValidationResult(status="not_applicable"),
    )


def task_recovery_response(request_id: str, task_id: str) -> CommandResponse:
    playbook = build_recovery_playbook(task_id)
    evidence = playbook.get("evidence", {})
    found = bool(evidence.get("task_status_found"))
    return CommandResponse(
        ok=True,
        command="task-recovery",
        request_id=request_id,
        backend=BACKEND,
        summary=(
            f"Recovery playbook returned for {task_id}."
            if found
            else f"Recovery playbook returned for missing task status {task_id}."
        ),
        data={"recovery_playbook": playbook},
        validation=ValidationResult(
            status="passed" if found else "warning",
            checks=[
                {
                    "name": "task_status_found",
                    "passed": found,
                    "details": {
                        "task_id": task_id,
                        "scenario": playbook.get("scenario"),
                    },
                }
            ],
        ),
    )


def task_recovery_playbooks_response(request_id: str) -> CommandResponse:
    playbooks = list_recovery_playbooks()
    return CommandResponse(
        ok=True,
        command="task-recovery-playbooks",
        request_id=request_id,
        backend=BACKEND,
        summary=f"Returned {len(playbooks)} recovery playbooks.",
        data={"recovery_playbooks": playbooks},
        validation=ValidationResult(status="not_applicable"),
    )


def mcp_tools_response(
    request_id: str,
    category: str | None = None,
    mutates_document: str | None = None,
) -> CommandResponse:
    mutates_filter = None
    if mutates_document == "true":
        mutates_filter = True
    elif mutates_document == "false":
        mutates_filter = False
    tools = list_mcp_tool_schemas(category=category, mutates_document=mutates_filter)
    return CommandResponse(
        ok=True,
        command="mcp-tools",
        request_id=request_id,
        backend=BACKEND,
        summary=f"Returned {len(tools)} draft MCP tool schemas.",
        data={
            "schema_version": tools[0]["schema_version"] if tools else None,
            "categories": list_mcp_tool_categories(),
            "filters": {
                "category": category,
                "mutates_document": mutates_filter,
            },
            "tools": tools,
        },
        validation=ValidationResult(status="not_applicable"),
    )


def mcp_tool_schema_response(request_id: str, name: str) -> CommandResponse:
    schema = get_mcp_tool_schema(name)
    ok = schema is not None
    return CommandResponse(
        ok=ok,
        command="mcp-tool-schema",
        request_id=request_id,
        backend=BACKEND,
        summary="MCP tool schema returned." if ok else "MCP tool schema not found.",
        data={"tool": schema} if schema else {},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[{"name": "mcp_tool_schema_exists", "passed": ok, "details": name}],
        ),
        errors=[] if ok else [{"code": "MCP_TOOL_SCHEMA_NOT_FOUND", "message": f"MCP tool schema not found: {name}"}],
    )


def mcp_call_response(request_id: str, name: str, arguments_json: str) -> CommandResponse:
    try:
        arguments = json.loads(arguments_json)
    except json.JSONDecodeError as exc:
        return CommandResponse(
            ok=False,
            command="mcp-call",
            request_id=request_id,
            backend=BACKEND,
            summary="MCP call failed because arguments_json was not valid JSON.",
            data={"tool_name": name},
            validation=ValidationResult(
                status="failed",
                checks=[{"name": "arguments_json_valid", "passed": False, "details": str(exc)}],
            ),
            errors=[{"code": "INVALID_ARGUMENTS_JSON", "message": str(exc)}],
        )
    if not isinstance(arguments, dict):
        return CommandResponse(
            ok=False,
            command="mcp-call",
            request_id=request_id,
            backend=BACKEND,
            summary="MCP call failed because arguments_json must be an object.",
            data={"tool_name": name},
            validation=ValidationResult(
                status="failed",
                checks=[{"name": "arguments_json_object", "passed": False, "details": type(arguments).__name__}],
            ),
            errors=[{"code": "INVALID_ARGUMENTS_JSON_TYPE", "message": "arguments_json must decode to an object."}],
        )

    ok, result, errors = call_mcp_tool(name, arguments)
    return CommandResponse(
        ok=ok,
        command="mcp-call",
        request_id=request_id,
        backend=BACKEND,
        summary="MCP adapter call completed." if ok else "MCP adapter call failed.",
        data={"mcp_call": result},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "mcp_adapter_call",
                    "passed": ok,
                    "details": {
                        "tool_name": name,
                        "cli_command": result.get("cli_command"),
                        "exit_code": result.get("exit_code"),
                    },
                }
            ],
        ),
        errors=errors,
    )


def mcp_smoke_response(request_id: str, expected_min_tools: int, tool_name: str) -> CommandResponse:
    ok, result, errors = run_mcp_server_smoke(
        expected_min_tools=expected_min_tools,
        tool_name=tool_name,
    )
    return CommandResponse(
        ok=ok,
        command="mcp-smoke",
        request_id=request_id,
        backend=BACKEND,
        summary="MCP server smoke checks passed." if ok else "MCP server smoke checks failed.",
        data={"mcp_smoke": result},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=result.get("checks", []),
        ),
        errors=errors,
    )


def mcp_config_audit_response(
    request_id: str,
    config_path: str,
    server_name: str,
    expected_min_tools: int,
    timeout_seconds: int,
) -> CommandResponse:
    ok, result, errors = audit_mcp_client_config(
        config_path=config_path,
        server_name=server_name,
        expected_min_tools=expected_min_tools,
        timeout_seconds=timeout_seconds,
    )
    return CommandResponse(
        ok=ok,
        command="mcp-config-audit",
        request_id=request_id,
        backend=BACKEND,
        summary="MCP client config audit passed." if ok else "MCP client config audit failed.",
        data={"mcp_config_audit": result},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=result.get("checks", []),
        ),
        errors=errors,
    )


def regression_manifest_response(
    request_id: str,
    manifest_path: str,
    profile: str | None,
    include_wps: bool,
) -> CommandResponse:
    ok, manifest, errors = load_regression_manifest(manifest_path)
    scenarios = list_regression_scenarios(manifest, profile=profile, include_wps=include_wps) if ok else []
    return CommandResponse(
        ok=ok,
        command="regression-manifest",
        request_id=request_id,
        backend=BACKEND,
        summary=f"Returned {len(scenarios)} regression scenarios." if ok else "Regression manifest could not be loaded.",
        data={
            "manifest_path": manifest_path,
            "version": manifest.get("version") if ok else None,
            "default_profile": manifest.get("default_profile") if ok else None,
            "filters": {"profile": profile, "include_wps": include_wps},
            "scenarios": scenarios,
        },
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[{"name": "manifest_loaded", "passed": ok, "details": manifest_path}],
        ),
        errors=errors,
    )


def regression_run_response(
    request_id: str,
    manifest_path: str,
    profile: str | None,
    include_wps: bool,
    artifact_dir: str | None = None,
) -> CommandResponse:
    ok, result, errors = run_regression_manifest(
        manifest_path=manifest_path,
        profile=profile,
        include_wps=include_wps,
    )
    response = CommandResponse(
        ok=ok,
        command="regression-run",
        request_id=request_id,
        backend=BACKEND,
        summary="Regression scenarios passed." if ok else "Regression scenarios failed.",
        data={"regression": result},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "regression_scenarios_passed",
                    "passed": ok,
                    "details": {
                        "scenario_count": result.get("scenario_count"),
                        "passed_count": result.get("passed_count"),
                        "failed_count": result.get("failed_count"),
                    },
                }
            ],
        ),
        errors=errors,
    )
    if artifact_dir:
        response_payload = response.to_dict()
        artifact = write_json_artifact(
            response_payload,
            artifact_dir=artifact_dir,
            prefix="regression-run",
            request_id=request_id,
        )
        response_payload["data"]["artifact"] = artifact
        return CommandResponse(
            ok=response.ok,
            command=response.command,
            request_id=response.request_id,
            backend=response.backend,
            summary=f"{response.summary} Artifact written.",
            data=response_payload["data"],
            validation=response.validation,
            errors=response.errors,
        )
    return response


def security_audit_response(request_id: str) -> CommandResponse:
    ok, result, errors = build_security_boundary_audit()
    return CommandResponse(
        ok=ok,
        command="security-audit",
        request_id=request_id,
        backend=BACKEND,
        summary="Security boundary audit passed." if ok else "Security boundary audit failed.",
        data={"security_audit": result},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "mutating_tool_boundaries",
                    "passed": ok,
                    "details": {
                        "mutating_tool_count": result.get("mutating_tool_count"),
                        "passed_tool_count": result.get("passed_tool_count"),
                        "failed_tool_count": result.get("failed_tool_count"),
                    },
                }
            ],
        ),
        errors=errors,
    )


def performance_baseline_response(request_id: str) -> CommandResponse:
    ok, result, errors = capture_performance_baseline()
    return CommandResponse(
        ok=ok,
        command="performance-baseline",
        request_id=request_id,
        backend=BACKEND,
        summary="Performance baseline captured." if ok else "Performance baseline failed.",
        data={"performance_baseline": result},
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "baseline_commands_passed",
                    "passed": ok,
                    "details": {
                        "scenario_count": result.get("scenario_count"),
                        "passed_count": result.get("passed_count"),
                        "failed_count": result.get("failed_count"),
                    },
                },
                {
                    "name": "wps_not_launched",
                    "passed": not result.get("launches_wps", True),
                    "details": {"launches_wps": result.get("launches_wps")},
                },
            ],
        ),
        errors=errors,
    )


def _with_optional_task_status(
    response_factory,
    task_id: str | None,
    tracked_command: str,
    operation_request_id: str,
    document_id: str | None = None,
) -> CommandResponse:
    if not task_id:
        return response_factory()

    _ok, status, _errors, _replayed = create_task_status(
        task_id=task_id,
        command=tracked_command,
        request_id=operation_request_id,
        document_id=document_id,
        message=f"{tracked_command} queued.",
        recovery_guidance=[
            "Run task-status with this task_id before retrying.",
            "Check operation by request_id if the command reached a terminal state.",
        ],
    )
    if not status.get("terminal"):
        update_task_status(
            task_id,
            "running",
            progress_percent=10,
            message=f"{tracked_command} running.",
        )

    response = response_factory()
    current_status = get_task_status(task_id)
    if current_status and not current_status.get("terminal"):
        update_task_status(
            task_id,
            "succeeded" if response.ok else "failed",
            message=(
                f"{tracked_command} completed."
                if response.ok
                else f"{tracked_command} failed."
            ),
            recovery_guidance=[] if response.ok else [
                "Inspect response errors before retrying.",
                "Run task-status with this task_id to avoid duplicate work.",
            ],
            result_ref=operation_request_id,
        )
        current_status = get_task_status(task_id)
    if current_status:
        response.data["task_status"] = current_status
    return response


def scan_dir_response(request_id: str, path: str, recursive: bool) -> CommandResponse:
    ok, result, errors = scan_directory(path, recursive=recursive)
    return CommandResponse(
        ok=ok,
        command="scan-dir",
        request_id=request_id,
        backend=BACKEND,
        summary=(
            f"Returned {result.get('count', 0)} supported files."
            if ok
            else "Directory scan failed."
        ),
        data=result,
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "directory_scanned",
                    "passed": ok,
                    "details": path,
                }
            ],
        ),
        errors=errors,
    )


def batch_report_response(
    request_id: str,
    path: str,
    recursive: bool,
    include_snapshots: bool,
) -> CommandResponse:
    ok, result, errors = build_batch_report(
        directory=path,
        recursive=recursive,
        include_snapshots=include_snapshots,
    )
    summary = result.get("summary", {})
    return CommandResponse(
        ok=ok,
        command="batch-report",
        request_id=request_id,
        backend=BACKEND,
        summary=(
            f"Batch report returned {summary.get('total_files', 0)} supported files."
            if ok
            else "Batch report failed."
        ),
        data=result,
        validation=ValidationResult(
            status="passed" if ok and not summary.get("snapshot_failed") else "failed",
            checks=[
                {
                    "name": "directory_scanned",
                    "passed": ok,
                    "details": path,
                },
                {
                    "name": "registration_status_included",
                    "passed": ok,
                    "details": {
                        "registered_files": summary.get("registered_files"),
                        "unregistered_files": summary.get("unregistered_files"),
                    },
                },
                {
                    "name": "snapshots_collected",
                    "passed": bool(ok and (not include_snapshots or summary.get("snapshot_failed") == 0)),
                    "details": {
                        "enabled": include_snapshots,
                        "passed": summary.get("snapshot_passed"),
                        "failed": summary.get("snapshot_failed"),
                        "skipped": summary.get("snapshot_skipped"),
                    },
                },
            ],
        ),
        errors=errors,
    )


def spreadsheet_read_response(
    request_id: str,
    document_id: str,
    range_address: str,
    sheet_name: str | None,
) -> CommandResponse:
    ok, result, errors = read_spreadsheet_range(
        document_id=document_id,
        range_address=range_address,
        sheet_name=sheet_name,
    )
    return CommandResponse(
        ok=ok,
        command="spreadsheet-read",
        request_id=request_id,
        backend=BACKEND,
        summary="Spreadsheet range returned." if ok else "Spreadsheet range read failed.",
        data=result,
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "range_read",
                    "passed": ok,
                    "details": {
                        "document_id": document_id,
                        "range": range_address,
                        "sheet": result.get("sheet"),
                    },
                }
            ],
        ),
        errors=errors,
    )


def spreadsheet_write_response(
    request_id: str,
    document_id: str,
    range_address: str,
    values_json: str,
    sheet_name: str | None,
    dry_run: bool,
) -> CommandResponse:
    try:
        values = json.loads(values_json)
    except json.JSONDecodeError as exc:
        return CommandResponse(
            ok=False,
            command="spreadsheet-write",
            request_id=request_id,
            backend=BACKEND,
            summary="Spreadsheet write could not parse values_json.",
            data={},
            validation=ValidationResult(status="failed"),
            errors=[{"code": "INVALID_JSON", "message": str(exc)}],
        )
    ok, result, errors, replayed = write_spreadsheet_range(
        document_id=document_id,
        range_address=range_address,
        values=values,
        request_id=request_id,
        sheet_name=sheet_name,
        dry_run=dry_run,
    )
    return CommandResponse(
        ok=ok,
        command="spreadsheet-write",
        request_id=request_id,
        backend="wps-com" if not dry_run else BACKEND,
        summary=(
            "Spreadsheet write request replayed from idempotency record."
            if replayed
            else "Spreadsheet write dry-run completed."
            if dry_run and ok
            else "Spreadsheet write completed."
            if ok
            else "Spreadsheet write failed."
        ),
        data=result,
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "range_shape_valid",
                    "passed": ok,
                    "details": {
                        "range": range_address,
                        "row_count": result.get("row_count"),
                        "column_count": result.get("column_count"),
                    },
                },
                {
                    "name": "backup_created",
                    "passed": bool(dry_run or result.get("backup", {}).get("created") or replayed),
                    "details": result.get("backup", {}).get("backup_path"),
                },
                {
                    "name": "write_validated",
                    "passed": bool(dry_run or result.get("validation_passed") or replayed),
                    "details": result.get("read_back_values"),
                },
            ],
        ),
        errors=errors,
    )


def spreadsheet_formula_write_response(
    request_id: str,
    document_id: str,
    range_address: str,
    formulas_json: str,
    expected_values_json: str,
    sheet_name: str | None,
    dry_run: bool,
) -> CommandResponse:
    try:
        formulas = json.loads(formulas_json)
        expected_values = json.loads(expected_values_json)
    except json.JSONDecodeError as exc:
        return CommandResponse(
            ok=False,
            command="spreadsheet-formula-write",
            request_id=request_id,
            backend=BACKEND,
            summary="Spreadsheet formula write could not parse JSON arguments.",
            data={},
            validation=ValidationResult(status="failed"),
            errors=[{"code": "INVALID_JSON", "message": str(exc)}],
        )
    ok, result, errors, replayed = write_spreadsheet_formulas(
        document_id=document_id,
        range_address=range_address,
        formulas=formulas,
        expected_values=expected_values,
        request_id=request_id,
        sheet_name=sheet_name,
        dry_run=dry_run,
    )
    return CommandResponse(
        ok=ok,
        command="spreadsheet-formula-write",
        request_id=request_id,
        backend="wps-com" if not dry_run else BACKEND,
        summary=(
            "Spreadsheet formula write request replayed from idempotency record."
            if replayed
            else "Spreadsheet formula write dry-run completed."
            if dry_run and ok
            else "Spreadsheet formula write completed."
            if ok
            else "Spreadsheet formula write failed."
        ),
        data=result,
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "formula_range_shape_valid",
                    "passed": ok,
                    "details": {
                        "range": range_address,
                        "row_count": result.get("row_count"),
                        "column_count": result.get("column_count"),
                    },
                },
                {
                    "name": "backup_created",
                    "passed": bool(dry_run or result.get("backup", {}).get("created") or replayed),
                    "details": result.get("backup", {}).get("backup_path"),
                },
                {
                    "name": "calculation_validated",
                    "passed": bool(dry_run or result.get("validation_passed") or replayed),
                    "details": result.get("read_back_values"),
                },
            ],
        ),
        errors=errors,
    )


def presentation_replace_response(
    request_id: str,
    document_id: str,
    find_text: str,
    replace_text: str,
    dry_run: bool,
    slide_index: int | None,
) -> CommandResponse:
    ok, result, errors, replayed = presentation_replace(
        document_id=document_id,
        find_text=find_text,
        replace_text=replace_text,
        request_id=request_id,
        dry_run=dry_run,
        slide_index=slide_index,
    )
    return CommandResponse(
        ok=ok,
        command="presentation-replace",
        request_id=request_id,
        backend="wps-com" if not dry_run else BACKEND,
        summary=(
            "Presentation replace request replayed from idempotency record."
            if replayed
            else "Presentation replace dry-run completed."
            if dry_run and ok
            else "Presentation replace completed."
            if ok
            else "Presentation replace could not complete."
        ),
        data=result,
        validation=ValidationResult(
            status="passed" if ok else "failed",
            checks=[
                {
                    "name": "matches_found",
                    "passed": bool(result.get("matches", 0) > 0),
                    "details": result.get("matches"),
                },
                {
                    "name": "backup_created",
                    "passed": bool(dry_run or result.get("backup", {}).get("created") or replayed),
                    "details": result.get("backup", {}).get("backup_path"),
                },
                {
                    "name": "replacement_validated",
                    "passed": bool(dry_run or result.get("validation_passed") or replayed),
                    "details": {
                        "remaining_find_count": result.get("remaining_find_count"),
                        "replace_count_delta": result.get("replace_count_delta"),
                    },
                },
            ],
        ),
        errors=errors,
    )


def run(argv: list[str] | None = None) -> int:
    _configure_stdout()
    argv = list(sys.argv[1:] if argv is None else argv)
    argv, extracted_request_id = _extract_request_id(argv)
    parser = build_parser()
    args = parser.parse_args(argv)
    request_id = _request_id(extracted_request_id or args.request_id)

    if args.command == "inspect-env":
        response = inspect_env_response(request_id)
    elif args.command == "wps-process-audit":
        response = wps_process_audit_response(
            request_id,
            timeout_seconds=args.timeout_seconds,
        )
    elif args.command == "plan":
        response = plan_response(request_id)
    elif args.command == "tasks":
        response = tasks_response(request_id, phase=args.phase, status=args.status)
    elif args.command == "com-smoke":
        response = com_smoke_response(
            request_id,
            component=args.component,
            input_path=args.input,
            output_path=args.output,
            visible=args.visible,
        )
    elif args.command == "calc-smoke":
        response = calc_smoke_response(
            request_id,
            input_path=args.input,
            output_path=args.output,
            timeout_seconds=args.timeout_seconds,
        )
    elif args.command == "convert-smoke":
        response = convert_smoke_response(
            request_id,
            component=args.component,
            input_path=args.input,
            output_path=args.output,
            output_format=args.format,
        )
    elif args.command == "writer-table-smoke":
        response = _with_optional_task_status(
            lambda: writer_table_smoke_response(
                request_id,
                input_path=args.input,
                output_path=args.output,
                table_index=args.table_index,
                row=args.row,
                column=args.column,
                text=args.text,
            ),
            task_id=args.task_id,
            tracked_command="writer-table-smoke",
            operation_request_id=request_id,
        )
    elif args.command == "register-document":
        response = register_document_response(
            request_id,
            component=args.component,
            path=args.path,
        )
    elif args.command == "documents":
        response = documents_response(request_id)
    elif args.command == "backup-document":
        response = _with_optional_task_status(
            lambda: backup_document_response(
                request_id,
                document_id=args.document_id,
                dry_run=args.dry_run,
            ),
            task_id=args.task_id,
            tracked_command="backup-document",
            operation_request_id=request_id,
            document_id=args.document_id,
        )
    elif args.command == "list-backups":
        response = list_backups_response(
            request_id,
            document_id=args.document_id,
        )
    elif args.command == "restore-backup":
        response = _with_optional_task_status(
            lambda: restore_backup_response(
                request_id,
                document_id=args.document_id,
                backup_name=args.backup_name,
                backup_path=args.backup_path,
                dry_run=args.dry_run,
            ),
            task_id=args.task_id,
            tracked_command="restore-backup",
            operation_request_id=request_id,
            document_id=args.document_id,
        )
    elif args.command == "writer-replace":
        response = _with_optional_task_status(
            lambda: writer_replace_response(
                request_id,
                document_id=args.document_id,
                find_text=args.find,
                replace_text=args.replace,
                dry_run=args.dry_run,
                paragraph_index=args.paragraph_index,
            ),
            task_id=args.task_id,
            tracked_command="writer-replace",
            operation_request_id=request_id,
            document_id=args.document_id,
        )
    elif args.command == "writer-table-write":
        response = _with_optional_task_status(
            lambda: writer_table_write_response(
                request_id,
                document_id=args.document_id,
                table_index=args.table_index,
                row=args.row,
                column=args.column,
                text=args.text,
                dry_run=args.dry_run,
            ),
            task_id=args.task_id,
            tracked_command="writer-table-write",
            operation_request_id=request_id,
            document_id=args.document_id,
        )
    elif args.command == "validate-document":
        response = validate_document_response(
            request_id,
            document_id=args.document_id,
            contains=args.contains,
            cell=args.cell,
            equals=args.equals,
        )
    elif args.command == "snapshot-document":
        response = snapshot_document_response(
            request_id,
            document_id=args.document_id,
        )
    elif args.command == "operation":
        response = operation_response(
            request_id,
            operation_request_id=args.request,
        )
    elif args.command == "operations":
        response = operations_response(request_id)
    elif args.command == "task-status-create":
        response = task_status_create_response(
            request_id,
            task_id=args.task_id,
            command=args.tracked_command,
            operation_request_id=args.operation_request_id,
            document_id=args.document_id,
            message=args.message,
            recovery_guidance=args.recovery_guidance,
        )
    elif args.command == "task-status-update":
        response = task_status_update_response(
            request_id,
            task_id=args.task_id,
            state=args.state,
            progress_percent=args.progress_percent,
            message=args.message,
            recovery_guidance=args.recovery_guidance,
            result_ref=args.result_ref,
        )
    elif args.command == "task-status":
        response = task_status_response(
            request_id,
            task_id=args.task_id,
        )
    elif args.command == "task-statuses":
        response = task_statuses_response(request_id)
    elif args.command == "task-recovery":
        response = task_recovery_response(
            request_id,
            task_id=args.task_id,
        )
    elif args.command == "task-recovery-playbooks":
        response = task_recovery_playbooks_response(request_id)
    elif args.command == "mcp-tools":
        response = mcp_tools_response(
            request_id,
            category=args.category,
            mutates_document=args.mutates_document,
        )
    elif args.command == "mcp-tool-schema":
        response = mcp_tool_schema_response(
            request_id,
            name=args.name,
        )
    elif args.command == "mcp-call":
        response = mcp_call_response(
            request_id,
            name=args.name,
            arguments_json=args.arguments_json,
        )
    elif args.command == "mcp-server":
        if args.once_json:
            rpc_response = handle_mcp_json(args.once_json)
            if rpc_response is not None:
                print(dumps_json(rpc_response))
            return 0
        return serve_stdio()
    elif args.command == "mcp-smoke":
        response = mcp_smoke_response(
            request_id,
            expected_min_tools=args.expected_min_tools,
            tool_name=args.tool_name,
        )
    elif args.command == "mcp-config-audit":
        response = mcp_config_audit_response(
            request_id,
            config_path=args.config,
            server_name=args.server_name,
            expected_min_tools=args.expected_min_tools,
            timeout_seconds=args.timeout_seconds,
        )
    elif args.command == "regression-manifest":
        response = regression_manifest_response(
            request_id,
            manifest_path=args.manifest,
            profile=args.profile,
            include_wps=args.include_wps,
        )
    elif args.command == "regression-run":
        response = regression_run_response(
            request_id,
            manifest_path=args.manifest,
            profile=args.profile,
            include_wps=args.include_wps,
            artifact_dir=args.artifact_dir,
        )
    elif args.command == "security-audit":
        response = security_audit_response(request_id)
    elif args.command == "performance-baseline":
        response = performance_baseline_response(request_id)
    elif args.command == "scan-dir":
        response = scan_dir_response(
            request_id,
            path=args.path,
            recursive=args.recursive,
        )
    elif args.command == "batch-report":
        response = batch_report_response(
            request_id,
            path=args.path,
            recursive=args.recursive,
            include_snapshots=not args.no_snapshots,
        )
    elif args.command == "spreadsheet-read":
        response = spreadsheet_read_response(
            request_id,
            document_id=args.document_id,
            range_address=args.range,
            sheet_name=args.sheet,
        )
    elif args.command == "spreadsheet-write":
        response = _with_optional_task_status(
            lambda: spreadsheet_write_response(
                request_id,
                document_id=args.document_id,
                range_address=args.range,
                values_json=args.values_json,
                sheet_name=args.sheet,
                dry_run=args.dry_run,
            ),
            task_id=args.task_id,
            tracked_command="spreadsheet-write",
            operation_request_id=request_id,
            document_id=args.document_id,
        )
    elif args.command == "spreadsheet-formula-write":
        response = _with_optional_task_status(
            lambda: spreadsheet_formula_write_response(
                request_id,
                document_id=args.document_id,
                range_address=args.range,
                formulas_json=args.formulas_json,
                expected_values_json=args.expected_values_json,
                sheet_name=args.sheet,
                dry_run=args.dry_run,
            ),
            task_id=args.task_id,
            tracked_command="spreadsheet-formula-write",
            operation_request_id=request_id,
            document_id=args.document_id,
        )
    elif args.command == "presentation-replace":
        response = _with_optional_task_status(
            lambda: presentation_replace_response(
                request_id,
                document_id=args.document_id,
                find_text=args.find,
                replace_text=args.replace,
                dry_run=args.dry_run,
                slide_index=args.slide_index,
            ),
            task_id=args.task_id,
            tracked_command="presentation-replace",
            operation_request_id=request_id,
            document_id=args.document_id,
        )
    else:  # pragma: no cover - argparse enforces valid commands
        parser.error(f"Unsupported command: {args.command}")

    print(dumps_json(response.to_dict()))
    return 0


def main() -> int:
    return run(sys.argv[1:])
