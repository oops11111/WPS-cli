from __future__ import annotations

import json
from pathlib import Path
import subprocess
import tempfile
from typing import Any

from .backups import create_backup
from .capabilities import powershell_executable, probe_wps_capabilities
from .document_text import (
    count_text_in_docx,
    count_text_in_docx_paragraph,
    docx_body_paragraphs,
    docx_body_tables,
    docx_table_cell_text,
)
from .errors import COM_BACKEND_UNAVAILABLE, COM_OPERATION_FAILED, INPUT_FILE_NOT_FOUND
from .operations import get_operation, record_operation
from .sessions import get_document


BODY_PARTS = ("word/document.xml",)


def _run_writer_replace_com(
    path: str,
    find_text: str,
    replace_text: str,
    paragraph_index: int | None = None,
) -> dict[str, Any]:
    capabilities = probe_wps_capabilities()
    selected_prog_id = capabilities["components"]["writer"]["selected_prog_id"]
    if not selected_prog_id:
        return {
            "ok": False,
            "errors": [
                {
                    "code": COM_BACKEND_UNAVAILABLE,
                    "message": "No registered WPS ProgID detected for writer.",
                }
            ],
            "data": {"capabilities": capabilities},
        }

    params = {
        "prog_id": selected_prog_id,
        "path": str(Path(path).resolve()),
        "find_text": find_text,
        "replace_text": replace_text,
        "paragraph_index": paragraph_index,
    }
    params_json = json.dumps(params)
    script = f"""
$ErrorActionPreference = 'Stop'
$params = @'
{params_json}
'@ | ConvertFrom-Json
$app = $null
$document = $null
try {{
  $app = New-Object -ComObject $params.prog_id
  try {{ $app.Visible = $false }} catch {{ }}
  $document = $app.Documents.Open($params.path)
  if ($null -ne $params.paragraph_index) {{
    $paragraphCount = $document.Paragraphs.Count
    if ([int]$params.paragraph_index -lt 1 -or [int]$params.paragraph_index -gt $paragraphCount) {{
      throw "Paragraph index out of range: $($params.paragraph_index)"
    }}
    $range = $document.Paragraphs.Item([int]$params.paragraph_index).Range
  }} else {{
    $range = $document.Content
  }}
  $replaceCount = 0
  $rangeEnd = $range.End
  while ($true) {{
    $find = $range.Find
    [void]$find.ClearFormatting()
    $matched = $find.Execute($params.find_text)
    if (-not $matched) {{ break }}
    $range.Text = $params.replace_text
    $replaceCount += 1
    $start = $range.End
    if ($start -ge $rangeEnd) {{ break }}
    $range = $document.Range($start, $rangeEnd)
  }}
  $document.Save()

  [pscustomobject]@{{
    ok = $true
    backend = 'powershell-com'
    component = 'writer'
    prog_id = $params.prog_id
    path = $params.path
    find_text = $params.find_text
    replace_text = $params.replace_text
    paragraph_index = $params.paragraph_index
    replace_count = $replaceCount
  }} | ConvertTo-Json -Depth 5
}} catch {{
  [pscustomobject]@{{
    ok = $false
    backend = 'powershell-com'
    component = 'writer'
    prog_id = $params.prog_id
    error_type = $_.Exception.GetType().FullName
    error_message = $_.Exception.Message
    position = $_.InvocationInfo.PositionMessage
  }} | ConvertTo-Json -Depth 5
  exit 2
}} finally {{
  if ($document -ne $null) {{
    try {{ $document.Close($false) }} catch {{ }}
    try {{ [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($document) }} catch {{ }}
  }}
  if ($app -ne $null) {{
    try {{ $app.Quit() }} catch {{ }}
    try {{ [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($app) }} catch {{ }}
  }}
  [GC]::Collect()
  [GC]::WaitForPendingFinalizers()
}}
"""
    script_path = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            suffix=".ps1",
            delete=False,
            encoding="utf-8-sig",
        ) as script_file:
            script_file.write(script)
            script_path = script_file.name
        completed = subprocess.run(
            [
                powershell_executable(),
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                script_path,
            ],
            check=False,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            text=True,
            timeout=120,
        )
    finally:
        if script_path:
            try:
                Path(script_path).unlink(missing_ok=True)
            except OSError:
                pass

    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError:
        payload = None

    if completed.returncode != 0 or not isinstance(payload, dict):
        return {
            "ok": False,
            "errors": [
                {
                    "code": COM_OPERATION_FAILED,
                    "message": (
                        payload.get("error_message")
                        if isinstance(payload, dict)
                        else (completed.stderr or completed.stdout).strip()
                    ),
                }
            ],
            "data": {"diagnostic": payload, "backend": "powershell-com"},
        }
    return {"ok": True, "errors": [], "data": payload}


def _run_writer_table_write_com(
    path: str,
    table_index: int,
    row: int,
    column: int,
    text: str,
) -> dict[str, Any]:
    capabilities = probe_wps_capabilities()
    selected_prog_id = capabilities["components"]["writer"]["selected_prog_id"]
    if not selected_prog_id:
        return {
            "ok": False,
            "errors": [
                {
                    "code": COM_BACKEND_UNAVAILABLE,
                    "message": "No registered WPS ProgID detected for writer.",
                }
            ],
            "data": {"capabilities": capabilities},
        }

    params = {
        "prog_id": selected_prog_id,
        "path": str(Path(path).resolve()),
        "table_index": table_index,
        "row": row,
        "column": column,
        "text": text,
    }
    params_json = json.dumps(params)
    script = f"""
$ErrorActionPreference = 'Stop'
$params = @'
{params_json}
'@ | ConvertFrom-Json
$app = $null
$document = $null
try {{
  $app = New-Object -ComObject $params.prog_id
  try {{ $app.Visible = $false }} catch {{ }}
  $document = $app.Documents.Open($params.path)
  $tableCount = $document.Tables.Count
  if ([int]$params.table_index -lt 1 -or [int]$params.table_index -gt $tableCount) {{
    throw "Table index out of range: $($params.table_index)"
  }}
  $table = $document.Tables.Item([int]$params.table_index)
  $cell = $table.Cell([int]$params.row, [int]$params.column)
  $beforeText = $cell.Range.Text
  $cell.Range.Text = [string]$params.text
  $document.Save()
  $afterText = $table.Cell([int]$params.row, [int]$params.column).Range.Text

  [pscustomobject]@{{
    ok = $true
    backend = 'powershell-com'
    component = 'writer'
    prog_id = $params.prog_id
    path = $params.path
    table_index = [int]$params.table_index
    row = [int]$params.row
    column = [int]$params.column
    table_count = $tableCount
    previous_text = $beforeText.TrimEnd([char]13, [char]7)
    read_back_text = $afterText.TrimEnd([char]13, [char]7)
  }} | ConvertTo-Json -Depth 5
}} catch {{
  [pscustomobject]@{{
    ok = $false
    backend = 'powershell-com'
    component = 'writer'
    prog_id = $params.prog_id
    error_type = $_.Exception.GetType().FullName
    error_message = $_.Exception.Message
    position = $_.InvocationInfo.PositionMessage
  }} | ConvertTo-Json -Depth 5
  exit 2
}} finally {{
  if ($document -ne $null) {{
    try {{ $document.Close($false) }} catch {{ }}
    try {{ [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($document) }} catch {{ }}
  }}
  if ($app -ne $null) {{
    try {{ $app.Quit() }} catch {{ }}
    try {{ [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($app) }} catch {{ }}
  }}
  [GC]::Collect()
  [GC]::WaitForPendingFinalizers()
}}
"""
    script_path = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            suffix=".ps1",
            delete=False,
            encoding="utf-8-sig",
        ) as script_file:
            script_file.write(script)
            script_path = script_file.name
        completed = subprocess.run(
            [
                powershell_executable(),
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                script_path,
            ],
            check=False,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            text=True,
            timeout=120,
        )
    finally:
        if script_path:
            try:
                Path(script_path).unlink(missing_ok=True)
            except OSError:
                pass

    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError:
        payload = None

    if completed.returncode != 0 or not isinstance(payload, dict):
        return {
            "ok": False,
            "errors": [
                {
                    "code": COM_OPERATION_FAILED,
                    "message": (
                        payload.get("error_message")
                        if isinstance(payload, dict)
                        else (completed.stderr or completed.stdout).strip()
                    ),
                }
            ],
            "data": {"diagnostic": payload, "backend": "powershell-com"},
        }
    return {"ok": True, "errors": [], "data": payload}


def writer_replace(
    document_id: str,
    find_text: str,
    replace_text: str,
    request_id: str,
    dry_run: bool = False,
    paragraph_index: int | None = None,
    workspace: str | Path = ".",
) -> tuple[bool, dict[str, Any], list[dict[str, str]], bool]:
    existing = get_operation(request_id, workspace)
    if existing and existing.get("command") == "writer-replace":
        return True, dict(existing["result"]), [], True

    if not find_text:
        return (
            False,
            {},
            [{"code": "INVALID_ARGUMENT", "message": "find_text must not be empty."}],
            False,
        )
    if paragraph_index is not None and paragraph_index < 1:
        return (
            False,
            {},
            [{"code": "INVALID_ARGUMENT", "message": "paragraph_index must be 1 or greater."}],
            False,
        )

    document = get_document(document_id, workspace)
    if not document:
        return (
            False,
            {},
            [{"code": "DOCUMENT_NOT_FOUND", "message": f"Document not registered: {document_id}"}],
            False,
        )
    if document["component"] != "writer":
        return (
            False,
            {"document": document},
            [{"code": "UNSUPPORTED_COMPONENT", "message": "writer-replace requires a writer document."}],
            False,
        )

    path = Path(document["path"])
    if not path.exists():
        return (
            False,
            {"document": document},
            [{"code": INPUT_FILE_NOT_FOUND, "message": f"Input file not found: {path}"}],
            False,
        )

    paragraph_count = len(docx_body_paragraphs(path))
    if paragraph_index is not None and paragraph_index > paragraph_count:
        return (
            False,
            {
                "document_id": document_id,
                "component": "writer",
                "path": str(path),
                "scope": "paragraph",
                "paragraph_index": paragraph_index,
                "paragraph_count": paragraph_count,
            },
            [{"code": "PARAGRAPH_NOT_FOUND", "message": f"Paragraph index out of range: {paragraph_index}"}],
            False,
        )

    if paragraph_index is None:
        before_count = count_text_in_docx(path, find_text, parts=BODY_PARTS)
        after_existing_count = (
            count_text_in_docx(path, replace_text, parts=BODY_PARTS) if replace_text else 0
        )
        scope = "body"
    else:
        before_count = count_text_in_docx_paragraph(path, paragraph_index, find_text)
        after_existing_count = (
            count_text_in_docx_paragraph(path, paragraph_index, replace_text) if replace_text else 0
        )
        scope = "paragraph"
    preview = {
        "document_id": document_id,
        "component": "writer",
        "path": str(path),
        "find_text": find_text,
        "replace_text": replace_text,
        "scope": scope,
        "paragraph_index": paragraph_index,
        "paragraph_count": paragraph_count,
        "matches": before_count,
        "dry_run": dry_run,
    }
    if dry_run:
        return True, preview, [], False
    if before_count == 0:
        return (
            False,
            preview,
            [{"code": "TEXT_NOT_FOUND", "message": "No matching text found before replace."}],
            False,
        )

    backup_ok, backup_result, backup_errors, backup_replayed = create_backup(
        document_id=document_id,
        request_id=f"{request_id}:backup",
        dry_run=False,
        workspace=workspace,
    )
    if not backup_ok:
        return False, {"preview": preview, "backup": backup_result}, backup_errors, False

    replace_result = _run_writer_replace_com(
        str(path),
        find_text,
        replace_text,
        paragraph_index=paragraph_index,
    )
    if not replace_result["ok"]:
        return False, {"preview": preview, "backup": backup_result, "replace": replace_result["data"]}, replace_result["errors"], False

    if paragraph_index is None:
        remaining_find_count = count_text_in_docx(path, find_text, parts=BODY_PARTS)
        final_replace_count = (
            count_text_in_docx(path, replace_text, parts=BODY_PARTS) if replace_text else 0
        )
    else:
        remaining_find_count = count_text_in_docx_paragraph(path, paragraph_index, find_text)
        final_replace_count = (
            count_text_in_docx_paragraph(path, paragraph_index, replace_text) if replace_text else 0
        )
    replaced_count = max(0, final_replace_count - after_existing_count)
    old_text_allowed = bool(replace_text and find_text in replace_text)
    validation_passed = replaced_count >= before_count and (
        old_text_allowed or remaining_find_count == 0
    )
    result = {
        **preview,
        "dry_run": False,
        "backup": backup_result,
        "backup_replayed": backup_replayed,
        "replace_backend": replace_result["data"].get("backend"),
        "backend_replace_count": replace_result["data"].get("replace_count"),
        "matches_before": before_count,
        "remaining_find_count": remaining_find_count,
        "replace_count_delta": replaced_count,
        "old_text_allowed_after_replace": old_text_allowed,
        "validation_passed": validation_passed,
    }
    if not validation_passed:
        return (
            False,
            result,
            [{"code": "VALIDATION_FAILED", "message": "Replacement validation did not pass."}],
            False,
        )

    record_operation(request_id, "writer-replace", result, workspace)
    return True, result, [], False


def writer_table_write(
    document_id: str,
    table_index: int,
    row: int,
    column: int,
    text: str,
    request_id: str,
    dry_run: bool = False,
    workspace: str | Path = ".",
) -> tuple[bool, dict[str, Any], list[dict[str, str]], bool]:
    existing = get_operation(request_id, workspace)
    if existing and existing.get("command") == "writer-table-write":
        return True, dict(existing["result"]), [], True

    if table_index < 1 or row < 1 or column < 1:
        return (
            False,
            {},
            [{"code": "INVALID_ARGUMENT", "message": "table_index, row, and column must be 1 or greater."}],
            False,
        )

    document = get_document(document_id, workspace)
    if not document:
        return (
            False,
            {},
            [{"code": "DOCUMENT_NOT_FOUND", "message": f"Document not registered: {document_id}"}],
            False,
        )
    if document["component"] != "writer":
        return (
            False,
            {"document": document},
            [{"code": "UNSUPPORTED_COMPONENT", "message": "writer-table-write requires a writer document."}],
            False,
        )

    path = Path(document["path"])
    if not path.exists():
        return (
            False,
            {"document": document},
            [{"code": INPUT_FILE_NOT_FOUND, "message": f"Input file not found: {path}"}],
            False,
        )

    tables = docx_body_tables(path)
    table_count = len(tables)
    if table_index > table_count:
        return (
            False,
            {
                "document_id": document_id,
                "component": "writer",
                "path": str(path),
                "table_index": table_index,
                "table_count": table_count,
            },
            [{"code": "TABLE_NOT_FOUND", "message": f"Table index out of range: {table_index}"}],
            False,
        )
    current_text = docx_table_cell_text(path, table_index, row, column)
    if current_text is None:
        selected_table = tables[table_index - 1]
        return (
            False,
            {
                "document_id": document_id,
                "component": "writer",
                "path": str(path),
                "table_index": table_index,
                "table_count": table_count,
                "row": row,
                "column": column,
                "row_count": len(selected_table),
                "column_count": max((len(item) for item in selected_table), default=0),
            },
            [{"code": "CELL_NOT_FOUND", "message": f"Cell out of range: row {row}, column {column}"}],
            False,
        )

    preview = {
        "document_id": document_id,
        "component": "writer",
        "path": str(path),
        "table_index": table_index,
        "table_count": table_count,
        "row": row,
        "column": column,
        "current_text": current_text,
        "replacement_text": text,
        "would_modify": current_text != text,
        "dry_run": dry_run,
    }
    if dry_run:
        return True, preview, [], False

    backup_ok, backup_result, backup_errors, backup_replayed = create_backup(
        document_id=document_id,
        request_id=f"{request_id}:backup",
        dry_run=False,
        workspace=workspace,
    )
    if not backup_ok:
        return False, {"preview": preview, "backup": backup_result}, backup_errors, False

    write_result = _run_writer_table_write_com(
        str(path),
        table_index=table_index,
        row=row,
        column=column,
        text=text,
    )
    if not write_result["ok"]:
        return False, {"preview": preview, "backup": backup_result, "write": write_result["data"]}, write_result["errors"], False

    final_tables = docx_body_tables(path)
    read_back_text = docx_table_cell_text(path, table_index, row, column)
    final_table_count = len(final_tables)
    table_count_preserved = final_table_count == table_count
    validation_passed = read_back_text == text
    result = {
        **preview,
        "dry_run": False,
        "backup": backup_result,
        "backup_replayed": backup_replayed,
        "write_backend": write_result["data"].get("backend"),
        "backend_read_back_text": write_result["data"].get("read_back_text"),
        "read_back_text": read_back_text,
        "final_table_count": final_table_count,
        "table_count_preserved": table_count_preserved,
        "validation_passed": validation_passed,
    }
    if not validation_passed:
        return (
            False,
            result,
            [{"code": "VALIDATION_FAILED", "message": "Writer table cell validation did not pass."}],
            False,
        )

    record_operation(request_id, "writer-table-write", result, workspace)
    return True, result, [], False
