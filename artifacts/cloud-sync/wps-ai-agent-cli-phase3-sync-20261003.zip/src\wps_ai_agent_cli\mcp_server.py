from __future__ import annotations

import json
import sys
from typing import Any, TextIO

from .mcp_adapter import call_mcp_tool
from .mcp_schema import list_mcp_tool_schemas


MCP_PROTOCOL_VERSION = "2026-07-28"
SERVER_INFO = {"name": "wps-ai-agent-cli", "version": "phase2-prototype"}


def _response(request_id: Any, result: dict[str, Any]) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def _error_response(request_id: Any, code: int, message: str, data: Any | None = None) -> dict[str, Any]:
    error: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        error["data"] = data
    return {"jsonrpc": "2.0", "id": request_id, "error": error}


def _tool_from_schema(schema: dict[str, Any]) -> dict[str, Any]:
    return {
        "name": schema["name"],
        "title": schema["title"],
        "description": schema["description"],
        "inputSchema": schema["input_schema"],
        "outputSchema": schema["output_contract"],
        "annotations": {
            "readOnlyHint": not schema["mutates_document"],
            "destructiveHint": schema["mutates_document"],
            "openWorldHint": schema["requires_wps"],
        },
        "_meta": {
            "cliCommand": schema["cli_command"],
            "category": schema["category"],
            "requiresWps": schema["requires_wps"],
            "idempotency": schema["idempotency"],
        },
    }


def _initialize_result() -> dict[str, Any]:
    return {
        "protocolVersion": MCP_PROTOCOL_VERSION,
        "capabilities": {"tools": {"listChanged": False}},
        "serverInfo": SERVER_INFO,
    }


def _tools_list_result() -> dict[str, Any]:
    return {
        "resultType": "complete",
        "tools": [_tool_from_schema(schema) for schema in list_mcp_tool_schemas()],
        "ttlMs": 300000,
        "cacheScope": "public",
    }


def _tools_call_result(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    ok, result, errors = call_mcp_tool(name, arguments)
    summary = None
    response = result.get("response") if result else None
    if response:
        summary = response.get("summary")
    payload = {
        "ok": ok,
        "summary": summary or ("MCP tool call completed." if ok else "MCP tool call failed."),
        "errors": errors,
    }
    return {
        "resultType": "complete",
        "isError": not ok,
        "content": [
            {
                "type": "text",
                "text": json.dumps(payload, ensure_ascii=False, sort_keys=True),
            }
        ],
        "structuredContent": {
            "mcp_call": result,
            "errors": errors,
        },
    }


def handle_mcp_request(message: dict[str, Any]) -> dict[str, Any] | None:
    request_id = message.get("id")
    method = message.get("method")
    if message.get("jsonrpc") != "2.0" or not method:
        return _error_response(request_id, -32600, "Invalid JSON-RPC request.")

    if method == "notifications/initialized":
        return None
    if method == "initialize":
        return _response(request_id, _initialize_result())
    if method == "tools/list":
        return _response(request_id, _tools_list_result())
    if method == "tools/call":
        params = message.get("params") or {}
        if not isinstance(params, dict):
            return _error_response(request_id, -32602, "tools/call params must be an object.")
        name = params.get("name")
        arguments = params.get("arguments") or {}
        if not isinstance(name, str) or not name:
            return _error_response(request_id, -32602, "tools/call requires a tool name.")
        if not isinstance(arguments, dict):
            return _error_response(request_id, -32602, "tools/call arguments must be an object.")
        return _response(request_id, _tools_call_result(name, arguments))

    return _error_response(request_id, -32601, f"Method not found: {method}")


def handle_mcp_json(raw_json: str) -> dict[str, Any] | None:
    try:
        message = json.loads(raw_json)
    except json.JSONDecodeError as exc:
        return _error_response(None, -32700, "Parse error.", str(exc))
    if not isinstance(message, dict):
        return _error_response(None, -32600, "Invalid JSON-RPC request.")
    return handle_mcp_request(message)


def serve_stdio(input_stream: TextIO | None = None, output_stream: TextIO | None = None) -> int:
    input_stream = input_stream or sys.stdin
    output_stream = output_stream or sys.stdout
    for line in input_stream:
        line = line.strip()
        if not line:
            continue
        response = handle_mcp_json(line)
        if response is None:
            continue
        output_stream.write(json.dumps(response, ensure_ascii=False, sort_keys=True))
        output_stream.write("\n")
        output_stream.flush()
    return 0
