import tempfile
import unittest
from pathlib import Path

from wps_ai_agent_cli.task_status import (
    build_recovery_playbook,
    create_task_status,
    get_task_status,
    list_recovery_playbooks,
    list_task_statuses,
    update_task_status,
)


class TaskStatusTests(unittest.TestCase):
    def test_create_update_get_and_list_task_status(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()

            ok, created, errors, replayed = create_task_status(
                command="convert-smoke",
                request_id="op-1",
                task_id="task-1",
                document_id="doc_1",
                message="Queued",
                recovery_guidance=["Retry after checking WPS availability."],
                workspace=workspace,
            )
            self.assertTrue(ok)
            self.assertFalse(replayed)
            self.assertEqual(errors, [])
            self.assertEqual(created["state"], "pending")
            self.assertFalse(created["terminal"])

            ok, running, errors = update_task_status(
                "task-1",
                "running",
                progress_percent=40,
                message="Opening WPS.",
                workspace=workspace,
            )
            self.assertTrue(ok)
            self.assertEqual(errors, [])
            self.assertEqual(running["state"], "running")
            self.assertEqual(running["progress_percent"], 40)
            self.assertIsNotNone(running["started_at"])

            ok, finished, errors = update_task_status(
                "task-1",
                "succeeded",
                result_ref="op-1",
                workspace=workspace,
            )
            self.assertTrue(ok)
            self.assertEqual(errors, [])
            self.assertTrue(finished["terminal"])
            self.assertEqual(finished["progress_percent"], 100)
            self.assertEqual(finished["result_ref"], "op-1")
            self.assertIsNotNone(finished["completed_at"])

            self.assertEqual(get_task_status("task-1", workspace)["state"], "succeeded")
            self.assertEqual(list_task_statuses(workspace)[0]["task_id"], "task-1")

    def test_create_task_status_replays_existing_task_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()
            create_task_status("sample", "op-1", task_id="task-1", workspace=workspace)

            ok, result, errors, replayed = create_task_status(
                "sample",
                "op-2",
                task_id="task-1",
                workspace=workspace,
            )

            self.assertTrue(ok)
            self.assertTrue(replayed)
            self.assertEqual(errors, [])
            self.assertEqual(result["request_id"], "op-1")

    def test_update_task_status_rejects_invalid_progress(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()
            create_task_status("sample", "op-1", task_id="task-1", workspace=workspace)

            ok, result, errors = update_task_status(
                "task-1",
                "running",
                progress_percent=101,
                workspace=workspace,
            )

            self.assertFalse(ok)
            self.assertEqual(result, {})
            self.assertEqual(errors[0]["code"], "INVALID_PROGRESS")

    def test_update_task_status_rejects_terminal_update(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()
            create_task_status("sample", "op-1", task_id="task-1", workspace=workspace)
            update_task_status("task-1", "failed", workspace=workspace)

            ok, result, errors = update_task_status(
                "task-1",
                "running",
                workspace=workspace,
            )

            self.assertFalse(ok)
            self.assertEqual(result["state"], "failed")
            self.assertEqual(errors[0]["code"], "TASK_ALREADY_TERMINAL")

    def test_recovery_playbook_for_running_task_is_ambiguous(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()
            create_task_status(
                "spreadsheet-write",
                "op-1",
                task_id="task-1",
                document_id="doc_1",
                workspace=workspace,
            )
            update_task_status("task-1", "running", progress_percent=50, workspace=workspace)

            playbook = build_recovery_playbook("task-1", workspace=workspace)

            self.assertEqual(playbook["scenario"], "interrupted_or_running")
            self.assertFalse(playbook["safe_to_retry"])
            self.assertEqual(playbook["evidence"]["document_id"], "doc_1")
            self.assertIn("python -m wps_ai_agent_cli operation --request op-1", playbook["commands"])
            self.assertIn("python -m wps_ai_agent_cli list-backups --document-id doc_1", playbook["commands"])

    def test_recovery_playbook_for_failed_task_preserves_guidance(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()
            create_task_status("writer-replace", "op-1", task_id="task-1", workspace=workspace)
            update_task_status(
                "task-1",
                "failed",
                recovery_guidance=["Inspect response errors before retrying."],
                workspace=workspace,
            )

            playbook = build_recovery_playbook("task-1", workspace=workspace)

            self.assertEqual(playbook["scenario"], "failed")
            self.assertFalse(playbook["safe_to_retry"])
            self.assertEqual(
                playbook["task_recovery_guidance"],
                ["Inspect response errors before retrying."],
            )

    def test_recovery_playbook_for_missing_task_is_ambiguous(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()

            playbook = build_recovery_playbook("missing-task", workspace=workspace)

            self.assertEqual(playbook["scenario"], "ambiguous_missing_status")
            self.assertFalse(playbook["safe_to_retry"])
            self.assertFalse(playbook["evidence"]["task_status_found"])

    def test_recovery_playbooks_list_exposes_required_scenarios(self):
        scenarios = {playbook["scenario"] for playbook in list_recovery_playbooks()}

        self.assertIn("interrupted_or_running", scenarios)
        self.assertIn("failed", scenarios)
        self.assertIn("ambiguous_missing_status", scenarios)


if __name__ == "__main__":
    unittest.main()
