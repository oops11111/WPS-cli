import unittest

from wps_ai_agent_cli.mcp_schema import (
    get_mcp_tool_schema,
    list_mcp_tool_categories,
    list_mcp_tool_schemas,
)


class McpSchemaTests(unittest.TestCase):
    def test_schema_names_are_unique_and_cover_current_cli_surface(self):
        schemas = list_mcp_tool_schemas()
        names = [schema["name"] for schema in schemas]
        commands = {schema["cli_command"] for schema in schemas}

        self.assertEqual(len(names), len(set(names)))
        self.assertGreaterEqual(len(schemas), 36)
        self.assertIn("spreadsheet-write", commands)
        self.assertIn("task-recovery", commands)
        self.assertIn("mcp-tools", commands)
        self.assertIn("mcp-call", commands)
        self.assertIn("mcp-server", commands)
        self.assertIn("wps-process-audit", commands)
        self.assertIn("mcp-smoke", commands)
        self.assertIn("mcp-config-audit", commands)
        self.assertIn("regression-manifest", commands)
        self.assertIn("regression-run", commands)
        self.assertIn("security-audit", commands)
        self.assertIn("performance-baseline", commands)
        self.assertIn("writer-table-write", commands)
        self.assertIn("writer-table-smoke", commands)

    def test_spreadsheet_write_schema_marks_safety_contract(self):
        schema = get_mcp_tool_schema("wps_agent_spreadsheet_write")

        self.assertIsNotNone(schema)
        self.assertTrue(schema["mutates_document"])
        self.assertTrue(schema["requires_wps"])
        self.assertEqual(
            schema["input_schema"]["required"],
            ["document_id", "range", "values_json"],
        )
        self.assertIn("task_id", schema["input_schema"]["properties"])
        self.assertIn("output_contract", schema)

    def test_schema_lookup_accepts_cli_command_name(self):
        schema = get_mcp_tool_schema("writer-replace")

        self.assertIsNotNone(schema)
        self.assertEqual(schema["name"], "wps_agent_writer_replace")

    def test_regression_run_schema_accepts_artifact_dir(self):
        schema = get_mcp_tool_schema("wps_agent_regression_run")

        self.assertIsNotNone(schema)
        self.assertIn("artifact_dir", schema["input_schema"]["properties"])

    def test_category_and_mutation_filters(self):
        spreadsheet = list_mcp_tool_schemas(category="spreadsheet")
        mutating = list_mcp_tool_schemas(mutates_document=True)
        categories = list_mcp_tool_categories()

        self.assertGreaterEqual(len(spreadsheet), 3)
        self.assertTrue(all(schema["category"] == "spreadsheet" for schema in spreadsheet))
        self.assertTrue(all(schema["mutates_document"] for schema in mutating))
        self.assertIn("recovery", categories)
        self.assertIn("security", categories)
        self.assertIn("performance", categories)

    def test_mutating_schemas_expose_safety_boundaries(self):
        mutating = list_mcp_tool_schemas(mutates_document=True)

        self.assertGreaterEqual(len(mutating), 8)
        for schema in mutating:
            properties = schema["input_schema"]["properties"]
            self.assertIn("request_id", properties)
            self.assertIn("request_id", schema["idempotency"])
            self.assertIn("task_id", properties)
            self.assertTrue(schema["safety_notes"])


if __name__ == "__main__":
    unittest.main()
