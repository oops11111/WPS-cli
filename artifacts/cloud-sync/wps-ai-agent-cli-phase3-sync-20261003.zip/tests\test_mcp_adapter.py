import unittest

from wps_ai_agent_cli.mcp_adapter import build_cli_argv, call_mcp_tool


class McpAdapterTests(unittest.TestCase):
    def test_build_cli_argv_maps_json_arguments_to_cli_flags(self):
        ok, argv, schema, errors = build_cli_argv(
            "wps_agent_tasks",
            {"phase": "phase2", "status": "next", "request_id": "req-1"},
        )

        self.assertTrue(ok)
        self.assertEqual(errors, [])
        self.assertEqual(schema["cli_command"], "tasks")
        self.assertEqual(argv, ["tasks", "--phase", "phase2", "--status", "next", "--request-id", "req-1"])

    def test_call_mcp_tool_uses_cli_response_layer(self):
        ok, result, errors = call_mcp_tool(
            "wps_agent_tasks",
            {"phase": "phase2", "request_id": "mcp-adapter-test-001"},
        )

        self.assertTrue(ok)
        self.assertEqual(errors, [])
        self.assertEqual(result["cli_command"], "tasks")
        self.assertEqual(result["response"]["command"], "tasks")
        self.assertEqual(result["response"]["data"]["filters"]["phase"], "phase2")

    def test_call_mcp_tool_rejects_missing_required_arguments(self):
        ok, result, errors = call_mcp_tool("wps_agent_spreadsheet_write", {"range": "A1:B2"})

        self.assertFalse(ok)
        self.assertIsNone(result["response"])
        self.assertEqual(errors[0]["code"], "MCP_ARGUMENTS_MISSING_REQUIRED")
        self.assertIn("document_id", errors[0]["details"])

    def test_call_mcp_tool_rejects_recursive_mcp_call(self):
        ok, result, errors = call_mcp_tool("wps_agent_mcp_call", {"name": "wps_agent_tasks"})

        self.assertFalse(ok)
        self.assertIsNone(result["response"])
        self.assertEqual(errors[0]["code"], "MCP_ADAPTER_CALL_REJECTED")


if __name__ == "__main__":
    unittest.main()
