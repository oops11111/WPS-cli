from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


STATE_DIR = ".wps-agent"
DOCUMENTS_FILE = "documents.json"
SUPPORTED_COMPONENTS = {"writer", "spreadsheets", "presentation"}


@dataclass(frozen=True)
class DocumentRecord:
    document_id: str
    component: str
    path: str
    registered_at: str
    exists: bool


def stable_document_id(component: str, path: str) -> str:
    canonical = str(Path(path).resolve()).lower()
    digest = hashlib.sha256(f"{component}:{canonical}".encode("utf-8")).hexdigest()[:16]
    return f"doc_{digest}"


def _state_path(workspace: str | Path = ".") -> Path:
    return Path(workspace) / STATE_DIR / DOCUMENTS_FILE


def _read_state(workspace: str | Path = ".") -> dict[str, Any]:
    state_file = _state_path(workspace)
    if not state_file.exists():
        return {"documents": {}}
    return json.loads(state_file.read_text(encoding="utf-8"))


def _write_state(state: dict[str, Any], workspace: str | Path = ".") -> None:
    state_file = _state_path(workspace)
    state_file.parent.mkdir(parents=True, exist_ok=True)
    state_file.write_text(json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")


def register_document(component: str, path: str, workspace: str | Path = ".") -> tuple[bool, dict[str, Any], list[dict[str, str]]]:
    if component not in SUPPORTED_COMPONENTS:
        return (
            False,
            {},
            [{"code": "UNSUPPORTED_COMPONENT", "message": f"Unsupported component: {component}"}],
        )

    document_path = Path(path)
    if not document_path.exists():
        return (
            False,
            {},
            [{"code": "INPUT_FILE_NOT_FOUND", "message": f"Input file not found: {path}"}],
        )

    resolved = str(document_path.resolve())
    document_id = stable_document_id(component, resolved)
    state = _read_state(workspace)
    record = DocumentRecord(
        document_id=document_id,
        component=component,
        path=resolved,
        registered_at=datetime.now(timezone.utc).isoformat(),
        exists=True,
    )
    state.setdefault("documents", {})[document_id] = asdict(record)
    _write_state(state, workspace)
    return True, asdict(record), []


def list_documents(workspace: str | Path = ".") -> list[dict[str, Any]]:
    state = _read_state(workspace)
    records = []
    for record in state.get("documents", {}).values():
        current = dict(record)
        current["exists"] = Path(current["path"]).exists()
        records.append(current)
    return sorted(records, key=lambda item: item["document_id"])


def get_document(document_id: str, workspace: str | Path = ".") -> dict[str, Any] | None:
    state = _read_state(workspace)
    record = state.get("documents", {}).get(document_id)
    if not record:
        return None
    current = dict(record)
    current["exists"] = Path(current["path"]).exists()
    return current
