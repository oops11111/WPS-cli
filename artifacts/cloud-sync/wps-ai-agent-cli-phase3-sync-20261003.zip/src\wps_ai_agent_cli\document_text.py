from __future__ import annotations

from collections.abc import Iterable
import xml.etree.ElementTree as ET
from pathlib import Path
from zipfile import ZipFile


def count_text_in_docx(
    path: str | Path,
    text: str,
    parts: Iterable[str] | None = None,
) -> int:
    if not text:
        return 0
    part_filter = set(parts) if parts is not None else None
    total = 0
    with ZipFile(path) as archive:
        for name in archive.namelist():
            if part_filter is not None and name not in part_filter:
                continue
            if name.startswith("word/") and name.endswith(".xml"):
                payload = archive.read(name).decode("utf-8", errors="ignore")
                total += payload.count(text)
    return total


def docx_body_paragraphs(path: str | Path) -> list[str]:
    with ZipFile(path) as archive:
        payload = archive.read("word/document.xml")
    root = ET.fromstring(payload)
    namespace = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    paragraphs = []
    for paragraph in root.findall(".//w:body/w:p", namespace):
        texts = [
            node.text or ""
            for node in paragraph.findall(".//w:t", namespace)
        ]
        paragraphs.append("".join(texts))
    return paragraphs


def count_text_in_docx_paragraph(path: str | Path, paragraph_index: int, text: str) -> int:
    if not text:
        return 0
    paragraphs = docx_body_paragraphs(path)
    if paragraph_index < 1 or paragraph_index > len(paragraphs):
        return 0
    return paragraphs[paragraph_index - 1].count(text)


def docx_body_tables(path: str | Path) -> list[list[list[str]]]:
    with ZipFile(path) as archive:
        payload = archive.read("word/document.xml")
    root = ET.fromstring(payload)
    namespace = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    tables = []
    for table in root.findall(".//w:body/w:tbl", namespace):
        rows = []
        for row in table.findall("./w:tr", namespace):
            cells = []
            for cell in row.findall("./w:tc", namespace):
                texts = [
                    node.text or ""
                    for node in cell.findall(".//w:t", namespace)
                ]
                cells.append("".join(texts))
            rows.append(cells)
        tables.append(rows)
    return tables


def docx_table_cell_text(path: str | Path, table_index: int, row: int, column: int) -> str | None:
    tables = docx_body_tables(path)
    if table_index < 1 or table_index > len(tables):
        return None
    selected_table = tables[table_index - 1]
    if row < 1 or row > len(selected_table):
        return None
    selected_row = selected_table[row - 1]
    if column < 1 or column > len(selected_row):
        return None
    return selected_row[column - 1]
