from __future__ import annotations

import json
from pathlib import Path
import subprocess
import tempfile
from typing import Any

from .backups import create_backup
from .capabilities import powershell_executable, probe_wps_capabilities
from .errors import COM_BACKEND_UNAVAILABLE, COM_OPERATION_FAILED, INPUT_FILE_NOT_FOUND
from .operations import get_operation, record_operation
from .presentation_text import count_text_in_pptx, pptx_slide_texts
from .sessions import get_document


def _run_presentation_replace_com(
    path: str,
    find_text: str,
    replace_text: str,
    slide_index: int | None = None,
) -> dict[str, Any]:
    capabilities = probe_wps_capabilities()
    selected_prog_id = capabilities["components"]["presentation"]["selected_prog_id"]
    if not selected_prog_id:
        return {
            "ok": False,
            "errors": [
                {
                    "code": COM_BACKEND_UNAVAILABLE,
                    "message": "No registered WPS ProgID detected for presentation.",
                }
            ],
            "data": {"capabilities": capabilities},
        }

    params = {
        "prog_id": selected_prog_id,
        "path": str(Path(path).resolve()),
        "find_text": find_text,
        "replace_text": replace_text,
        "slide_index": slide_index,
    }
    params_json = json.dumps(params)
    script = f"""
$ErrorActionPreference = 'Stop'
$params = @'
{params_json}
'@ | ConvertFrom-Json
$app = $null
$presentation = $null
try {{
  $app = New-Object -ComObject $params.prog_id
  try {{ $app.Visible = $false }} catch {{ }}
  $presentation = $app.Presentations.Open($params.path, $false, $false, $false)
  $findText = [string]$params.find_text
  $replaceText = [string]$params.replace_text
  $replaceCount = 0
  $textShapeCount = 0
  $targetSlideIndex = $null
  if ($null -ne $params.slide_index) {{
    $targetSlideIndex = [int]$params.slide_index
    if ($targetSlideIndex -lt 1 -or $targetSlideIndex -gt $presentation.Slides.Count) {{
      throw "Slide index out of range: $targetSlideIndex"
    }}
  }}

  for ($slideIndex = 1; $slideIndex -le $presentation.Slides.Count; $slideIndex++) {{
    if ($null -ne $targetSlideIndex -and $slideIndex -ne $targetSlideIndex) {{ continue }}
    $slide = $presentation.Slides.Item($slideIndex)
    for ($shapeIndex = 1; $shapeIndex -le $slide.Shapes.Count; $shapeIndex++) {{
      $shape = $slide.Shapes.Item($shapeIndex)
      $hasText = $false
      try {{
        $hasText = ([int]$shape.HasTextFrame -ne 0) -and ([int]$shape.TextFrame.HasText -ne 0)
      }} catch {{ $hasText = $false }}
      if (-not $hasText) {{ continue }}
      $textShapeCount += 1
      $textRange = $shape.TextFrame.TextRange
      $text = [string]$textRange.Text
      $matches = [regex]::Matches($text, [regex]::Escape($findText)).Count
      if ($matches -le 0) {{ continue }}
      $textRange.Text = $text.Replace($findText, $replaceText)
      $replaceCount += $matches
    }}
  }}
  $presentation.Save()

  [pscustomobject]@{{
    ok = $true
    backend = 'powershell-com'
    component = 'presentation'
    prog_id = $params.prog_id
    path = $params.path
    find_text = $params.find_text
    replace_text = $params.replace_text
    slide_index = $params.slide_index
    slide_count = $presentation.Slides.Count
    text_shape_count = $textShapeCount
    replace_count = $replaceCount
  }} | ConvertTo-Json -Depth 5
}} catch {{
  [pscustomobject]@{{
    ok = $false
    backend = 'powershell-com'
    component = 'presentation'
    prog_id = $params.prog_id
    error_type = $_.Exception.GetType().FullName
    error_message = $_.Exception.Message
    position = $_.InvocationInfo.PositionMessage
  }} | ConvertTo-Json -Depth 5
  exit 2
}} finally {{
  if ($presentation -ne $null) {{
    try {{ $presentation.Close() }} catch {{ }}
    try {{ [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($presentation) }} catch {{ }}
  }}
  if ($app -ne $null) {{
    try {{ $app.Quit() }} catch {{ }}
    try {{ [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($app) }} catch {{ }}
  }}
  [GC]::Collect()
  [GC]::WaitForPendingFinalizers()
}}
"""
    script_path = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            suffix=".ps1",
            delete=False,
            encoding="utf-8-sig",
        ) as script_file:
            script_file.write(script)
            script_path = script_file.name
        completed = subprocess.run(
            [
                powershell_executable(),
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                script_path,
            ],
            check=False,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            text=True,
            timeout=120,
        )
    finally:
        if script_path:
            try:
                Path(script_path).unlink(missing_ok=True)
            except OSError:
                pass

    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError:
        payload = None

    if completed.returncode != 0 or not isinstance(payload, dict):
        return {
            "ok": False,
            "errors": [
                {
                    "code": COM_OPERATION_FAILED,
                    "message": (
                        payload.get("error_message")
                        if isinstance(payload, dict)
                        else (completed.stderr or completed.stdout).strip()
                    ),
                }
            ],
            "data": {"diagnostic": payload, "backend": "powershell-com"},
        }
    return {"ok": True, "errors": [], "data": payload}


def presentation_replace(
    document_id: str,
    find_text: str,
    replace_text: str,
    request_id: str,
    dry_run: bool = False,
    slide_index: int | None = None,
    workspace: str | Path = ".",
) -> tuple[bool, dict[str, Any], list[dict[str, str]], bool]:
    existing = get_operation(request_id, workspace)
    if existing and existing.get("command") == "presentation-replace":
        return True, dict(existing["result"]), [], True

    if not find_text:
        return (
            False,
            {},
            [{"code": "INVALID_ARGUMENT", "message": "find_text must not be empty."}],
            False,
        )
    if slide_index is not None and slide_index < 1:
        return (
            False,
            {},
            [{"code": "INVALID_ARGUMENT", "message": "slide_index must be 1 or greater."}],
            False,
        )

    document = get_document(document_id, workspace)
    if not document:
        return (
            False,
            {},
            [{"code": "DOCUMENT_NOT_FOUND", "message": f"Document not registered: {document_id}"}],
            False,
        )
    if document["component"] != "presentation":
        return (
            False,
            {"document": document},
            [{"code": "UNSUPPORTED_COMPONENT", "message": "presentation-replace requires a presentation document."}],
            False,
        )

    path = Path(document["path"])
    if not path.exists():
        return (
            False,
            {"document": document},
            [{"code": INPUT_FILE_NOT_FOUND, "message": f"Input file not found: {path}"}],
            False,
        )

    slides = pptx_slide_texts(path)
    slide_count = len(slides)
    if slide_index is not None and not any(slide["slide_index"] == slide_index for slide in slides):
        return (
            False,
            {
                "document_id": document_id,
                "component": "presentation",
                "path": str(path),
                "slide_index": slide_index,
                "slide_count": slide_count,
            },
            [{"code": "SLIDE_NOT_FOUND", "message": f"Slide index out of range: {slide_index}"}],
            False,
        )

    before_count = count_text_in_pptx(path, find_text, slide_index=slide_index)
    after_existing_count = (
        count_text_in_pptx(path, replace_text, slide_index=slide_index) if replace_text else 0
    )
    preview = {
        "document_id": document_id,
        "component": "presentation",
        "path": str(path),
        "find_text": find_text,
        "replace_text": replace_text,
        "scope": "slide" if slide_index is not None else "deck",
        "slide_index": slide_index,
        "slide_count": slide_count,
        "matches": before_count,
        "dry_run": dry_run,
    }
    if dry_run:
        return True, preview, [], False
    if before_count == 0:
        return (
            False,
            preview,
            [{"code": "TEXT_NOT_FOUND", "message": "No matching text found before replace."}],
            False,
        )

    backup_ok, backup_result, backup_errors, backup_replayed = create_backup(
        document_id=document_id,
        request_id=f"{request_id}:backup",
        dry_run=False,
        workspace=workspace,
    )
    if not backup_ok:
        return False, {"preview": preview, "backup": backup_result}, backup_errors, False

    replace_result = _run_presentation_replace_com(
        str(path),
        find_text,
        replace_text,
        slide_index=slide_index,
    )
    if not replace_result["ok"]:
        return False, {"preview": preview, "backup": backup_result, "replace": replace_result["data"]}, replace_result["errors"], False

    remaining_find_count = count_text_in_pptx(path, find_text, slide_index=slide_index)
    final_replace_count = (
        count_text_in_pptx(path, replace_text, slide_index=slide_index) if replace_text else 0
    )
    replaced_count = max(0, final_replace_count - after_existing_count)
    old_text_allowed = bool(replace_text and find_text in replace_text)
    validation_passed = replaced_count >= before_count and (
        old_text_allowed or remaining_find_count == 0
    )
    result = {
        **preview,
        "dry_run": False,
        "backup": backup_result,
        "backup_replayed": backup_replayed,
        "replace_backend": replace_result["data"].get("backend"),
        "backend_replace_count": replace_result["data"].get("replace_count"),
        "text_shape_count": replace_result["data"].get("text_shape_count"),
        "matches_before": before_count,
        "remaining_find_count": remaining_find_count,
        "replace_count_delta": replaced_count,
        "old_text_allowed_after_replace": old_text_allowed,
        "validation_passed": validation_passed,
    }
    if not validation_passed:
        return (
            False,
            result,
            [{"code": "VALIDATION_FAILED", "message": "Replacement validation did not pass."}],
            False,
        )

    record_operation(request_id, "presentation-replace", result, workspace)
    return True, result, [], False
