import tempfile
import unittest
from pathlib import Path

from openpyxl import Workbook

from wps_ai_agent_cli.sessions import register_document
from wps_ai_agent_cli.spreadsheet_ops import (
    read_spreadsheet_range,
    write_spreadsheet_formulas,
    write_spreadsheet_range,
)


class SpreadsheetOpsTests(unittest.TestCase):
    def test_read_spreadsheet_range_returns_matrix(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()
            document = Path(tmp) / "sample.xlsx"
            workbook = Workbook()
            sheet = workbook.active
            sheet.title = "Calculation"
            sheet["A1"] = "Item"
            sheet["B1"] = "Value"
            sheet["A2"] = "Sample"
            sheet["B2"] = 18
            workbook.save(document)
            ok, record, _errors = register_document("spreadsheets", str(document), workspace)
            self.assertTrue(ok)

            ok, result, errors = read_spreadsheet_range(
                record["document_id"],
                "A1:B2",
                workspace=workspace,
            )

            self.assertTrue(ok)
            self.assertEqual(errors, [])
            self.assertEqual(result["values"], [["Item", "Value"], ["Sample", 18]])
            self.assertEqual(result["row_count"], 2)
            self.assertEqual(result["column_count"], 2)

    def test_write_spreadsheet_range_dry_run_reports_shape(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()
            document = Path(tmp) / "sample.xlsx"
            workbook = Workbook()
            workbook.save(document)
            ok, record, _errors = register_document("spreadsheets", str(document), workspace)
            self.assertTrue(ok)

            ok, result, errors, replayed = write_spreadsheet_range(
                record["document_id"],
                "A1:B2",
                [["A", "B"], [1, 2]],
                request_id="sheet-write-dry",
                dry_run=True,
                workspace=workspace,
            )

            self.assertTrue(ok)
            self.assertFalse(replayed)
            self.assertEqual(errors, [])
            self.assertEqual(result["row_count"], 2)
            self.assertEqual(result["column_count"], 2)
            self.assertFalse((workspace / ".wps-agent" / "backups").exists())

    def test_write_spreadsheet_range_rejects_shape_mismatch(self):
        ok, result, errors, replayed = write_spreadsheet_range(
            "doc_missing",
            "A1:B2",
            [["A", "B"]],
            request_id="sheet-write-bad-shape",
            dry_run=True,
        )

        self.assertFalse(ok)
        self.assertFalse(replayed)
        self.assertEqual(result["range_shape"], [2, 2])
        self.assertEqual(result["values_shape"], [1, 2])
        self.assertEqual(errors[0]["code"], "RANGE_SHAPE_MISMATCH")

    def test_write_spreadsheet_formulas_dry_run_reports_shape(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()
            document = Path(tmp) / "sample.xlsx"
            workbook = Workbook()
            workbook.save(document)
            ok, record, _errors = register_document("spreadsheets", str(document), workspace)
            self.assertTrue(ok)

            ok, result, errors, replayed = write_spreadsheet_formulas(
                record["document_id"],
                "C1:C2",
                [["=A1+B1"], ["=A2+B2"]],
                expected_values=[[3], [7]],
                request_id="sheet-formula-dry",
                dry_run=True,
                workspace=workspace,
            )

            self.assertTrue(ok)
            self.assertFalse(replayed)
            self.assertEqual(errors, [])
            self.assertEqual(result["row_count"], 2)
            self.assertEqual(result["column_count"], 1)
            self.assertFalse((workspace / ".wps-agent" / "backups").exists())

    def test_write_spreadsheet_formulas_rejects_non_formula_string(self):
        ok, result, errors, replayed = write_spreadsheet_formulas(
            "doc_missing",
            "A1:A1",
            [["A1+B1"]],
            expected_values=[[3]],
            request_id="sheet-formula-invalid",
            dry_run=True,
        )

        self.assertFalse(ok)
        self.assertFalse(replayed)
        self.assertEqual(result, {})
        self.assertEqual(errors[0]["code"], "INVALID_ARGUMENT")

    def test_write_spreadsheet_formulas_rejects_expected_shape_mismatch(self):
        ok, result, errors, replayed = write_spreadsheet_formulas(
            "doc_missing",
            "A1:A2",
            [["=A1+B1"], ["=A2+B2"]],
            expected_values=[[3]],
            request_id="sheet-formula-bad-expected",
            dry_run=True,
        )

        self.assertFalse(ok)
        self.assertFalse(replayed)
        self.assertEqual(result["formulas_shape"], [2, 1])
        self.assertEqual(result["expected_values_shape"], [1, 1])
        self.assertEqual(errors[0]["code"], "EXPECTED_SHAPE_MISMATCH")


if __name__ == "__main__":
    unittest.main()
