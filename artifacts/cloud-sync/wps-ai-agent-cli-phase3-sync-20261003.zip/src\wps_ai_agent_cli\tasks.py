from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ProjectTask:
    id: str
    phase: str
    title: str
    status: str
    acceptance: str


TASKS: tuple[ProjectTask, ...] = (
    ProjectTask(
        id="P0-001",
        phase="phase0",
        title="Project skeleton and CLI entrypoint",
        status="done",
        acceptance="The inspect-env command returns structured JSON.",
    ),
    ProjectTask(
        id="P0-002",
        phase="phase0",
        title="WPS ProgID registration detection",
        status="done",
        acceptance="Detect COM registration without launching WPS.",
    ),
    ProjectTask(
        id="P0-003",
        phase="phase0",
        title="Structured command response model",
        status="done",
        acceptance="Responses include ok, request_id, backend, summary, validation, and errors.",
    ),
    ProjectTask(
        id="P0-004",
        phase="phase0",
        title="Phase task planning commands",
        status="done",
        acceptance="The plan and tasks commands expose the current roadmap.",
    ),
    ProjectTask(
        id="P0-005",
        phase="phase0",
        title="Minimal COM prototype",
        status="done",
        acceptance="Writer, Spreadsheets, and Presentation passed open/save/close smoke tests.",
    ),
    ProjectTask(
        id="P0-006",
        phase="phase0",
        title="Spreadsheet calculation verification sample",
        status="done",
        acceptance="Formula write, WPS calculation, raw value, and displayed text verification passed.",
    ),
    ProjectTask(
        id="P0-007",
        phase="phase0",
        title="Conversion loss matrix sample",
        status="done",
        acceptance="Writer DOCX to PDF conversion matrix sample is recorded with backend, retained features, and known losses.",
    ),
    ProjectTask(
        id="P0-008",
        phase="phase0",
        title="Phase 0 feasibility report",
        status="done",
        acceptance="Conditional go recommendation for Phase 1 is documented.",
    ),
    ProjectTask(
        id="P1-001",
        phase="phase1",
        title="document_id session model",
        status="done",
        acceptance="Documents can be registered, listed, and addressed by stable document_id.",
    ),
    ProjectTask(
        id="P1-002",
        phase="phase1",
        title="Mandatory pre-change backup",
        status="done",
        acceptance="Registered documents can be backed up by document_id before mutation.",
    ),
    ProjectTask(
        id="P1-003",
        phase="phase1",
        title="Request ID and idempotency protection",
        status="done",
        acceptance="Repeated backup requests with the same request_id replay the recorded result.",
    ),
    ProjectTask(
        id="P1-004",
        phase="phase1",
        title="Dry-run preview",
        status="done",
        acceptance="Writer replace dry-run previews body-scope match count without modifying the file.",
    ),
    ProjectTask(
        id="P1-005",
        phase="phase1",
        title="Basic validation hooks",
        status="done",
        acceptance="validate-document supports writer body text and spreadsheet cell value checks.",
    ),
    ProjectTask(
        id="P1-006",
        phase="phase1",
        title="Task status ledger",
        status="done",
        acceptance="Operations can be listed and queried by request_id.",
    ),
    ProjectTask(
        id="P1-007",
        phase="phase1",
        title="Batch file status report",
        status="done",
        acceptance="Directory files should be inspected with per-file component, existence, and registration status.",
    ),
    ProjectTask(
        id="P1-008",
        phase="phase1",
        title="Phase 1 consolidation report",
        status="done",
        acceptance="Summarize MVP CLI capabilities, verified commands, remaining gaps, and next implementation priorities.",
    ),
    ProjectTask(
        id="P1-009",
        phase="phase1",
        title="Writer scoped replace expansion",
        status="done",
        acceptance="writer-replace supports 1-based paragraph scoped replacement with matching dry-run and validation scope.",
    ),
    ProjectTask(
        id="P1-010",
        phase="phase1",
        title="Spreadsheet range read and write",
        status="done",
        acceptance="A1 range reads and writes support backup, COM write, read-back validation, and idempotency.",
    ),
    ProjectTask(
        id="P1-011",
        phase="phase1",
        title="Presentation placeholder text replacement",
        status="done",
        acceptance="Replace text in presentation placeholders or text boxes with backup, validation, and idempotency.",
    ),
    ProjectTask(
        id="P1-012",
        phase="phase1",
        title="Spreadsheet formula write and recalculation",
        status="done",
        acceptance="Write formulas to spreadsheet ranges, trigger WPS calculation, and validate cached results.",
    ),
    ProjectTask(
        id="P1-013",
        phase="phase1",
        title="Validation snapshot expansion",
        status="done",
        acceptance="Add stronger validation snapshots for docx text structure, xlsx formula errors, and pptx text object counts.",
    ),
    ProjectTask(
        id="P1-014",
        phase="phase1",
        title="Batch execution report",
        status="done",
        acceptance="Produce a batch-oriented report that combines directory scan, registration status, and validation snapshots.",
    ),
    ProjectTask(
        id="P1-015",
        phase="phase1",
        title="Backup inventory and restore",
        status="done",
        acceptance="List recoverable backups by document_id and restore a selected backup safely.",
    ),
    ProjectTask(
        id="P1-016",
        phase="phase1",
        title="Phase 1 release candidate audit",
        status="done",
        acceptance="Run a final capability audit, document remaining gaps, and produce a Phase 1 release candidate report.",
    ),
    ProjectTask(
        id="P2-001",
        phase="phase2",
        title="Long-running task status model",
        status="done",
        acceptance="Introduce a reusable status model for long-running WPS operations with progress, terminal state, and recovery guidance.",
    ),
    ProjectTask(
        id="P2-002",
        phase="phase2",
        title="Task status integration with mutating commands",
        status="done",
        acceptance="Attach task status creation and terminal updates to selected mutating WPS commands without breaking existing idempotency.",
    ),
    ProjectTask(
        id="P2-003",
        phase="phase2",
        title="Long-running task recovery playbooks",
        status="done",
        acceptance="Document and expose recovery playbooks for interrupted, failed, and ambiguous long-running WPS operations.",
    ),
    ProjectTask(
        id="P2-004",
        phase="phase2",
        title="MCP tool schema draft",
        status="done",
        acceptance="Draft MCP tool schemas that map current CLI commands to reusable agent-facing contracts and examples.",
    ),
    ProjectTask(
        id="P2-005",
        phase="phase2",
        title="MCP adapter implementation",
        status="done",
        acceptance="Implement an MCP adapter layer that exposes the drafted tool schemas through callable tool handlers backed by CLI core logic.",
    ),
    ProjectTask(
        id="P2-006",
        phase="phase2",
        title="MCP server prototype",
        status="done",
        acceptance="Prototype a local MCP server entrypoint that exposes the adapter tools over a standard MCP-compatible transport.",
    ),
    ProjectTask(
        id="P2-007",
        phase="phase2",
        title="MCP server client config and smoke harness",
        status="done",
        acceptance="Document local MCP server client configuration and add repeatable smoke checks for initialize, tools/list, and tools/call.",
    ),
    ProjectTask(
        id="P2-008",
        phase="phase2",
        title="MCP desktop integration audit",
        status="done",
        acceptance="Audit the local MCP server against a desktop client configuration and document any transport, path, or environment issues.",
    ),
    ProjectTask(
        id="P2-009",
        phase="phase2",
        title="Phase 2 final handoff report",
        status="done",
        acceptance="Produce a final Phase 2 handoff report summarizing MCP readiness, validation evidence, known limits, and next optional expansion areas.",
    ),
    ProjectTask(
        id="P3-001",
        phase="phase3",
        title="Production readiness plan and risk register",
        status="done",
        acceptance="Define Phase 3 production-readiness workstreams, risks, acceptance gates, and first regression targets.",
    ),
    ProjectTask(
        id="P3-002",
        phase="phase3",
        title="Regression suite manifest and smoke matrix",
        status="done",
        acceptance="Create a machine-readable regression manifest that enumerates critical CLI, MCP, and WPS smoke scenarios with expected evidence.",
    ),
    ProjectTask(
        id="P3-003",
        phase="phase3",
        title="Regression manifest WPS smoke execution",
        status="done",
        acceptance="Run the WPS-required regression profile in the real desktop environment and record component-level evidence and gaps.",
    ),
    ProjectTask(
        id="P3-004",
        phase="phase3",
        title="Regression result artifact export",
        status="done",
        acceptance="Persist regression-run output as timestamped JSON artifacts for CI, audit trails, and later comparison.",
    ),
    ProjectTask(
        id="P3-005",
        phase="phase3",
        title="Regression artifact CI handoff",
        status="done",
        acceptance="Document CI invocation, artifact retention path, and pass/fail gates for safe and WPS regression profiles.",
    ),
    ProjectTask(
        id="P3-006",
        phase="phase3",
        title="Recovery hardening drill",
        status="done",
        acceptance="Define and execute a focused failure drill for interrupted or failed document-mutating operations, including recovery evidence.",
    ),
    ProjectTask(
        id="P3-007",
        phase="phase3",
        title="Security boundary audit",
        status="done",
        acceptance="Audit mutating CLI and MCP tools for request_id, dry-run, backup, recovery guidance, and explicit WPS/file-system risk boundaries.",
    ),
    ProjectTask(
        id="P3-008",
        phase="phase3",
        title="Performance baseline capture",
        status="done",
        acceptance="Capture baseline runtime, output size, and evidence for core read-only and regression commands without launching WPS.",
    ),
    ProjectTask(
        id="P3-009",
        phase="phase3",
        title="Desktop MCP integration evidence refresh",
        status="done",
        acceptance="Refresh MCP desktop integration evidence against the current tool surface, including config audit, tools/list, tools/call, and any remaining real-client gap.",
    ),
    ProjectTask(
        id="P3-010",
        phase="phase3",
        title="Advanced WPS capability scoping",
        status="done",
        acceptance="Select the next advanced WPS capability and define fixture, dry-run, backup, validation, and smoke evidence requirements before implementation.",
    ),
    ProjectTask(
        id="P3-011",
        phase="phase3",
        title="Writer table cell update prototype",
        status="done",
        acceptance="Implement Writer table cell update with fixture, dry-run, backup, read-back validation, MCP schema, and WPS smoke evidence.",
    ),
    ProjectTask(
        id="P3-012",
        phase="phase3",
        title="Writer table regression integration",
        status="done",
        acceptance="Integrate writer table update into regression evidence, restore checks, and repeatable WPS smoke documentation without making safe CI launch desktop WPS.",
    ),
    ProjectTask(
        id="P3-013",
        phase="phase3",
        title="Spreadsheet WPS calc timeout investigation",
        status="done",
        acceptance="Diagnose and harden the WPS spreadsheet calc smoke timeout surfaced by the full WPS regression profile, preserving structured regression artifacts.",
    ),
    ProjectTask(
        id="P3-014",
        phase="phase3",
        title="WPS process lifecycle cleanup audit",
        status="done",
        acceptance="Audit WPS COM process lifecycle cleanup across smoke commands, capture stale-process diagnostics, and document safe cleanup guidance without killing user-owned processes automatically.",
    ),
    ProjectTask(
        id="P3-015",
        phase="phase3",
        title="Phase 3 release readiness refresh",
        status="done",
        acceptance="Refresh Phase 3 release readiness evidence, summarize current safe and WPS regression status, and list remaining production risks and handoff steps.",
    ),
    ProjectTask(
        id="P3-016",
        phase="phase3",
        title="Cloud sync readiness handoff",
        status="done",
        acceptance="Prepare project artifacts, evidence paths, and repository handoff notes needed to synchronize the current local project state to a cloud or remote project workspace.",
    ),
    ProjectTask(
        id="P3-017",
        phase="phase3",
        title="Remote cloud target selection",
        status="next",
        acceptance="Select the actual remote or cloud project target and execute the sync path chosen by the user, such as Git remote, archive upload, or connected cloud workspace.",
    ),
)


def list_tasks(phase: str | None = None, status: str | None = None) -> list[dict[str, str]]:
    tasks = TASKS
    if phase:
        tasks = tuple(task for task in tasks if task.phase == phase)
    if status:
        tasks = tuple(task for task in tasks if task.status == status)
    return [
        {
            "id": task.id,
            "phase": task.phase,
            "title": task.title,
            "status": task.status,
            "acceptance": task.acceptance,
        }
        for task in tasks
    ]
