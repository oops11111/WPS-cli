import tempfile
import unittest
from pathlib import Path

from wps_ai_agent_cli.sessions import list_documents, register_document, stable_document_id


class SessionRegistryTests(unittest.TestCase):
    def test_stable_document_id_is_repeatable(self):
        first = stable_document_id("writer", "sample.docx")
        second = stable_document_id("writer", "sample.docx")

        self.assertEqual(first, second)
        self.assertTrue(first.startswith("doc_"))

    def test_register_document_persists_record(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()
            document = Path(tmp) / "sample.docx"
            document.write_text("placeholder", encoding="utf-8")

            ok, record, errors = register_document(
                component="writer",
                path=str(document),
                workspace=workspace,
            )

            self.assertTrue(ok)
            self.assertEqual(errors, [])
            self.assertEqual(record["component"], "writer")
            self.assertEqual(list_documents(workspace)[0]["document_id"], record["document_id"])


if __name__ == "__main__":
    unittest.main()
