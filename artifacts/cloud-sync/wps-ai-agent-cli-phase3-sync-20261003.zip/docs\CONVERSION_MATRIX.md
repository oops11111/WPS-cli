# Phase 0 转换矩阵样例

## 已验证转换方向

| 方向 | 后端 | 输入 | 输出 | 方法 | 结果 |
| --- | --- | --- | --- | --- | --- |
| DOCX 到 PDF | WPS Writer COM | `1-WPS_AI_Agent_CLI_PRD_v1.1.docx` | `fixtures/phase0/phase0_writer_export.pdf` | `ExportAsFixedFormat` | passed |

## DOCX 到 PDF 记录

### 前提条件

- Windows 桌面环境可用。
- WPS Writer COM ProgID `kwps.Application` 已注册。
- 输入文件可由 WPS Writer 打开。
- 目标路径可写。

### 保留能力

- 文本内容。
- 页面布局。
- 基础表格。
- WPS 支持范围内的图片和页面元素。

### 已知损失

- PDF 输出不可作为 WPS 原生文档继续编辑。
- 交互字段、目录域或其他动态字段可能被扁平化。
- 导出结果依赖本机 WPS PDF 导出能力和字体环境。

### 实测证据

- 输出文件: `fixtures/phase0/phase0_writer_export.pdf`
- 输出大小: 242418 bytes
- 页数: 5
- 首页渲染: `fixtures/phase0/pdf_render/phase0_writer_export_page1.png`
- 文本抽取: 首页可抽取到 `WPS AI Agent CLI` 和 PRD 文档内容。

## 待验证转换方向

| 方向 | 优先级 | 状态 | 说明 |
| --- | --- | --- | --- |
| XLSX 到 PDF | high | pending | 需要记录公式结果、分页和工作表选择行为 |
| PPTX 到 PDF | high | pending | 需要记录幻灯片尺寸、字体和图片保真度 |
| DOCX 到 HTML | medium | pending | 需要区分 WPS SaveAs HTML 和浏览器视觉优先模式 |
| HTML 到 PDF | medium | pending | 属于 HTML 视觉优先基线，需要单独样例 |
