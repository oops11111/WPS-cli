import tempfile
import unittest
from pathlib import Path

from wps_ai_agent_cli.operations import get_operation, list_operations, record_operation


class OperationLedgerTests(unittest.TestCase):
    def test_record_get_and_list_operations(self):
        with tempfile.TemporaryDirectory() as tmp:
            workspace = Path(tmp) / "workspace"
            workspace.mkdir()

            record_operation("req-1", "sample", {"ok": True}, workspace)

            self.assertEqual(get_operation("req-1", workspace)["command"], "sample")
            operations = list_operations(workspace)
            self.assertEqual(len(operations), 1)
            self.assertEqual(operations[0]["request_id"], "req-1")


if __name__ == "__main__":
    unittest.main()
