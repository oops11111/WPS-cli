# MCP Server Client 配置与 Smoke Harness

## Client 配置

本地 MCP server 原型使用 stdio transport。示例配置见：

```text
config/mcp_client_config.example.json
```

通用配置形态：

```json
{
  "mcpServers": {
    "wps-ai-agent-cli": {
      "command": "C:\\Users\\admin\\.cache\\codex-runtimes\\codex-primary-runtime\\dependencies\\python\\python.exe",
      "args": ["-m", "wps_ai_agent_cli", "mcp-server"],
      "cwd": "C:\\Users\\admin\\Documents\\wps cli",
      "env": {
        "PYTHONPATH": "src"
      }
    }
  }
}
```

如果 Windows `python` 指向 Microsoft Store 占位符，应把 `command` 替换成本机可用解释器。本轮验证使用：

```powershell
C:\Users\admin\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe
```

## Repeatable Smoke

`mcp-smoke` 会在进程内重复跑三类请求：

1. `initialize`
2. `tools/list`
3. `tools/call`，默认调用 `wps_agent_tasks`

推荐命令：

```powershell
$env:PYTHONPATH = "src"
python -m wps_ai_agent_cli mcp-smoke --expected-min-tools 41 --tool-name wps_agent_tasks
python -m wps_ai_agent_cli mcp-config-audit --config config/mcp_client_config.example.json --server-name wps-ai-agent-cli --expected-min-tools 41
```

也可以逐条检查 JSON-RPC：

```powershell
python -m wps_ai_agent_cli mcp-server --once-json "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"initialize\",\"params\":{}}"
python -m wps_ai_agent_cli mcp-server --once-json "{\"jsonrpc\":\"2.0\",\"id\":2,\"method\":\"tools/list\",\"params\":{}}"
python -m wps_ai_agent_cli mcp-server --once-json "{\"jsonrpc\":\"2.0\",\"id\":3,\"method\":\"tools/call\",\"params\":{\"name\":\"wps_agent_tasks\",\"arguments\":{\"phase\":\"phase2\"}}}"
```

## Expected Results

- `initialize` 返回 `protocolVersion`、`serverInfo` 和 `capabilities.tools`。
- `tools/list` 当前返回 41 个工具。
- `tools/call` 返回 `isError = false`，并在 `structuredContent.mcp_call.response` 中包含原始 CLI `CommandResponse`。
- `mcp-smoke` 返回 `ok = true`，validation 中包含 `initialize_protocol`、`tools_list_count`、`tools_call_adapter` 三个 passed check。
- `mcp-config-audit` 返回 `ok = true`，validation 中包含 config、cwd、command、env 和 configured tools/list smoke 检查。
- P3-009 额外验证 `mcp-smoke --expected-min-tools 38 --tool-name wps_agent_security_audit`，覆盖无参工具的 `tools/call` adapter 路径；P3-014 后当前工具面为 41 个工具。

## Current Limits

- 当前 server 原型是单进程、无会话状态的 stdio JSON-RPC handler。
- 当前 client 配置是本地示例，不包含远程部署、权限隔离或 secret 管理。
- 修改类工具仍应传入稳定 `request_id`，并优先使用 `dry_run`。
