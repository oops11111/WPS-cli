import unittest
from unittest.mock import patch

from wps_ai_agent_cli.regression import (
    load_regression_manifest,
    list_regression_scenarios,
    _run_cli,
    run_regression_manifest,
)


class RegressionTests(unittest.TestCase):
    def test_load_manifest_and_filter_safe_scenarios(self):
        ok, manifest, errors = load_regression_manifest()
        scenarios = list_regression_scenarios(manifest, profile="safe")

        self.assertTrue(ok)
        self.assertEqual(errors, [])
        self.assertGreaterEqual(len(scenarios), 5)
        self.assertTrue(all(not scenario["requires_wps"] for scenario in scenarios))

    def test_run_safe_regression_manifest(self):
        ok, result, errors = run_regression_manifest(profile="safe")

        self.assertTrue(ok)
        self.assertEqual(errors, [])
        self.assertGreaterEqual(result["scenario_count"], 5)
        self.assertEqual(result["failed_count"], 0)

    def test_wps_scenarios_are_excluded_by_default(self):
        ok, manifest, _errors = load_regression_manifest()
        default_scenarios = list_regression_scenarios(manifest)
        all_scenarios = list_regression_scenarios(manifest, include_wps=True)

        self.assertTrue(ok)
        self.assertLess(len(default_scenarios), len(all_scenarios))
        self.assertTrue(any(scenario["requires_wps"] for scenario in all_scenarios))
        self.assertTrue(any(scenario["id"] == "writer-table-smoke" for scenario in all_scenarios))

    def test_run_cli_reports_exceptions_as_structured_failure(self):
        with patch("wps_ai_agent_cli.cli.run", side_effect=TimeoutError("slow command")):
            exit_code, payload, raw_output = _run_cli(["calc-smoke"])

        self.assertEqual(exit_code, 1)
        self.assertIsNotNone(payload)
        self.assertFalse(payload["ok"])
        self.assertEqual(payload["errors"][0]["exception_type"], "TimeoutError")
        self.assertIn("TimeoutError", raw_output)


if __name__ == "__main__":
    unittest.main()
