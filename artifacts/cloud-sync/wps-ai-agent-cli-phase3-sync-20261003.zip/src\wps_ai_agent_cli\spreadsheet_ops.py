from __future__ import annotations

import json
from pathlib import Path
import subprocess
import tempfile
from typing import Any

from openpyxl import load_workbook
from openpyxl.utils.cell import range_boundaries

from .backups import create_backup
from .capabilities import powershell_executable, probe_wps_capabilities
from .errors import COM_BACKEND_UNAVAILABLE, COM_OPERATION_FAILED, INPUT_FILE_NOT_FOUND
from .operations import get_operation, record_operation
from .sessions import get_document


def read_spreadsheet_range(
    document_id: str,
    range_address: str,
    sheet_name: str | None = None,
    workspace: str | Path = ".",
) -> tuple[bool, dict[str, Any], list[dict[str, str]]]:
    document = get_document(document_id, workspace)
    if not document:
        return (
            False,
            {},
            [{"code": "DOCUMENT_NOT_FOUND", "message": f"Document not registered: {document_id}"}],
        )
    if document["component"] != "spreadsheets":
        return (
            False,
            {"document": document},
            [{"code": "UNSUPPORTED_COMPONENT", "message": "spreadsheet-read requires a spreadsheet document."}],
        )

    path = Path(document["path"])
    if not path.exists():
        return (
            False,
            {"document": document},
            [{"code": INPUT_FILE_NOT_FOUND, "message": f"Input file not found: {path}"}],
        )

    workbook = load_workbook(path, data_only=True, read_only=True)
    try:
        if sheet_name:
            if sheet_name not in workbook.sheetnames:
                return (
                    False,
                    {"document": document, "sheet_names": workbook.sheetnames},
                    [{"code": "SHEET_NOT_FOUND", "message": f"Sheet not found: {sheet_name}"}],
                )
            sheet = workbook[sheet_name]
        else:
            sheet = workbook.worksheets[0]
        rows = []
        for row in sheet[range_address]:
            rows.append([cell.value for cell in row])
        return (
            True,
            {
                "document_id": document_id,
                "component": "spreadsheets",
                "path": str(path),
                "sheet": sheet.title,
                "range": range_address,
                "values": rows,
                "row_count": len(rows),
                "column_count": len(rows[0]) if rows else 0,
            },
            [],
        )
    finally:
        workbook.close()


def _matrix_shape(values: list[list[Any]]) -> tuple[int, int]:
    if not values:
        return 0, 0
    width = len(values[0])
    if width == 0:
        return len(values), 0
    for row in values:
        if len(row) != width:
            raise ValueError("values_json must be a rectangular 2D array.")
    return len(values), width


def _run_spreadsheet_write_com(
    path: str,
    sheet_name: str | None,
    range_address: str,
    values: list[list[Any]],
) -> dict[str, Any]:
    capabilities = probe_wps_capabilities()
    selected_prog_id = capabilities["components"]["spreadsheets"]["selected_prog_id"]
    if not selected_prog_id:
        return {
            "ok": False,
            "errors": [
                {
                    "code": COM_BACKEND_UNAVAILABLE,
                    "message": "No registered WPS ProgID detected for spreadsheets.",
                }
            ],
            "data": {"capabilities": capabilities},
        }

    min_col, min_row, max_col, max_row = range_boundaries(range_address)
    params = {
        "prog_id": selected_prog_id,
        "path": str(Path(path).resolve()),
        "sheet_name": sheet_name,
        "range": range_address,
        "start_row": min_row,
        "start_col": min_col,
        "row_count": max_row - min_row + 1,
        "column_count": max_col - min_col + 1,
        "values": values,
    }
    params_json = json.dumps(params)
    script = f"""
$ErrorActionPreference = 'Stop'
$params = @'
{params_json}
'@ | ConvertFrom-Json
$app = $null
$workbook = $null
try {{
  $app = New-Object -ComObject $params.prog_id
  try {{ $app.Visible = $false }} catch {{ }}
  $workbook = $app.Workbooks.Open($params.path)
  if ($null -ne $params.sheet_name -and $params.sheet_name -ne '') {{
    $sheet = $workbook.Worksheets.Item($params.sheet_name)
  }} else {{
    $sheet = $workbook.Worksheets.Item(1)
  }}
  $targetRange = $sheet.Range($params.range)
  for ($r = 0; $r -lt [int]$params.row_count; $r++) {{
    $row = @($params.values[$r])
    for ($c = 0; $c -lt [int]$params.column_count; $c++) {{
      $cell = $targetRange.Cells.Item($r + 1, $c + 1)
      $value = $row[$c]
      if ($null -eq $value) {{
        $cell.Value2 = $null
      }} elseif ($value -is [int] -or $value -is [long] -or $value -is [double] -or $value -is [decimal]) {{
        $cell.Value2 = [double]$value
      }} else {{
        $cell.Value2 = [string]$value
      }}
    }}
  }}
  $workbook.Save()
  [pscustomobject]@{{
    ok = $true
    backend = 'powershell-com'
    component = 'spreadsheets'
    prog_id = $params.prog_id
    path = $params.path
    sheet = $sheet.Name
    range = $params.range
    row_count = $params.row_count
    column_count = $params.column_count
  }} | ConvertTo-Json -Depth 5
}} catch {{
  [pscustomobject]@{{
    ok = $false
    backend = 'powershell-com'
    component = 'spreadsheets'
    prog_id = $params.prog_id
    error_type = $_.Exception.GetType().FullName
    error_message = $_.Exception.Message
    position = $_.InvocationInfo.PositionMessage
  }} | ConvertTo-Json -Depth 5
  exit 2
}} finally {{
  if ($workbook -ne $null) {{
    try {{ $workbook.Close($false) }} catch {{ }}
    try {{ [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($workbook) }} catch {{ }}
  }}
  if ($app -ne $null) {{
    try {{ $app.Quit() }} catch {{ }}
    try {{ [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($app) }} catch {{ }}
  }}
  [GC]::Collect()
  [GC]::WaitForPendingFinalizers()
}}
"""
    script_path = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            suffix=".ps1",
            delete=False,
            encoding="utf-8-sig",
        ) as script_file:
            script_file.write(script)
            script_path = script_file.name
        completed = subprocess.run(
            [
                powershell_executable(),
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                script_path,
            ],
            check=False,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            text=True,
            timeout=120,
        )
    finally:
        if script_path:
            try:
                Path(script_path).unlink(missing_ok=True)
            except OSError:
                pass

    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError:
        payload = None

    if completed.returncode != 0 or not isinstance(payload, dict):
        return {
            "ok": False,
            "errors": [
                {
                    "code": COM_OPERATION_FAILED,
                    "message": (
                        payload.get("error_message")
                        if isinstance(payload, dict)
                        else (completed.stderr or completed.stdout).strip()
                    ),
                }
            ],
            "data": {"diagnostic": payload, "backend": "powershell-com"},
        }
    return {"ok": True, "errors": [], "data": payload}


def _run_spreadsheet_formula_write_com(
    path: str,
    sheet_name: str | None,
    range_address: str,
    formulas: list[list[str]],
) -> dict[str, Any]:
    capabilities = probe_wps_capabilities()
    selected_prog_id = capabilities["components"]["spreadsheets"]["selected_prog_id"]
    if not selected_prog_id:
        return {
            "ok": False,
            "errors": [
                {
                    "code": COM_BACKEND_UNAVAILABLE,
                    "message": "No registered WPS ProgID detected for spreadsheets.",
                }
            ],
            "data": {"capabilities": capabilities},
        }

    min_col, min_row, max_col, max_row = range_boundaries(range_address)
    params = {
        "prog_id": selected_prog_id,
        "path": str(Path(path).resolve()),
        "sheet_name": sheet_name,
        "range": range_address,
        "start_row": min_row,
        "start_col": min_col,
        "row_count": max_row - min_row + 1,
        "column_count": max_col - min_col + 1,
        "formulas": formulas,
    }
    params_json = json.dumps(params)
    script = f"""
$ErrorActionPreference = 'Stop'
$params = @'
{params_json}
'@ | ConvertFrom-Json
$app = $null
$workbook = $null
try {{
  $app = New-Object -ComObject $params.prog_id
  try {{ $app.Visible = $false }} catch {{ }}
  $workbook = $app.Workbooks.Open($params.path)
  if ($null -ne $params.sheet_name -and $params.sheet_name -ne '') {{
    $sheet = $workbook.Worksheets.Item($params.sheet_name)
  }} else {{
    $sheet = $workbook.Worksheets.Item(1)
  }}
  $targetRange = $sheet.Range($params.range)
  for ($r = 0; $r -lt [int]$params.row_count; $r++) {{
    $row = @($params.formulas[$r])
    for ($c = 0; $c -lt [int]$params.column_count; $c++) {{
      $formula = [string]$row[$c]
      if (-not $formula.StartsWith('=')) {{
        throw "Formula must start with '=': $formula"
      }}
      $cell = $targetRange.Cells.Item($r + 1, $c + 1)
      $cell.Formula = $formula
    }}
  }}
  try {{ $app.CalculateFull() }} catch {{ try {{ $app.Calculate() }} catch {{ $workbook.RefreshAll() }} }}
  $workbook.Save()
  [pscustomobject]@{{
    ok = $true
    backend = 'powershell-com'
    component = 'spreadsheets'
    prog_id = $params.prog_id
    path = $params.path
    sheet = $sheet.Name
    range = $params.range
    row_count = $params.row_count
    column_count = $params.column_count
    calculation_triggered = $true
  }} | ConvertTo-Json -Depth 5
}} catch {{
  [pscustomobject]@{{
    ok = $false
    backend = 'powershell-com'
    component = 'spreadsheets'
    prog_id = $params.prog_id
    error_type = $_.Exception.GetType().FullName
    error_message = $_.Exception.Message
    position = $_.InvocationInfo.PositionMessage
  }} | ConvertTo-Json -Depth 5
  exit 2
}} finally {{
  if ($workbook -ne $null) {{
    try {{ $workbook.Close($false) }} catch {{ }}
    try {{ [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($workbook) }} catch {{ }}
  }}
  if ($app -ne $null) {{
    try {{ $app.Quit() }} catch {{ }}
    try {{ [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($app) }} catch {{ }}
  }}
  [GC]::Collect()
  [GC]::WaitForPendingFinalizers()
}}
"""
    script_path = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            suffix=".ps1",
            delete=False,
            encoding="utf-8-sig",
        ) as script_file:
            script_file.write(script)
            script_path = script_file.name
        completed = subprocess.run(
            [
                powershell_executable(),
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                script_path,
            ],
            check=False,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            text=True,
            timeout=120,
        )
    finally:
        if script_path:
            try:
                Path(script_path).unlink(missing_ok=True)
            except OSError:
                pass

    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError:
        payload = None

    if completed.returncode != 0 or not isinstance(payload, dict):
        return {
            "ok": False,
            "errors": [
                {
                    "code": COM_OPERATION_FAILED,
                    "message": (
                        payload.get("error_message")
                        if isinstance(payload, dict)
                        else (completed.stderr or completed.stdout).strip()
                    ),
                }
            ],
            "data": {"diagnostic": payload, "backend": "powershell-com"},
        }
    return {"ok": True, "errors": [], "data": payload}


def write_spreadsheet_range(
    document_id: str,
    range_address: str,
    values: list[list[Any]],
    request_id: str,
    sheet_name: str | None = None,
    dry_run: bool = False,
    workspace: str | Path = ".",
) -> tuple[bool, dict[str, Any], list[dict[str, str]], bool]:
    existing = get_operation(request_id, workspace)
    if existing and existing.get("command") == "spreadsheet-write":
        return True, dict(existing["result"]), [], True

    try:
        row_count, column_count = _matrix_shape(values)
    except ValueError as exc:
        return False, {}, [{"code": "INVALID_ARGUMENT", "message": str(exc)}], False
    if row_count == 0 or column_count == 0:
        return False, {}, [{"code": "INVALID_ARGUMENT", "message": "values_json must not be empty."}], False

    try:
        min_col, min_row, max_col, max_row = range_boundaries(range_address)
    except ValueError as exc:
        return False, {}, [{"code": "INVALID_ARGUMENT", "message": str(exc)}], False
    expected_rows = max_row - min_row + 1
    expected_cols = max_col - min_col + 1
    if (row_count, column_count) != (expected_rows, expected_cols):
        return (
            False,
            {
                "range": range_address,
                "range_shape": [expected_rows, expected_cols],
                "values_shape": [row_count, column_count],
            },
            [{"code": "RANGE_SHAPE_MISMATCH", "message": "values_json shape must match target range."}],
            False,
        )

    document = get_document(document_id, workspace)
    if not document:
        return False, {}, [{"code": "DOCUMENT_NOT_FOUND", "message": f"Document not registered: {document_id}"}], False
    if document["component"] != "spreadsheets":
        return (
            False,
            {"document": document},
            [{"code": "UNSUPPORTED_COMPONENT", "message": "spreadsheet-write requires a spreadsheet document."}],
            False,
        )
    path = Path(document["path"])
    if not path.exists():
        return False, {"document": document}, [{"code": INPUT_FILE_NOT_FOUND, "message": f"Input file not found: {path}"}], False

    preview = {
        "document_id": document_id,
        "component": "spreadsheets",
        "path": str(path),
        "sheet": sheet_name,
        "range": range_address,
        "values": values,
        "row_count": row_count,
        "column_count": column_count,
        "dry_run": dry_run,
    }
    if dry_run:
        return True, preview, [], False

    backup_ok, backup_result, backup_errors, backup_replayed = create_backup(
        document_id=document_id,
        request_id=f"{request_id}:backup",
        dry_run=False,
        workspace=workspace,
    )
    if not backup_ok:
        return False, {"preview": preview, "backup": backup_result}, backup_errors, False

    write_result = _run_spreadsheet_write_com(str(path), sheet_name, range_address, values)
    if not write_result["ok"]:
        return False, {"preview": preview, "backup": backup_result, "write": write_result["data"]}, write_result["errors"], False

    read_ok, read_result, read_errors = read_spreadsheet_range(
        document_id,
        range_address,
        sheet_name=sheet_name,
        workspace=workspace,
    )
    if not read_ok:
        return False, {"preview": preview, "backup": backup_result}, read_errors, False
    validation_passed = read_result["values"] == values
    result = {
        **preview,
        "dry_run": False,
        "sheet": read_result["sheet"],
        "backup": backup_result,
        "backup_replayed": backup_replayed,
        "write_backend": write_result["data"].get("backend"),
        "read_back_values": read_result["values"],
        "validation_passed": validation_passed,
    }
    if not validation_passed:
        return (
            False,
            result,
            [{"code": "VALIDATION_FAILED", "message": "Read-back values did not match written values."}],
            False,
        )

    record_operation(request_id, "spreadsheet-write", result, workspace)
    return True, result, [], False


def write_spreadsheet_formulas(
    document_id: str,
    range_address: str,
    formulas: list[list[Any]],
    expected_values: list[list[Any]],
    request_id: str,
    sheet_name: str | None = None,
    dry_run: bool = False,
    workspace: str | Path = ".",
) -> tuple[bool, dict[str, Any], list[dict[str, str]], bool]:
    existing = get_operation(request_id, workspace)
    if existing and existing.get("command") == "spreadsheet-formula-write":
        return True, dict(existing["result"]), [], True

    try:
        row_count, column_count = _matrix_shape(formulas)
    except ValueError as exc:
        return False, {}, [{"code": "INVALID_ARGUMENT", "message": str(exc)}], False
    if row_count == 0 or column_count == 0:
        return False, {}, [{"code": "INVALID_ARGUMENT", "message": "formulas_json must not be empty."}], False
    if any(not isinstance(formula, str) or not formula.startswith("=") for row in formulas for formula in row):
        return (
            False,
            {},
            [{"code": "INVALID_ARGUMENT", "message": "Every formula must be a string starting with '='."}],
            False,
        )

    try:
        expected_rows, expected_cols = _matrix_shape(expected_values)
    except ValueError as exc:
        return False, {}, [{"code": "INVALID_ARGUMENT", "message": str(exc)}], False
    if (expected_rows, expected_cols) != (row_count, column_count):
        return (
            False,
            {
                "formulas_shape": [row_count, column_count],
                "expected_values_shape": [expected_rows, expected_cols],
            },
            [{"code": "EXPECTED_SHAPE_MISMATCH", "message": "expected_values_json shape must match formulas_json."}],
            False,
        )

    try:
        min_col, min_row, max_col, max_row = range_boundaries(range_address)
    except ValueError as exc:
        return False, {}, [{"code": "INVALID_ARGUMENT", "message": str(exc)}], False
    expected_range_rows = max_row - min_row + 1
    expected_range_cols = max_col - min_col + 1
    if (row_count, column_count) != (expected_range_rows, expected_range_cols):
        return (
            False,
            {
                "range": range_address,
                "range_shape": [expected_range_rows, expected_range_cols],
                "formulas_shape": [row_count, column_count],
            },
            [{"code": "RANGE_SHAPE_MISMATCH", "message": "formulas_json shape must match target range."}],
            False,
        )

    document = get_document(document_id, workspace)
    if not document:
        return False, {}, [{"code": "DOCUMENT_NOT_FOUND", "message": f"Document not registered: {document_id}"}], False
    if document["component"] != "spreadsheets":
        return (
            False,
            {"document": document},
            [{"code": "UNSUPPORTED_COMPONENT", "message": "spreadsheet-formula-write requires a spreadsheet document."}],
            False,
        )
    path = Path(document["path"])
    if not path.exists():
        return False, {"document": document}, [{"code": INPUT_FILE_NOT_FOUND, "message": f"Input file not found: {path}"}], False

    preview = {
        "document_id": document_id,
        "component": "spreadsheets",
        "path": str(path),
        "sheet": sheet_name,
        "range": range_address,
        "formulas": formulas,
        "expected_values": expected_values,
        "row_count": row_count,
        "column_count": column_count,
        "dry_run": dry_run,
    }
    if dry_run:
        return True, preview, [], False

    backup_ok, backup_result, backup_errors, backup_replayed = create_backup(
        document_id=document_id,
        request_id=f"{request_id}:backup",
        dry_run=False,
        workspace=workspace,
    )
    if not backup_ok:
        return False, {"preview": preview, "backup": backup_result}, backup_errors, False

    write_result = _run_spreadsheet_formula_write_com(str(path), sheet_name, range_address, formulas)
    if not write_result["ok"]:
        return False, {"preview": preview, "backup": backup_result, "write": write_result["data"]}, write_result["errors"], False

    read_ok, read_result, read_errors = read_spreadsheet_range(
        document_id,
        range_address,
        sheet_name=sheet_name,
        workspace=workspace,
    )
    if not read_ok:
        return False, {"preview": preview, "backup": backup_result}, read_errors, False

    validation_passed = read_result["values"] == expected_values
    result = {
        **preview,
        "dry_run": False,
        "sheet": read_result["sheet"],
        "backup": backup_result,
        "backup_replayed": backup_replayed,
        "write_backend": write_result["data"].get("backend"),
        "calculation_triggered": write_result["data"].get("calculation_triggered"),
        "read_back_values": read_result["values"],
        "validation_passed": validation_passed,
    }
    if not validation_passed:
        return (
            False,
            result,
            [{"code": "VALIDATION_FAILED", "message": "Calculated values did not match expected_values_json."}],
            False,
        )

    record_operation(request_id, "spreadsheet-formula-write", result, workspace)
    return True, result, [], False
