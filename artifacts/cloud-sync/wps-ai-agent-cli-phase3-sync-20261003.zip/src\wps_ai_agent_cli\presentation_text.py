from __future__ import annotations

import re
from pathlib import Path
import xml.etree.ElementTree as ET
from zipfile import ZipFile


DRAWING_TEXT = "{http://schemas.openxmlformats.org/drawingml/2006/main}t"
SLIDE_RE = re.compile(r"ppt/slides/slide(\d+)\.xml$")


def _slide_parts(path: Path) -> list[tuple[int, str]]:
    with ZipFile(path) as archive:
        parts: list[tuple[int, str]] = []
        for name in archive.namelist():
            match = SLIDE_RE.match(name)
            if match:
                parts.append((int(match.group(1)), name))
    return sorted(parts)


def pptx_slide_texts(path: str | Path) -> list[dict[str, object]]:
    source = Path(path)
    slides = []
    with ZipFile(source) as archive:
        for slide_number, part_name in _slide_parts(source):
            root = ET.fromstring(archive.read(part_name))
            text = "".join(node.text or "" for node in root.iter(DRAWING_TEXT))
            slides.append(
                {
                    "slide_index": slide_number,
                    "part": part_name,
                    "text": text,
                }
            )
    return slides


def pptx_text_objects(path: str | Path) -> list[dict[str, object]]:
    source = Path(path)
    objects = []
    namespace = {
        "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
        "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    }
    with ZipFile(source) as archive:
        for slide_number, part_name in _slide_parts(source):
            root = ET.fromstring(archive.read(part_name))
            for object_index, shape in enumerate(root.findall(".//p:sp", namespace), start=1):
                text_body = shape.find(".//p:txBody", namespace)
                if text_body is None:
                    continue
                text = "".join(node.text or "" for node in text_body.findall(".//a:t", namespace))
                placeholder = shape.find(".//p:nvPr/p:ph", namespace)
                objects.append(
                    {
                        "slide_index": slide_number,
                        "object_index": object_index,
                        "part": part_name,
                        "text": text,
                        "text_length": len(text),
                        "is_empty": text == "",
                        "placeholder_type": placeholder.attrib.get("type") if placeholder is not None else None,
                    }
                )
    return objects


def count_text_in_pptx(
    path: str | Path,
    needle: str,
    slide_index: int | None = None,
) -> int:
    if not needle:
        return 0
    count = 0
    for slide in pptx_slide_texts(path):
        if slide_index is not None and slide["slide_index"] != slide_index:
            continue
        count += str(slide["text"]).count(needle)
    return count
