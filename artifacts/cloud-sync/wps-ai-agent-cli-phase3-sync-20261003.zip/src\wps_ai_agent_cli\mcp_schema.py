from __future__ import annotations

from typing import Any


SCHEMA_VERSION = "draft-2026-10-03"

COMMON_OUTPUT_CONTRACT: dict[str, Any] = {
    "type": "object",
    "description": "All tools return the shared CommandResponse envelope.",
    "required": ["ok", "command", "request_id", "backend", "summary", "data", "validation", "errors"],
    "properties": {
        "ok": {"type": "boolean"},
        "command": {"type": "string"},
        "request_id": {"type": "string"},
        "backend": {"type": "string"},
        "summary": {"type": "string"},
        "data": {"type": "object"},
        "validation": {"type": "object"},
        "errors": {"type": "array", "items": {"type": "object"}},
    },
}


def _string(description: str, enum: list[str] | None = None) -> dict[str, Any]:
    schema: dict[str, Any] = {"type": "string", "description": description}
    if enum:
        schema["enum"] = enum
    return schema


def _integer(description: str, minimum: int | None = None, maximum: int | None = None) -> dict[str, Any]:
    schema: dict[str, Any] = {"type": "integer", "description": description}
    if minimum is not None:
        schema["minimum"] = minimum
    if maximum is not None:
        schema["maximum"] = maximum
    return schema


def _boolean(description: str) -> dict[str, Any]:
    return {"type": "boolean", "description": description}


def _array(description: str) -> dict[str, Any]:
    return {"type": "array", "description": description, "items": {"type": "string"}}


def _object_schema(properties: dict[str, Any], required: list[str] | None = None) -> dict[str, Any]:
    merged = {
        "request_id": _string("Optional stable idempotency key for the CLI request."),
        **properties,
    }
    return {
        "type": "object",
        "additionalProperties": False,
        "required": required or [],
        "properties": merged,
    }


def _tool(
    name: str,
    cli_command: str,
    title: str,
    description: str,
    category: str,
    required: list[str] | None = None,
    properties: dict[str, Any] | None = None,
    mutates_document: bool = False,
    requires_wps: bool = False,
    idempotency: str = "Optional request_id is accepted for traceability.",
    cli_example: str | None = None,
    safety_notes: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "name": name,
        "cli_command": cli_command,
        "title": title,
        "description": description,
        "category": category,
        "mutates_document": mutates_document,
        "requires_wps": requires_wps,
        "idempotency": idempotency,
        "input_schema": _object_schema(properties or {}, required),
        "output_contract": COMMON_OUTPUT_CONTRACT,
        "cli_example": cli_example or f"python -m wps_ai_agent_cli {cli_command}",
        "safety_notes": safety_notes or [],
    }


MCP_TOOL_SCHEMAS: tuple[dict[str, Any], ...] = (
    _tool(
        "wps_agent_inspect_env",
        "inspect-env",
        "Inspect WPS environment",
        "Inspect OS, pywin32 availability, and WPS COM ProgID registration.",
        "environment",
    ),
    _tool(
        "wps_agent_wps_process_audit",
        "wps-process-audit",
        "Audit WPS processes",
        "List WPS-related processes and safe cleanup guidance without terminating anything.",
        "environment",
        properties={
            "timeout_seconds": _integer("Timeout for process inspection.", minimum=1),
        },
        cli_example="python -m wps_ai_agent_cli wps-process-audit",
    ),
    _tool(
        "wps_agent_plan",
        "plan",
        "Return roadmap",
        "Return the staged implementation roadmap.",
        "project",
    ),
    _tool(
        "wps_agent_tasks",
        "tasks",
        "List development tasks",
        "List staged development tasks with optional phase and status filters.",
        "project",
        properties={
            "phase": _string("Optional phase id such as phase0, phase1, or phase2."),
            "status": _string("Optional task status such as next or done."),
        },
        cli_example="python -m wps_ai_agent_cli tasks --phase phase2",
    ),
    _tool(
        "wps_agent_com_smoke",
        "com-smoke",
        "Run COM smoke test",
        "Open, save a copy, and close a WPS Writer, Spreadsheets, or Presentation file.",
        "smoke",
        required=["component", "input", "output"],
        properties={
            "component": _string("WPS component to exercise.", ["writer", "spreadsheets", "presentation"]),
            "input": _string("Input document path."),
            "output": _string("Output copy path."),
            "visible": _boolean("Show WPS during the smoke run."),
        },
        requires_wps=True,
        cli_example="python -m wps_ai_agent_cli com-smoke --component writer --input input.docx --output output.docx",
    ),
    _tool(
        "wps_agent_calc_smoke",
        "calc-smoke",
        "Run spreadsheet calculation smoke test",
        "Verify formula calculation through WPS Spreadsheets.",
        "smoke",
        required=["input", "output"],
        properties={
            "input": _string("Input workbook path."),
            "output": _string("Output workbook path."),
            "timeout_seconds": _integer("Timeout for the WPS spreadsheet COM smoke.", minimum=1),
        },
        requires_wps=True,
    ),
    _tool(
        "wps_agent_convert_smoke",
        "convert-smoke",
        "Run conversion smoke test",
        "Convert a WPS Writer document to PDF and report conversion evidence.",
        "smoke",
        required=["component", "input", "output", "format"],
        properties={
            "component": _string("Component to convert.", ["writer"]),
            "input": _string("Input file path."),
            "output": _string("Output file path."),
            "format": _string("Output format.", ["pdf"]),
        },
        requires_wps=True,
    ),
    _tool(
        "wps_agent_register_document",
        "register-document",
        "Register document",
        "Register a supported local file and return a stable document_id.",
        "documents",
        required=["component", "path"],
        properties={
            "component": _string("Document component.", ["writer", "spreadsheets", "presentation"]),
            "path": _string("Document path to register."),
        },
        cli_example="python -m wps_ai_agent_cli register-document --component writer --path input.docx",
    ),
    _tool(
        "wps_agent_documents",
        "documents",
        "List documents",
        "List registered documents and their current existence status.",
        "documents",
    ),
    _tool(
        "wps_agent_backup_document",
        "backup-document",
        "Create backup",
        "Create a recoverable backup for a registered document_id.",
        "safety",
        required=["document_id"],
        properties={
            "document_id": _string("Registered document_id."),
            "dry_run": _boolean("Preview the backup path without copying."),
            "task_id": _string("Optional long-running task status id."),
        },
        mutates_document=True,
        idempotency="Mutating command; request_id should be supplied and is replayed by the operation ledger.",
        safety_notes=[
            "Creates a filesystem backup under .wps-agent/backups; dry_run previews without copying.",
            "Use before document-changing commands when an explicit backup is needed.",
        ],
    ),
    _tool(
        "wps_agent_list_backups",
        "list-backups",
        "List backups",
        "List recoverable backups, optionally scoped to one document_id.",
        "safety",
        properties={"document_id": _string("Optional registered document_id.")},
    ),
    _tool(
        "wps_agent_restore_backup",
        "restore-backup",
        "Restore backup",
        "Restore a selected backup after first protecting the current file.",
        "safety",
        required=["document_id"],
        properties={
            "document_id": _string("Registered document_id."),
            "backup_name": _string("Backup filename from list-backups."),
            "backup_path": _string("Backup path from list-backups."),
            "dry_run": _boolean("Preview restore without copying."),
            "task_id": _string("Optional long-running task status id."),
        },
        mutates_document=True,
        idempotency="Mutating command; request_id should be supplied and is replayed by the operation ledger.",
        safety_notes=[
            "Restores a registered document from a backup and creates a pre-restore backup before overwriting.",
            "Provide either backup_name or backup_path; dry_run previews without copying.",
        ],
    ),
    _tool(
        "wps_agent_writer_replace",
        "writer-replace",
        "Replace Writer text",
        "Replace body text in a registered WPS Writer document with backup, dry-run, and validation.",
        "writer",
        required=["document_id", "find", "replace"],
        properties={
            "document_id": _string("Registered writer document_id."),
            "find": _string("Text to find."),
            "replace": _string("Replacement text."),
            "dry_run": _boolean("Preview matches without modifying the file."),
            "paragraph_index": _integer("Optional 1-based paragraph index.", minimum=1),
            "task_id": _string("Optional long-running task status id."),
        },
        mutates_document=True,
        requires_wps=True,
        idempotency="Mutating command; request_id should be supplied and is replayed by the operation ledger.",
        safety_notes=[
            "Uses WPS to mutate a registered Writer document and creates a backup before mutation.",
            "Use dry_run before mutation when possible.",
        ],
    ),
    _tool(
        "wps_agent_writer_table_write",
        "writer-table-write",
        "Write Writer table cell",
        "Write text to a table cell in a registered WPS Writer document with backup, dry-run, and validation.",
        "writer",
        required=["document_id", "table_index", "row", "column", "text"],
        properties={
            "document_id": _string("Registered writer document_id."),
            "table_index": _integer("1-based table index.", minimum=1),
            "row": _integer("1-based row index.", minimum=1),
            "column": _integer("1-based column index.", minimum=1),
            "text": _string("Replacement cell text."),
            "dry_run": _boolean("Preview target cell without modifying the file."),
            "task_id": _string("Optional long-running task status id."),
        },
        mutates_document=True,
        requires_wps=True,
        idempotency="Mutating command; request_id should be supplied and is replayed by the operation ledger.",
        safety_notes=[
            "Uses WPS to mutate a registered Writer table cell and creates a backup before mutation.",
            "Use dry_run before mutation; table, row, and column are 1-based and validated before write.",
        ],
    ),
    _tool(
        "wps_agent_writer_table_smoke",
        "writer-table-smoke",
        "Smoke Writer table cell update",
        "Run a repeatable WPS Writer table cell update smoke test against an output copy with backup and restore dry-run checks.",
        "smoke",
        required=["input", "output", "table_index", "row", "column", "text"],
        properties={
            "input": _string("Input Writer fixture path."),
            "output": _string("Output copy path."),
            "table_index": _integer("1-based table index.", minimum=1),
            "row": _integer("1-based row index.", minimum=1),
            "column": _integer("1-based column index.", minimum=1),
            "text": _string("Replacement cell text."),
            "task_id": _string("Optional long-running task status id."),
        },
        mutates_document=True,
        requires_wps=True,
        idempotency="Mutating smoke command; request_id should be supplied for traceable child write and restore-check operations.",
        safety_notes=[
            "Copies the input fixture to the requested output path before launching WPS.",
            "Uses WPS to mutate the output Writer table cell, creates a backup, and verifies restore dry-run availability.",
        ],
    ),
    _tool(
        "wps_agent_validate_document",
        "validate-document",
        "Validate document",
        "Run basic validation checks against a registered document.",
        "validation",
        required=["document_id"],
        properties={
            "document_id": _string("Registered document_id."),
            "contains": _string("Expected body text for writer documents."),
            "cell": _string("Cell address for spreadsheet validation."),
            "equals": _string("Expected cell value for spreadsheet validation."),
        },
    ),
    _tool(
        "wps_agent_snapshot_document",
        "snapshot-document",
        "Snapshot document",
        "Return a structural validation snapshot for a registered document.",
        "validation",
        required=["document_id"],
        properties={"document_id": _string("Registered document_id.")},
    ),
    _tool(
        "wps_agent_operation",
        "operation",
        "Get operation",
        "Return a recorded operation by request_id.",
        "operations",
        required=["request"],
        properties={"request": _string("Recorded operation request_id.")},
    ),
    _tool(
        "wps_agent_operations",
        "operations",
        "List operations",
        "List recorded operation ledger entries.",
        "operations",
    ),
    _tool(
        "wps_agent_task_status_create",
        "task-status-create",
        "Create task status",
        "Create a reusable status record for a long-running task.",
        "tasks",
        required=["command", "operation_request_id"],
        properties={
            "task_id": _string("Optional stable task id."),
            "command": _string("Command or workflow being tracked."),
            "operation_request_id": _string("Request id for the tracked operation."),
            "document_id": _string("Optional related document_id."),
            "message": _string("Initial status message."),
            "recovery_guidance": _array("Recovery guidance items."),
        },
    ),
    _tool(
        "wps_agent_task_status_update",
        "task-status-update",
        "Update task status",
        "Update a long-running task status record.",
        "tasks",
        required=["task_id", "state"],
        properties={
            "task_id": _string("Task id to update."),
            "state": _string("New task state.", ["pending", "running", "succeeded", "failed", "cancelled"]),
            "progress_percent": _integer("Progress percentage.", minimum=0, maximum=100),
            "message": _string("Updated status message."),
            "recovery_guidance": _array("Recovery guidance items."),
            "result_ref": _string("Optional operation request id or output reference."),
        },
    ),
    _tool(
        "wps_agent_task_status",
        "task-status",
        "Get task status",
        "Return one long-running task status record.",
        "tasks",
        required=["task_id"],
        properties={"task_id": _string("Task id to return.")},
    ),
    _tool(
        "wps_agent_task_statuses",
        "task-statuses",
        "List task statuses",
        "List long-running task status records.",
        "tasks",
    ),
    _tool(
        "wps_agent_task_recovery",
        "task-recovery",
        "Get recovery playbook",
        "Return a recovery playbook for a long-running task status.",
        "recovery",
        required=["task_id"],
        properties={"task_id": _string("Task id to recover or inspect.")},
    ),
    _tool(
        "wps_agent_task_recovery_playbooks",
        "task-recovery-playbooks",
        "List recovery playbooks",
        "List available long-running task recovery playbooks.",
        "recovery",
    ),
    _tool(
        "wps_agent_mcp_tools",
        "mcp-tools",
        "List MCP tool schemas",
        "List draft MCP tool schemas mapped from CLI commands.",
        "mcp",
        properties={
            "category": _string("Optional tool category filter."),
            "mutates_document": _string("Optional mutation filter.", ["true", "false"]),
        },
    ),
    _tool(
        "wps_agent_mcp_tool_schema",
        "mcp-tool-schema",
        "Get MCP tool schema",
        "Return one draft MCP tool schema by MCP tool name or CLI command.",
        "mcp",
        required=["name"],
        properties={"name": _string("MCP tool name or CLI command.")},
    ),
    _tool(
        "wps_agent_mcp_call",
        "mcp-call",
        "Call MCP tool adapter",
        "Invoke a draft MCP tool by mapping JSON arguments to the existing CLI response layer.",
        "mcp",
        required=["name"],
        properties={
            "name": _string("MCP tool name or CLI command."),
            "arguments_json": _string("JSON object of tool arguments."),
        },
    ),
    _tool(
        "wps_agent_mcp_server",
        "mcp-server",
        "Run MCP server prototype",
        "Run a local MCP-compatible JSON-RPC server prototype over stdio.",
        "mcp",
        properties={
            "once_json": _string("Optional single JSON-RPC request for smoke tests."),
        },
    ),
    _tool(
        "wps_agent_mcp_smoke",
        "mcp-smoke",
        "Run MCP server smoke checks",
        "Run repeatable MCP server smoke checks for initialize, tools/list, and tools/call.",
        "mcp",
        properties={
            "expected_min_tools": _integer("Minimum number of tools expected from tools/list.", minimum=1),
            "tool_name": _string("Tool name to exercise through tools/call."),
        },
    ),
    _tool(
        "wps_agent_mcp_config_audit",
        "mcp-config-audit",
        "Audit MCP client config",
        "Audit a local MCP client config and run a configured tools/list smoke check.",
        "mcp",
        properties={
            "config": _string("Path to MCP client config JSON."),
            "server_name": _string("Server key under mcpServers."),
            "expected_min_tools": _integer("Minimum number of tools expected from tools/list.", minimum=1),
            "timeout_seconds": _integer("Timeout for the configured tools/list smoke.", minimum=1),
        },
    ),
    _tool(
        "wps_agent_regression_manifest",
        "regression-manifest",
        "List regression manifest scenarios",
        "List regression manifest scenarios and smoke matrix metadata.",
        "regression",
        properties={
            "manifest": _string("Path to regression manifest JSON."),
            "profile": _string("Optional scenario profile filter."),
            "include_wps": _boolean("Include scenarios that require WPS."),
        },
    ),
    _tool(
        "wps_agent_regression_run",
        "regression-run",
        "Run regression manifest",
        "Run regression scenarios from the manifest.",
        "regression",
        properties={
            "manifest": _string("Path to regression manifest JSON."),
            "profile": _string("Optional scenario profile filter."),
            "include_wps": _boolean("Include scenarios that require WPS."),
            "artifact_dir": _string("Optional directory where a timestamped regression-run JSON artifact will be written."),
        },
    ),
    _tool(
        "wps_agent_scan_dir",
        "scan-dir",
        "Scan directory",
        "Scan a directory for supported WPS files and registration status.",
        "batch",
        required=["path"],
        properties={"path": _string("Directory to scan."), "recursive": _boolean("Scan recursively.")},
    ),
    _tool(
        "wps_agent_batch_report",
        "batch-report",
        "Build batch report",
        "Combine directory scan, registration status, and validation snapshots.",
        "batch",
        required=["path"],
        properties={
            "path": _string("Directory to report on."),
            "recursive": _boolean("Report recursively."),
            "no_snapshots": _boolean("Skip validation snapshots."),
        },
    ),
    _tool(
        "wps_agent_spreadsheet_read",
        "spreadsheet-read",
        "Read spreadsheet range",
        "Read an A1 range from a registered spreadsheet document.",
        "spreadsheet",
        required=["document_id", "range"],
        properties={
            "document_id": _string("Registered spreadsheet document_id."),
            "range": _string("A1 range to read, for example A1:D6."),
            "sheet": _string("Optional sheet name. Defaults to first sheet."),
        },
    ),
    _tool(
        "wps_agent_spreadsheet_write",
        "spreadsheet-write",
        "Write spreadsheet range",
        "Write a JSON matrix to an A1 range in a registered spreadsheet document.",
        "spreadsheet",
        required=["document_id", "range", "values_json"],
        properties={
            "document_id": _string("Registered spreadsheet document_id."),
            "range": _string("A1 range to write, for example A1:B2."),
            "values_json": _string("Rectangular JSON matrix, for example [[1,2],[3,4]]."),
            "sheet": _string("Optional sheet name. Defaults to first sheet."),
            "dry_run": _boolean("Preview write shape without modifying the file."),
            "task_id": _string("Optional long-running task status id."),
        },
        mutates_document=True,
        requires_wps=True,
        idempotency="Mutating command; request_id should be supplied and is replayed by the operation ledger.",
        safety_notes=[
            "Uses WPS to mutate a registered spreadsheet and creates a backup before mutation.",
            "Creates a backup before mutation and validates read-back results.",
        ],
    ),
    _tool(
        "wps_agent_spreadsheet_formula_write",
        "spreadsheet-formula-write",
        "Write spreadsheet formulas",
        "Write formulas to an A1 range, recalculate with WPS, and validate cached values.",
        "spreadsheet",
        required=["document_id", "range", "formulas_json", "expected_values_json"],
        properties={
            "document_id": _string("Registered spreadsheet document_id."),
            "range": _string("A1 range to write, for example D4:D6."),
            "formulas_json": _string("Rectangular JSON matrix of formulas."),
            "expected_values_json": _string("Rectangular JSON matrix of expected cached values."),
            "sheet": _string("Optional sheet name. Defaults to first sheet."),
            "dry_run": _boolean("Preview formula write shape without modifying the file."),
            "task_id": _string("Optional long-running task status id."),
        },
        mutates_document=True,
        requires_wps=True,
        idempotency="Mutating command; request_id should be supplied and is replayed by the operation ledger.",
        safety_notes=[
            "Uses WPS to mutate formulas in a registered spreadsheet and creates a backup before mutation.",
            "Use dry_run before mutation when possible and validate cached calculation results after write.",
        ],
    ),
    _tool(
        "wps_agent_presentation_replace",
        "presentation-replace",
        "Replace presentation text",
        "Replace text in a registered presentation with backup, validation, and idempotency.",
        "presentation",
        required=["document_id", "find", "replace"],
        properties={
            "document_id": _string("Registered presentation document_id."),
            "find": _string("Text to find."),
            "replace": _string("Replacement text."),
            "dry_run": _boolean("Preview matches without modifying the file."),
            "slide_index": _integer("Optional 1-based slide index.", minimum=1),
            "task_id": _string("Optional long-running task status id."),
        },
        mutates_document=True,
        requires_wps=True,
        idempotency="Mutating command; request_id should be supplied and is replayed by the operation ledger.",
        safety_notes=[
            "Uses WPS to mutate a registered presentation and creates a backup before mutation.",
            "Use dry_run before mutation when possible and validate replacement results after write.",
        ],
    ),
    _tool(
        "wps_agent_security_audit",
        "security-audit",
        "Audit security boundaries",
        "Audit mutating CLI and MCP tool safety boundaries.",
        "security",
    ),
    _tool(
        "wps_agent_performance_baseline",
        "performance-baseline",
        "Capture performance baseline",
        "Capture runtime and output-size baselines for safe read-only commands.",
        "performance",
    ),
)


def list_mcp_tool_schemas(
    category: str | None = None,
    mutates_document: bool | None = None,
) -> list[dict[str, Any]]:
    schemas = [dict(schema) for schema in MCP_TOOL_SCHEMAS]
    if category:
        schemas = [schema for schema in schemas if schema["category"] == category]
    if mutates_document is not None:
        schemas = [schema for schema in schemas if schema["mutates_document"] is mutates_document]
    return schemas


def get_mcp_tool_schema(name: str) -> dict[str, Any] | None:
    for schema in MCP_TOOL_SCHEMAS:
        if schema["name"] == name or schema["cli_command"] == name:
            return dict(schema)
    return None


def list_mcp_tool_categories() -> list[str]:
    return sorted({schema["category"] for schema in MCP_TOOL_SCHEMAS})
