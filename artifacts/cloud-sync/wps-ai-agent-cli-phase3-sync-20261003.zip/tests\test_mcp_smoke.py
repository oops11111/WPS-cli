import unittest

from wps_ai_agent_cli.mcp_smoke import run_mcp_server_smoke


class McpSmokeTests(unittest.TestCase):
    def test_mcp_server_smoke_passes_for_tasks_tool(self):
        ok, result, errors = run_mcp_server_smoke(
            expected_min_tools=1,
            tool_name="wps_agent_tasks",
        )

        self.assertTrue(ok)
        self.assertEqual(errors, [])
        self.assertTrue(all(check["passed"] for check in result["checks"]))
        self.assertEqual(
            result["responses"]["tools_call"]["result"]["structuredContent"]["mcp_call"]["response"]["command"],
            "tasks",
        )

    def test_mcp_server_smoke_fails_when_tool_count_expectation_is_too_high(self):
        ok, result, errors = run_mcp_server_smoke(expected_min_tools=10_000)

        self.assertFalse(ok)
        self.assertEqual(errors[0]["code"], "MCP_SMOKE_FAILED")
        self.assertFalse(result["checks"][1]["passed"])

    def test_mcp_server_smoke_passes_for_no_argument_tool(self):
        ok, result, errors = run_mcp_server_smoke(
            expected_min_tools=1,
            tool_name="wps_agent_security_audit",
        )

        self.assertTrue(ok)
        self.assertEqual(errors, [])
        self.assertEqual(
            result["responses"]["tools_call"]["result"]["structuredContent"]["mcp_call"]["response"]["command"],
            "security-audit",
        )


if __name__ == "__main__":
    unittest.main()
