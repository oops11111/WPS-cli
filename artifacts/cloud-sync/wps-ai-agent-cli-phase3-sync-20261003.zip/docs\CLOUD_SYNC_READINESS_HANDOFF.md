# Cloud Sync Readiness Handoff

## Current Workspace

Local project root:

```text
C:\Users\admin\Documents\wps cli
```

This workspace is not currently initialized as a Git repository. Cloud sync therefore needs one selected target workflow before execution.

## Recommended Sync Scope

Include:

- `src\`
- `tests\`
- `config\`
- `docs\`
- `fixtures\`
- `artifacts\regression\safe\regression-run-20261003T105522479191Z-regression-writer-table-p3-015-final-safe.json`
- `artifacts\regression\wps\regression-run-20261003T105030651877Z-regression-writer-table-p3-013-wps-003.json`

Exclude or regenerate:

- `.wps-agent\backups\` unless recovery evidence must be preserved
- transient WPS output probes not referenced by release reports
- Python caches such as `__pycache__`

## Verification Before Sync

```powershell
$env:PYTHONPATH='src'
python -m unittest discover -s tests
python -m wps_ai_agent_cli regression-run --profile safe --artifact-dir artifacts\regression\safe
```

Optional local desktop WPS validation:

```powershell
python -m wps_ai_agent_cli regression-run --profile wps --include-wps --artifact-dir artifacts\regression\wps
python -m wps_ai_agent_cli wps-process-audit
```

## Remote Target Options

Choose one:

- Initialize Git here and push to a remote repository.
- Package the recommended sync scope into an archive for upload.
- Connect a cloud project workspace and copy the recommended sync scope there.
- Use an installed connector such as Google Drive, Dropbox, SharePoint, or Box if the target is document-storage oriented.

## Current Release Evidence

- Release readiness: `docs\PHASE3_RELEASE_READINESS_REFRESH.md`
- Safe regression final artifact: `artifacts\regression\safe\regression-run-20261003T105522479191Z-regression-writer-table-p3-015-final-safe.json`
- WPS regression final artifact: `artifacts\regression\wps\regression-run-20261003T105030651877Z-regression-writer-table-p3-013-wps-003.json`
- WPS process audit: `docs\P3_WPS_PROCESS_LIFECYCLE_AUDIT_REPORT.md`

## Next Decision

P3-017 should select the actual remote/cloud target and execute the chosen sync route.
