import io
import json
import unittest

from wps_ai_agent_cli.mcp_server import handle_mcp_json, handle_mcp_request, serve_stdio


class McpServerTests(unittest.TestCase):
    def test_initialize_returns_server_capabilities(self):
        response = handle_mcp_request(
            {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}}
        )

        self.assertEqual(response["jsonrpc"], "2.0")
        self.assertEqual(response["id"], 1)
        self.assertIn("protocolVersion", response["result"])
        self.assertFalse(response["result"]["capabilities"]["tools"]["listChanged"])

    def test_tools_list_returns_mcp_tool_shapes(self):
        response = handle_mcp_request(
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
        )
        tools = response["result"]["tools"]
        names = {tool["name"] for tool in tools}

        self.assertEqual(response["result"]["resultType"], "complete")
        self.assertIn("wps_agent_tasks", names)
        self.assertIn("wps_agent_mcp_server", names)
        self.assertIn("inputSchema", tools[0])

    def test_tools_call_uses_adapter(self):
        response = handle_mcp_request(
            {
                "jsonrpc": "2.0",
                "id": 3,
                "method": "tools/call",
                "params": {
                    "name": "wps_agent_tasks",
                    "arguments": {"phase": "phase2", "request_id": "mcp-server-test-001"},
                },
            }
        )

        self.assertFalse(response["result"]["isError"])
        self.assertEqual(
            response["result"]["structuredContent"]["mcp_call"]["response"]["command"],
            "tasks",
        )

    def test_handle_mcp_json_reports_parse_error(self):
        response = handle_mcp_json("{not-json")

        self.assertEqual(response["error"]["code"], -32700)

    def test_serve_stdio_writes_line_delimited_json_rpc(self):
        input_stream = io.StringIO(
            json.dumps({"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}})
            + "\n"
        )
        output_stream = io.StringIO()

        exit_code = serve_stdio(input_stream=input_stream, output_stream=output_stream)
        response = json.loads(output_stream.getvalue())

        self.assertEqual(exit_code, 0)
        self.assertEqual(response["id"], 1)
        self.assertIn("tools", response["result"])


if __name__ == "__main__":
    unittest.main()
