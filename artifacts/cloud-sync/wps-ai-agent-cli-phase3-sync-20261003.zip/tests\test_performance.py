import unittest

from wps_ai_agent_cli.performance import capture_performance_baseline


class PerformanceBaselineTests(unittest.TestCase):
    def test_capture_performance_baseline_uses_safe_commands(self):
        ok, result, errors = capture_performance_baseline()

        self.assertTrue(ok)
        self.assertEqual(errors, [])
        self.assertGreaterEqual(result["scenario_count"], 6)
        self.assertEqual(result["failed_count"], 0)
        self.assertFalse(result["launches_wps"])
        self.assertGreater(result["total_duration_ms"], 0)
        self.assertGreater(result["total_output_bytes"], 0)
        self.assertTrue(all(not item["launches_wps"] for item in result["results"]))


if __name__ == "__main__":
    unittest.main()
