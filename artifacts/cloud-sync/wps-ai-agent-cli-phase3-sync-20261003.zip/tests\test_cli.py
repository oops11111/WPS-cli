import io
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from wps_ai_agent_cli.cli import (
    _configure_stdout,
    _extract_request_id,
    _with_optional_task_status,
    build_parser,
    regression_run_response,
)
from wps_ai_agent_cli.models import CommandResponse, ValidationResult


class CliParsingTests(unittest.TestCase):
    def test_extract_request_id_after_subcommand(self):
        argv, request_id = _extract_request_id(
            ["backup-document", "--document-id", "doc_1", "--request-id", "req-1"]
        )

        self.assertEqual(request_id, "req-1")
        self.assertEqual(argv, ["backup-document", "--document-id", "doc_1"])

    def test_extract_request_id_equals_form(self):
        argv, request_id = _extract_request_id(["tasks", "--request-id=req-2"])

        self.assertEqual(request_id, "req-2")
        self.assertEqual(argv, ["tasks"])

    def test_configure_stdout_prefers_utf8(self):
        stream = io.TextIOWrapper(io.BytesIO(), encoding="gbk")
        with patch("sys.stdout", stream):
            _configure_stdout()
            self.assertEqual(stream.encoding.lower().replace("_", "-"), "utf-8")

    def test_mutating_command_parsers_accept_task_id(self):
        parser = build_parser()

        args = parser.parse_args([
            "backup-document",
            "--document-id",
            "doc_1",
            "--task-id",
            "task_1",
        ])

        self.assertEqual(args.command, "backup-document")
        self.assertEqual(args.task_id, "task_1")

    def test_task_recovery_parser_accepts_task_id(self):
        parser = build_parser()

        args = parser.parse_args(["task-recovery", "--task-id", "task_1"])

        self.assertEqual(args.command, "task-recovery")
        self.assertEqual(args.task_id, "task_1")

    def test_mcp_schema_parsers_accept_filters_and_names(self):
        parser = build_parser()

        list_args = parser.parse_args(["mcp-tools", "--category", "spreadsheet", "--mutates-document", "true"])
        schema_args = parser.parse_args(["mcp-tool-schema", "--name", "wps_agent_writer_replace"])
        call_args = parser.parse_args(["mcp-call", "--name", "wps_agent_tasks", "--arguments-json", "{\"phase\":\"phase2\"}"])
        server_args = parser.parse_args(["mcp-server", "--once-json", "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"tools/list\"}"])
        smoke_args = parser.parse_args(["mcp-smoke", "--expected-min-tools", "10", "--tool-name", "wps_agent_tasks"])
        audit_args = parser.parse_args(["mcp-config-audit", "--config", "config/mcp_client_config.example.json"])
        manifest_args = parser.parse_args(["regression-manifest", "--profile", "safe"])
        run_args = parser.parse_args(["regression-run", "--profile", "safe"])
        run_artifact_args = parser.parse_args(["regression-run", "--profile", "safe", "--artifact-dir", "artifacts/regression"])
        security_args = parser.parse_args(["security-audit"])
        performance_args = parser.parse_args(["performance-baseline"])
        process_audit_args = parser.parse_args(["wps-process-audit", "--timeout-seconds", "4"])
        writer_table_args = parser.parse_args([
            "writer-table-write",
            "--document-id",
            "doc_1",
            "--table-index",
            "1",
            "--row",
            "2",
            "--column",
            "3",
            "--text",
            "Approved",
        ])
        writer_table_smoke_args = parser.parse_args([
            "writer-table-smoke",
            "--input",
            "fixtures/phase3/writer_table_fixture.docx",
            "--output",
            "fixtures/phase3/writer_table_regression_smoke.docx",
            "--table-index",
            "1",
            "--row",
            "2",
            "--column",
            "3",
            "--text",
            "Regression",
        ])

        self.assertEqual(list_args.command, "mcp-tools")
        self.assertEqual(list_args.category, "spreadsheet")
        self.assertEqual(list_args.mutates_document, "true")
        self.assertEqual(schema_args.command, "mcp-tool-schema")
        self.assertEqual(schema_args.name, "wps_agent_writer_replace")
        self.assertEqual(call_args.command, "mcp-call")
        self.assertEqual(call_args.name, "wps_agent_tasks")
        self.assertEqual(server_args.command, "mcp-server")
        self.assertIn("tools/list", server_args.once_json)
        calc_args = parser.parse_args(["calc-smoke", "--input", "in.xlsx", "--output", "out.xlsx", "--timeout-seconds", "3"])

        self.assertEqual(smoke_args.command, "mcp-smoke")
        self.assertEqual(smoke_args.expected_min_tools, 10)
        self.assertEqual(smoke_args.tool_name, "wps_agent_tasks")
        self.assertEqual(calc_args.command, "calc-smoke")
        self.assertEqual(calc_args.timeout_seconds, 3)
        self.assertEqual(audit_args.command, "mcp-config-audit")
        self.assertEqual(audit_args.config, "config/mcp_client_config.example.json")
        self.assertEqual(manifest_args.command, "regression-manifest")
        self.assertEqual(manifest_args.profile, "safe")
        self.assertEqual(run_args.command, "regression-run")
        self.assertEqual(run_args.profile, "safe")
        self.assertEqual(run_artifact_args.artifact_dir, "artifacts/regression")
        self.assertEqual(security_args.command, "security-audit")
        self.assertEqual(performance_args.command, "performance-baseline")
        self.assertEqual(process_audit_args.command, "wps-process-audit")
        self.assertEqual(process_audit_args.timeout_seconds, 4)
        self.assertEqual(writer_table_args.command, "writer-table-write")
        self.assertEqual(writer_table_args.table_index, 1)
        self.assertEqual(writer_table_smoke_args.command, "writer-table-smoke")
        self.assertEqual(writer_table_smoke_args.text, "Regression")

    def test_regression_run_response_writes_artifact(self):
        with TemporaryDirectory() as tmpdir:
            response = regression_run_response(
                "req_artifact_1",
                manifest_path="config/regression_manifest.json",
                profile="safe",
                include_wps=False,
                artifact_dir=tmpdir,
            )

            artifact = response.data["artifact"]
            artifact_path = Path(artifact["path"])
            payload = json.loads(artifact_path.read_text(encoding="utf-8"))

        self.assertTrue(response.ok)
        self.assertTrue(artifact["created"])
        self.assertEqual(artifact_path.name, artifact["filename"])
        self.assertEqual(payload["request_id"], "req_artifact_1")
        self.assertEqual(payload["data"]["regression"]["failed_count"], 0)

    def test_optional_task_status_marks_success_and_attaches_status(self):
        statuses = {
            "task_1": {
                "task_id": "task_1",
                "state": "pending",
                "terminal": False,
                "progress_percent": 0,
            }
        }

        def fake_create_task_status(**_kwargs):
            return True, dict(statuses["task_1"]), [], False

        def fake_update_task_status(task_id, state_value, **kwargs):
            statuses[task_id]["state"] = state_value
            statuses[task_id]["terminal"] = state_value in {"succeeded", "failed", "cancelled"}
            if kwargs.get("result_ref"):
                statuses[task_id]["result_ref"] = kwargs["result_ref"]
            return True, dict(statuses[task_id]), []

        def fake_get_task_status(task_id):
            return dict(statuses[task_id])

        response = CommandResponse(
            ok=True,
            command="backup-document",
            request_id="req_1",
            backend="local-python",
            summary="ok",
            validation=ValidationResult(status="passed"),
        )

        with (
            patch("wps_ai_agent_cli.cli.create_task_status", side_effect=fake_create_task_status),
            patch("wps_ai_agent_cli.cli.update_task_status", side_effect=fake_update_task_status),
            patch("wps_ai_agent_cli.cli.get_task_status", side_effect=fake_get_task_status),
        ):
            result = _with_optional_task_status(
                lambda: response,
                task_id="task_1",
                tracked_command="backup-document",
                operation_request_id="req_1",
                document_id="doc_1",
            )

        self.assertEqual(result.data["task_status"]["state"], "succeeded")
        self.assertTrue(result.data["task_status"]["terminal"])
        self.assertEqual(result.data["task_status"]["result_ref"], "req_1")


if __name__ == "__main__":
    unittest.main()
